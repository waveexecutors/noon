package dev.noon.gui;

import dev.noon.util.Anim;
import dev.noon.util.Fonts;
import dev.noon.util.Gfx;
import dev.noon.util.Sounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * Poco main menu, drawn on top of the REAL vanilla TitleScreen (see TitleScreenMixin) so every sub screen simply returns to it.
 * First launch: HyperOS image -> POCO image -> menu. Logos are your PNGs (assets/noon/textures/gui). Input is polled from GLFW.
 */
public final class PocoMenu {
    private PocoMenu() {}

    private static final Identifier HYPER = Identifier.of("noon", "textures/gui/hyperos.png");
    private static final Identifier POCO = Identifier.of("noon", "textures/gui/poco.png");
    private static final int HYPER_W = 1080, HYPER_H = 608, POCO_W = 700, POCO_H = 212;

    private static final int GOLD = 0xFFF2B24A, YELLOW = 0xFFFFCB00, BTN = 0xFF333333, BTN_HOVER = 0xFF414141, BG = 0xFF101010;
    private static final String[] LABELS = {"SinglePlayer", "MultiPlayer", "POCO Alt", "Options", "Exit Game"};

    private static final Anim[] HOVER = {new Anim(), new Anim(), new Anim(), new Anim(), new Anim()};
    private static final Anim MENU_IN = new Anim();
    private static boolean introPlayed, started, prevL, soundPlayed;
    private static long start;

    private static void tex(DrawContext c, Identifier id, int x, int y, int w, int h, int tw, int th) {
        c.drawTexture(RenderPipelines.GUI_TEXTURED, id, x, y, 0f, 0f, w, h, tw, th, tw, th);
    }

    private static float seg(float t, float a, float b) {
        return Anim.clamp01((t - a) / (b - a));
    }

    private static void disc(DrawContext c, int cx, int cy, int r, int topCol, int botCol, float a) {
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.sqrt((double) r * r - (double) dy * dy);
            float t = (dy + r) / (2f * r);
            c.fill(cx - half, cy + dy, cx + half, cy + dy + 1, Gfx.alpha(Gfx.lerp(topCol, botCol, t), a));
        }
    }

    /** Called every frame instead of TitleScreen.render. */
    public static void render(TitleScreen screen, DrawContext ctx, int mx, int my) {
        MinecraftClient mc = MinecraftClient.getInstance();
        long handle = mc.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean click = l && !prevL;
        prevL = l;
        int w = screen.width, h = screen.height;

        if (!started) {
            started = true;
            start = System.currentTimeMillis();
            MENU_IN.v = introPlayed ? 0f : 0f;
        }
        float t = (System.currentTimeMillis() - start) / 1000f;

        if (!introPlayed) {
            if (!soundPlayed) {
                soundPlayed = true;
                Sounds.charging();
            }
            if (click || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_SPACE) == GLFW.GLFW_PRESS) t = Math.max(t, 4.7f);
            if (t < 4.7f) {
                ctx.fill(0, 0, w, h, 0xFF000000);
                intro(ctx, w, h, t);
                return;
            }
            introPlayed = true;
            MENU_IN.v = 0f;
        }
        float a = MENU_IN.to(1f, 5f);
        menu(screen, mc, ctx, w, h, mx, my, click, a, (System.currentTimeMillis() - start) / 1000f);
    }

    private static void intro(DrawContext ctx, int w, int h, float t) {
        // HyperOS image: fade in 0.4-0.95s, out 2.2-2.65s
        float a1 = seg(t, 0.4f, 0.95f) * (1f - seg(t, 2.2f, 2.65f));
        if (a1 > 0.01f) {
            float sc = Math.min(w / (float) HYPER_W, h / (float) HYPER_H);
            int dw = Math.round(HYPER_W * sc), dh = Math.round(HYPER_H * sc);
            int x = (w - dw) / 2, y = (h - dh) / 2;
            tex(ctx, HYPER, x, y, dw, dh, HYPER_W, HYPER_H);
            ctx.fill(x, y, x + dw, y + dh, Gfx.alpha(0xFF000000, 1f - a1)); // fade by covering with black
        }
        // POCO image: in 2.7-3.3s, out 4.1-4.6s
        float a2 = seg(t, 2.7f, 3.3f) * (1f - seg(t, 4.1f, 4.6f));
        if (a2 > 0.01f) {
            int dw = Math.round(w * 0.36f), dh = Math.round(dw * POCO_H / (float) POCO_W);
            int x = (w - dw) / 2, y = (h - dh) / 2;
            tex(ctx, POCO, x, y, dw, dh, POCO_W, POCO_H);
            ctx.fill(x, y, x + dw, y + dh, Gfx.alpha(0xFF000000, 1f - a2));
        }
    }

    private static void menu(TitleScreen screen, MinecraftClient mc, DrawContext ctx, int w, int h, int mx, int my, boolean click, float a, float t) {
        ctx.fill(0, 0, w, h, BG);
        disc(ctx, -Math.round(w * 0.02f), -Math.round(h * 0.04f), Math.round(h * 0.34f), 0xFFE9B340, 0xFF9A6E22, a);
        disc(ctx, w + Math.round(w * 0.02f), h + Math.round(h * 0.12f), Math.round(h * 0.42f), 0xFFE6B04A, 0xFF8A5F1E, a);

        int pw = Math.max(210, Math.min(380, Math.round(w * 0.45f)));
        int ph = Math.round(pw * 0.655f);
        int px = (w - pw) / 2, py = Math.round(h * 0.40f) + Math.round((1f - a) * 14f);
        float pulse = 0.5f + 0.5f * (float) Math.sin(t * 2.4);
        int r = Math.round(ph * 0.1f);

        // POCO logo (your PNG) above the panel
        int lw = Math.round(pw * 0.42f), lh = Math.round(lw * POCO_H / (float) POCO_W);
        int lx = (w - lw) / 2, ly = py - lh - Math.round(ph * 0.07f);
        tex(ctx, POCO, lx, ly, lw, lh, POCO_W, POCO_H);
        if (a < 0.99f) ctx.fill(lx, ly, lx + lw, ly + lh, Gfx.alpha(BG, 1f - a));

        for (int i = 8; i >= 1; i--) {
            int g = i * 2;
            Gfx.rrectFast(ctx, px - g, py - g, pw + g * 2, ph + g * 2, r + g, Gfx.alpha(0xFFEAB84C, a * (0.035f + 0.02f * pulse) * (9 - i) / 8f));
        }
        Gfx.rrect(ctx, px, py, pw, ph, r, Gfx.alpha(Gfx.lerp(0xFFB9B9B9, 0xFFFFFFFF, pulse), a));
        int bw = Math.max(2, Math.round(ph * 0.03f));
        Gfx.rrect(ctx, px + bw, py + bw, pw - bw * 2, ph - bw * 2, Math.max(2, r - bw), Gfx.alpha(GOLD, a));

        int pad = Math.round(pw * 0.04f);
        int bh = Math.round(ph * 0.15f);
        int half = (pw - pad * 2 - Math.round(pw * 0.02f)) / 2;
        int cw = Math.round(pw * 0.53f);
        int[][] rects = {
                {px + pad, py + Math.round(ph * 0.09f), half, bh},
                {px + pw - pad - half, py + Math.round(ph * 0.09f), half, bh},
                {px + (pw - cw) / 2, py + Math.round(ph * 0.28f), cw, bh},
                {px + (pw - cw) / 2, py + Math.round(ph * 0.50f), cw, bh},
                {px + (pw - cw) / 2, py + Math.round(ph * 0.76f), cw, bh}};

        for (int i = 0; i < 5; i++) {
            int[] b = rects[i];
            boolean hov = a > 0.9f && mx >= b[0] && mx < b[0] + b[2] && my >= b[1] && my < b[1] + b[3];
            float hv = HOVER[i].to(hov ? 1f : 0f, 16f);
            int g = Math.round(hv * 1.5f);
            int bx = b[0] - g, by = b[1] - g, bww = b[2] + g * 2, bhh = b[3] + g * 2;
            int rad = Math.max(3, bhh / 3);
            Gfx.rrectFast(ctx, bx - 1, by + 1, bww + 2, bhh + 2, rad + 1, Gfx.alpha(0x50000000, a));
            Gfx.rrect(ctx, bx, by, bww, bhh, rad, Gfx.alpha(0xFFFFFFFF, a));
            Gfx.rrect(ctx, bx + 2, by + 2, bww - 4, bhh - 4, Math.max(2, rad - 2), Gfx.alpha(Gfx.lerp(BTN, BTN_HOVER, hv), a));
            String s = LABELS[i];
            int tw = Fonts.width(s, "m");
            Fonts.draw(ctx, "m", s, bx + (bww - tw) / 2, by + (bhh - 11) / 2, Gfx.alpha(Gfx.lerp(GOLD, YELLOW, hv), a));
            if (click && hov) {
                Sounds.click();
                Screen self = screen;
                switch (i) {
                    case 0 -> mc.setScreen(new SelectWorldScreen(self));
                    case 1 -> mc.setScreen(new MultiplayerScreen(self));
                    case 2 -> mc.setScreen(new AltScreen(self));
                    case 3 -> mc.setScreen(new OptionsScreen(self, mc.options));
                    default -> mc.scheduleStop();
                }
                return;
            }
        }
    }
}
