package dev.noon.gui;

import dev.noon.util.Anim;
import dev.noon.util.Fonts;
import dev.noon.util.Gfx;
import dev.noon.util.Sounds;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Poco main menu: first launch plays the "Powered by Xiaomi HyperOS" -> POCO boot splash, then the menu with the golden corner
 * discs and a glowing panel. Replaces the vanilla title screen (see MinecraftClientMixin). Input is polled from GLFW.
 */
public class PocoMenuScreen extends Screen {
    private static boolean introPlayed;

    private static final int GOLD = 0xFFF2B24A, YELLOW = 0xFFFFCB00, BTN = 0xFF333333, BTN_HOVER = 0xFF414141, BLUE = 0xFF2D5BFF;

    private final String[] labels = {"SinglePlayer", "MultiPlayer", "POCO Alt", "Options", "Exit Game"};
    private final Anim[] hover = new Anim[5];
    private final Anim menuIn = new Anim();
    private long start = System.currentTimeMillis();
    private boolean intro = !introPlayed;
    private boolean soundPlayed, prevL;
    private int[][] rects = new int[5][4];

    public PocoMenuScreen() {
        super(Text.literal("Poco"));
        for (int i = 0; i < hover.length; i++) hover[i] = new Anim();
        if (!intro) menuIn.v = 0f;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static void disc(DrawContext c, int cx, int cy, int r, int topCol, int botCol, float a) {
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.sqrt((double) r * r - (double) dy * dy);
            float t = (dy + r) / (2f * r);
            c.fill(cx - half, cy + dy, cx + half, cy + dy + 1, Gfx.alpha(Gfx.lerp(topCol, botCol, t), a));
        }
    }

    private static float seg(float t, float a, float b) {
        return Anim.clamp01((t - a) / (b - a));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long handle = this.client.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean click = l && !prevL;
        prevL = l;
        float t = (System.currentTimeMillis() - start) / 1000f;
        ctx.fill(0, 0, this.width, this.height, 0xFF000000);

        if (intro) {
            if (!soundPlayed) {
                soundPlayed = true;
                Sounds.charging();
            }
            if (click || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_SPACE) == GLFW.GLFW_PRESS) t = Math.max(t, 4.6f);
            if (t >= 4.6f) {
                intro = false;
                introPlayed = true;
                start = System.currentTimeMillis() - 4600;
                menuIn.v = 0f;
            } else {
                drawIntro(ctx, t);
                return;
            }
        }
        float mt = menuIn.to(1f, 5f);
        drawMenu(ctx, mx, my, click, mt, (System.currentTimeMillis() - start) / 1000f);
    }

    private void drawIntro(DrawContext ctx, float t) {
        // HyperOS card: 0.5s in, hold, out at 2.4s
        float a1 = seg(t, 0.4f, 0.95f) * (1f - seg(t, 2.2f, 2.65f));
        if (a1 > 0.01f) {
            int x = Math.round(this.width * 0.115f), y = Math.round(this.height * 0.32f) + Math.round((1f - seg(t, 0.4f, 0.95f)) * 6f);
            Fonts.draw(ctx, "m", "Powered by", x, y, Gfx.alpha(0xFF8C8C8C, a1));
            String a = "Xiaomi Hyper";
            Fonts.draw(ctx, "l", a, x, y + 17, Gfx.alpha(0xFFFFFFFF, a1));
            Fonts.draw(ctx, "l", "OS", x + Fonts.width(a, "l"), y + 17, Gfx.alpha(BLUE, a1));
        }
        // POCO wordmark: 2.7s in, hold, out at 4.2s
        float a2 = seg(t, 2.7f, 3.3f) * (1f - seg(t, 4.1f, 4.6f));
        if (a2 > 0.01f) {
            String s = "POCO";
            int w = Fonts.width(s, "xl");
            int y = this.height / 2 - 17 + Math.round((1f - seg(t, 2.7f, 3.3f)) * 8f);
            Fonts.draw(ctx, "xl", s, (this.width - w) / 2, y, Gfx.alpha(YELLOW, a2));
        }
    }

    private void drawMenu(DrawContext ctx, int mx, int my, boolean click, float a, float t) {
        int w = this.width, h = this.height;
        ctx.fill(0, 0, w, h, 0xFF101010);
        disc(ctx, -Math.round(w * 0.02f), -Math.round(h * 0.04f), Math.round(h * 0.34f), 0xFFE9B340, 0xFF9A6E22, a);
        disc(ctx, w + Math.round(w * 0.02f), h + Math.round(h * 0.12f), Math.round(h * 0.42f), 0xFFE6B04A, 0xFF8A5F1E, a);

        // panel
        int pw = Math.max(210, Math.min(380, Math.round(w * 0.45f)));
        int ph = Math.round(pw * 0.655f);
        int px = (w - pw) / 2, py = Math.round(h * 0.37f) + Math.round((1f - a) * 14f);
        float pulse = 0.5f + 0.5f * (float) Math.sin(t * 2.4);
        int r = Math.round(ph * 0.1f);

        String title = "POCO";
        Fonts.draw(ctx, "xl", title, (w - Fonts.width(title, "xl")) / 2, py - 44, Gfx.alpha(YELLOW, a));

        for (int i = 8; i >= 1; i--) { // soft golden glow
            int g = i * 2;
            Gfx.rrectFast(ctx, px - g, py - g, pw + g * 2, ph + g * 2, r + g, Gfx.alpha(0xFFEAB84C, a * (0.035f + 0.02f * pulse) * (9 - i) / 8f));
        }
        Gfx.rrect(ctx, px, py, pw, ph, r, Gfx.alpha(Gfx.lerp(0xFFB9B9B9, 0xFFFFFFFF, pulse), a));
        int bw = Math.max(2, Math.round(ph * 0.03f));
        Gfx.rrect(ctx, px + bw, py + bw, pw - bw * 2, ph - bw * 2, Math.max(2, r - bw), Gfx.alpha(Gfx.lerp(0xFFB48637, GOLD, Math.min(1f, a + pulse * 0.1f)), a));

        // buttons
        int pad = Math.round(pw * 0.04f);
        int bh = Math.round(ph * 0.15f);
        int half = (pw - pad * 2 - Math.round(pw * 0.02f)) / 2;
        int cw = Math.round(pw * 0.53f);
        rects[0] = new int[]{px + pad, py + Math.round(ph * 0.09f), half, bh};
        rects[1] = new int[]{px + pw - pad - half, py + Math.round(ph * 0.09f), half, bh};
        rects[2] = new int[]{px + (pw - cw) / 2, py + Math.round(ph * 0.28f), cw, bh};
        rects[3] = new int[]{px + (pw - cw) / 2, py + Math.round(ph * 0.50f), cw, bh};
        rects[4] = new int[]{px + (pw - cw) / 2, py + Math.round(ph * 0.76f), cw, bh};

        for (int i = 0; i < 5; i++) {
            int[] b = rects[i];
            boolean hov = a > 0.9f && mx >= b[0] && mx < b[0] + b[2] && my >= b[1] && my < b[1] + b[3];
            float hv = hover[i].to(hov ? 1f : 0f, 16f);
            int g = Math.round(hv * 1.5f);
            int bx = b[0] - g, by = b[1] - g, bww = b[2] + g * 2, bhh = b[3] + g * 2;
            int rad = Math.max(3, bhh / 3);
            Gfx.rrectFast(ctx, bx - 1, by + 1, bww + 2, bhh + 2, rad + 1, Gfx.alpha(0x50000000, a)); // drop shadow
            Gfx.rrect(ctx, bx, by, bww, bhh, rad, Gfx.alpha(0xFFFFFFFF, a));
            Gfx.rrect(ctx, bx + 2, by + 2, bww - 4, bhh - 4, Math.max(2, rad - 2), Gfx.alpha(Gfx.lerp(BTN, BTN_HOVER, hv), a));
            String s = labels[i];
            int tw = Fonts.width(s, "m");
            Fonts.draw(ctx, "m", s, bx + (bww - tw) / 2, by + (bhh - 11) / 2, Gfx.alpha(Gfx.lerp(GOLD, YELLOW, hv), a));
            if (click && hov) {
                Sounds.click();
                press(i);
            }
        }
    }

    private void press(int i) {
        switch (i) {
            case 0 -> this.client.setScreen(new SelectWorldScreen(this));
            case 1 -> this.client.setScreen(new MultiplayerScreen(this));
            case 2 -> this.client.setScreen(new AltScreen(this));
            case 3 -> this.client.setScreen(new OptionsScreen(this, this.client.options));
            default -> this.client.scheduleStop();
        }
    }
}
