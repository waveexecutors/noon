package dev.noon.mixin;

import dev.noon.gui.PocoMenuScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    /** Swaps the vanilla title screen for the Poco menu. */
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen noon$pocoMenu(Screen screen) {
        if (screen != null && screen.getClass() == TitleScreen.class) return new PocoMenuScreen();
        return screen;
    }
}
