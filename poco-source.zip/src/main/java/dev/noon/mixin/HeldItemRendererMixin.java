package dev.noon.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import dev.noon.module.render.Animations;
import dev.noon.module.render.HandCustomization;
import dev.noon.module.render.HandGlow;
import net.minecraft.item.ItemStack;
import net.minecraft.item.BlockItem;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Written against argument TYPES (via @Local / ordinals) instead of the full descriptor, so it keeps matching even if the
 * render-queue parameter type changes between 1.21.x versions.
 */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    /** Custom swing replaces vanilla's: zero the vanilla swingProgress (3rd float arg) while an animation is selected. */
    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, ordinal = 2)
    private float noon$noVanillaSwing(float swing) {
        return swing > 0f && Animations.overridesSwing() ? 0f : swing;
    }

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void noon$handBegin(CallbackInfo ci,
                                @Local(argsOnly = true) AbstractClientPlayerEntity player,
                                @Local(argsOnly = true) Hand hand,
                                @Local(argsOnly = true) MatrixStack matrices,
                                @Local(argsOnly = true) ItemStack item,
                                @Local(argsOnly = true, ordinal = 0) float tickProgress) {
        matrices.push();
        boolean right = player.getMainArm() == Arm.RIGHT;
        HandCustomization.apply(matrices, hand, right);
        Animations.apply(matrices, hand, right, player.getHandSwingProgress(tickProgress));
        if (HandGlow.INSTANCE.enabled) {
            // full hand matrix (view space, incl. customization / animation); HandGlow rebuilds the vanilla arm transform on top
            float[] m = new float[16];
            matrices.peek().getPositionMatrix().get(m);
            HandGlow.capture(hand == Hand.MAIN_HAND, m, item.isEmpty(), item.getItem() instanceof BlockItem);
        }
    }

    /** Separate injector (require = 0) so a signature change can only break the glow, never the hand rendering itself. */
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), require = 0)
    private void noon$handParams(CallbackInfo ci,
                                 @Local(argsOnly = true) Hand hand,
                                 @Local(argsOnly = true, ordinal = 2) float swingProgress,
                                 @Local(argsOnly = true, ordinal = 3) float equipProgress) {
        if (HandGlow.INSTANCE.enabled) HandGlow.params(hand == Hand.MAIN_HAND, swingProgress, equipProgress);
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
    private void noon$handEnd(CallbackInfo ci, @Local(argsOnly = true) MatrixStack matrices) {
        matrices.pop();
    }
}
