package dev.noon.mixin;
import dev.noon.module.combat.FakeLag;
import net.minecraft.network.ClientConnection;
import io.netty.channel.ChannelFutureListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ClientConnection.class)
public abstract class ClientConnectionMixin {
 @Inject(method="send(Lnet/minecraft/network/packet/Packet;Lio/netty/channel/ChannelFutureListener;)V",at=@At("HEAD"),cancellable=true,require=0)
 private void noon$delayMovement(Packet<?> packet, ChannelFutureListener callbacks, CallbackInfo ci){if(FakeLag.intercept((ClientConnection)(Object)this,packet,callbacks))ci.cancel();}
 @Inject(method="disconnect",at=@At("HEAD"),require=0)
 private void noon$flushOnDisconnect(Text reason,CallbackInfo ci){FakeLag.flushAll();}
}
