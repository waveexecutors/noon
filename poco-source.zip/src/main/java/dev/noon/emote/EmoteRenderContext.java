package dev.noon.emote;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
/** Weak state identity map: identifies the local player's render state without retaining old frames. */
public final class EmoteRenderContext {
 private static final Map<PlayerEntityRenderState,Boolean> LOCAL=Collections.synchronizedMap(new WeakHashMap<>());
 private EmoteRenderContext(){}
 public static void mark(PlayerEntityRenderState state,boolean local){if(local)LOCAL.put(state,Boolean.TRUE);else LOCAL.remove(state);}
 public static boolean isLocal(PlayerEntityRenderState state){return LOCAL.containsKey(state);}
}
