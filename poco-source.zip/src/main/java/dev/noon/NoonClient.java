package dev.noon;

import dev.noon.alt.AltManager;
import dev.noon.gui.ClickGuiScreen;
import dev.noon.hud.Hud;
import dev.noon.module.ModuleManager;
import dev.noon.module.combat.AimAssist;
import dev.noon.module.combat.Criticals;
import dev.noon.module.combat.WTap;
import dev.noon.module.render.HandGlow;
import dev.noon.module.render.MobESP;
import dev.noon.module.render.PlayerESP;
import dev.noon.module.render.StorageESP;
import dev.noon.module.render.Tracers;
import dev.noon.module.smp.BaseFinder;
import dev.noon.module.smp.LogoutSpots;
import dev.noon.module.smp.StaffRadar;
import dev.noon.render.Esp;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class NoonClient implements ClientModInitializer {
    private boolean prevKey;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ModuleManager.load();
        AltManager.load();


        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> ModuleManager.save());
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            AimAssist.INSTANCE.frame();
            if (mc.player != null && mc.world != null && !mc.options.hudHidden) {
                Esp.begin(mc, ctx, tickCounter.getTickProgress(false));
                if (Esp.ready()) {
                    if (Tracers.INSTANCE.enabled) Tracers.INSTANCE.render(mc, ctx);
                    if (StorageESP.INSTANCE.enabled) StorageESP.INSTANCE.render(mc, ctx);
                    if (MobESP.INSTANCE.enabled) MobESP.INSTANCE.render(mc, ctx);
                    if (PlayerESP.INSTANCE.enabled) PlayerESP.INSTANCE.render(mc, ctx);
                    if (BaseFinder.INSTANCE.enabled) BaseFinder.INSTANCE.render(mc, ctx);
                    if (LogoutSpots.INSTANCE.enabled) LogoutSpots.INSTANCE.render(mc, ctx);
                }
            }
            if (HandGlow.INSTANCE.enabled) HandGlow.INSTANCE.render(mc, ctx, tickCounter.getTickProgress(false));
            if (StaffRadar.INSTANCE.enabled) StaffRadar.INSTANCE.render(ctx);
            Hud.render(ctx);
            if (!(mc.currentScreen instanceof ClickGuiScreen)) dev.noon.gui.Notify.render(ctx);
        });

        // manual attacks go through Criticals (it may delay them until the hop peaks)
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (player == MinecraftClient.getInstance().player && !Criticals.internal && Criticals.handle(entity)) {
                return ActionResult.FAIL;
            }
            if (player == MinecraftClient.getInstance().player) WTap.onAttack();
            return ActionResult.PASS;
        });
    }

    private void tick(MinecraftClient mc) {
        if (mc.getWindow() == null) return;

        // Right Shift opens / closes the ClickGUI
        boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (down && !prevKey) {
            if (mc.currentScreen instanceof ClickGuiScreen gui) {
                if (!gui.isBinding()) gui.requestClose();
            } else if (mc.currentScreen == null && mc.player != null) {
                mc.setScreen(new ClickGuiScreen());
            }
        }
        prevKey = down;

        if (mc.player != null && mc.world != null) {
            ModuleManager.tick();
        }
    }
}
