package dev.noon.module.combat;
import dev.noon.module.Module;import dev.noon.module.Category;import dev.noon.module.Setting;import net.minecraft.client.MinecraftClient;import net.minecraft.entity.Entity;import net.minecraft.entity.player.PlayerEntity;import net.minecraft.util.hit.EntityHitResult;import net.minecraft.util.math.Vec3d;import java.util.*;
/** Bounded client-side target position recorder. It does not alter hitboxes or server combat validation. */
public final class Backtrack extends Module {
 public static final Backtrack INSTANCE=new Backtrack();
 public final Setting.Num duration=add(new Setting.Num("History (ms)",100,2000,500,50));
 public final Setting.Bool showHistory=add(new Setting.Bool("Visualize History",true));
 public record Sample(int entityId,long time,Vec3d position){}
 private final ArrayDeque<Sample> history=new ArrayDeque<>(); private int targetId=-1;
 private Backtrack(){super("Backtrack",Category.COMBAT);}
 @Override public void onTick(){MinecraftClient mc=mc();if(mc.player==null||mc.world==null){clear();return;}if(!(mc.crosshairTarget instanceof EntityHitResult hit)||!(hit.getEntity() instanceof PlayerEntity target)||target==mc.player){clear();return;}long now=System.nanoTime();if(target.getId()!=targetId){history.clear();targetId=target.getId();}history.addLast(new Sample(targetId,now,target.getEntityPos()));long cutoff=now-(long)(duration.get()*1_000_000L);while(!history.isEmpty()&&(history.peekFirst().time()<cutoff||history.size()>80))history.removeFirst();}
 public List<Sample> samples(){return List.copyOf(history);} public void clear(){history.clear();targetId=-1;}
 @Override public void onDisable(){clear();}
}
