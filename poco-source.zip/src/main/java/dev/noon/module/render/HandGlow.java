package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.util.Gfx;
import dev.noon.util.HandMath;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Arm;

/**
 * Real hand outline: HeldItemRendererMixin captures the exact first-person matrix of each hand every frame, HandMath rebuilds
 * the vanilla arm transform on top of it and projects the actual arm box, and this module fills a thick outline that hugs
 * that silhouette, plus a soft glow fading outward. It follows swing, equip, bobbing, Animations and Hand Customization.
 */
public class HandGlow extends Module {
    public static final HandGlow INSTANCE = new HandGlow();

    public final Setting.Mode colorMode = add(new Setting.Mode("Color Mode", 0, "Rainbow", "Custom", "Fade", "Pulse"));
    public final Setting.Num r1 = add(new Setting.Num("Red", 0, 255, 80, 1));
    public final Setting.Num g1 = add(new Setting.Num("Green", 0, 255, 160, 1));
    public final Setting.Num b1 = add(new Setting.Num("Blue", 0, 255, 255, 1));
    public final Setting.Num r2 = add(new Setting.Num("Fade Red", 0, 255, 255, 1));
    public final Setting.Num g2 = add(new Setting.Num("Fade Green", 0, 255, 60, 1));
    public final Setting.Num b2 = add(new Setting.Num("Fade Blue", 0, 255, 180, 1));
    public final Setting.Num speed = add(new Setting.Num("Speed", 0.1, 5.0, 1.0, 0.1));
    public final Setting.Num thickness = add(new Setting.Num("Outline Thickness", 1, 12, 3, 0.5));
    public final Setting.Num glowSpread = add(new Setting.Num("Glow Spread", 0, 30, 8, 1));
    public final Setting.Num glowAlpha = add(new Setting.Num("Glow Intensity", 5, 100, 60, 1));
    public final Setting.Num layers = add(new Setting.Num("Glow Layers", 1, 8, 4, 1));
    public final Setting.Bool mainHand = add(new Setting.Bool("Main Hand", true));
    public final Setting.Bool offHand = add(new Setting.Bool("Off Hand", true));
    public final Setting.Bool needItem = add(new Setting.Bool("Only With Item", false));
    public final Setting.Bool outlineItems = add(new Setting.Bool("Glow Held Items", true));
    public final Setting.Num itemFit = add(new Setting.Num("Item Fit", 0.4, 1.0, 0.72, 0.02));
    public final Setting.Bool slimArms = add(new Setting.Bool("Slim Arms", false));
    public final Setting.Num handFov = add(new Setting.Num("Hand FOV", 40, 110, 70, 1));
    // manual calibration, in case a different GUI scale / FOV mod shifts the projection
    public final Setting.Mode camFix = add(new Setting.Mode("Camera Fix", 0, "Auto", "Off", "Force"));
    public final Setting.Num offX = add(new Setting.Num("Align X", -60, 60, 0, 1));
    public final Setting.Num offY = add(new Setting.Num("Align Y", -60, 60, 0, 1));
    public final Setting.Num fitScale = add(new Setting.Num("Align Scale", 0.6, 1.6, 1.0, 0.01));

    private HandGlow() {
        super("Hand Glow", Category.RENDER);
        showInHud = false;
    }

    private int color(float t) {
        double ph = System.currentTimeMillis() / 1000.0 * speed.get();
        int c1 = 0xFF000000 | (r1.i() << 16) | (g1.i() << 8) | b1.i();
        int c2 = 0xFF000000 | (r2.i() << 16) | (g2.i() << 8) | b2.i();
        switch (colorMode.index) {
            case 0:
                return 0xFF000000 | java.awt.Color.HSBtoRGB((float) ((ph * 0.25 + t * 0.15) % 1.0), 0.7f, 1f);
            case 1:
                return c1;
            case 2:
                return Gfx.lerp(c1, c2, (float) (0.5 + 0.5 * Math.sin(ph * 2.0 + t * 2.0)));
            default:
                return Gfx.lerp(0xFF000000 | ((r1.i() / 3) << 16) | ((g1.i() / 3) << 8) | (b1.i() / 3), c1,
                        (float) (0.5 + 0.5 * Math.sin(ph * 3.0)));
        }
    }

    // ---- per-frame capture from HeldItemRendererMixin ------------------------------------------

    private static final float[][] MAT = new float[2][16];
    private static final float[] SWING = new float[2], EQUIP = new float[2];
    private static final boolean[] EMPTY = new boolean[2], BLOCK = new boolean[2];
    private static final long[] CAP_T = new long[2];
    private static boolean inverseSeen;

    /** Hand matrix (view space, after Hand Customization + Animations) at the start of renderFirstPersonItem. */
    public static void capture(boolean main, float[] mat, boolean empty, boolean block) {
        int i = main ? 0 : 1;
        System.arraycopy(mat, 0, MAT[i], 0, 16);
        EMPTY[i] = empty;
        BLOCK[i] = block;
        CAP_T[i] = System.nanoTime();
    }

    /** swingProgress / equipProgress arguments of renderFirstPersonItem. */
    public static void params(boolean main, float swing, float equip) {
        int i = main ? 0 : 1;
        SWING[i] = swing;
        EQUIP[i] = equip;
    }

    // ---- drawing ------------------------------------------------------------------------------

    public void render(MinecraftClient mc, DrawContext ctx, float td) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson()) return;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        double tanHalf = Math.tan(Math.toRadians(handFov.get()) / 2.0);
        double aspect = (double) sw / sh;
        long now = System.nanoTime();
        for (int i = 0; i < 2; i++) {
            boolean main = i == 0;
            if (main ? !mainHand.get() : !offHand.get()) continue;
            if (now - CAP_T[i] > 100_000_000L) continue; // vanilla did not draw this hand this frame
            boolean empty = EMPTY[i];
            if (empty && (!main || p.isInvisible())) continue; // vanilla draws no bare off hand / no arm when invisible
            if (!empty && !outlineItems.get()) continue;
            if (main && needItem.get() && empty) continue;

            Arm arm = main ? p.getMainArm() : p.getMainArm().getOpposite();
            boolean right = arm == Arm.RIGHT;
            float swing = SWING[i];
            if (swing > 0f && Animations.overridesSwing()) swing = 0f; // mixin zeroes vanilla's swing in that case
            double[] base = HandMath.fromColumnMajor(MAT[i]);
            // Since 1.21.2 the hand matrix stack starts with the INVERSE of the camera rotation (the real view matrix is applied
            // afterwards by the renderer). Without cancelling it the glow swings around whenever you look around. Auto latches
            // on once a hand matrix rotates by more than a hand ever can (a real hand tilts ~15 degrees at most).
            if (camFix.index != 1) {
                double tr = base[0] + base[5] + base[10];
                double ang = Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, (tr - 1.0) / 2.0))));
                if (ang > 40.0) inverseSeen = true;
                if (camFix.index == 2 || inverseSeen) {
                    net.minecraft.client.render.Camera cam = mc.gameRenderer.getCamera();
                    double[] v = HandMath.rotX(HandMath.id(), cam.getPitch());
                    v = HandMath.rotY(v, cam.getYaw() - 180.0);
                    base = HandMath.mul(v, base);
                }
            }
            double[][] corners = empty
                    ? HandMath.arm(base, right, slimArms.get(), swing, EQUIP[i])
                    : HandMath.item(base, right, BLOCK[i], swing, EQUIP[i], itemFit.get());
            List<double[]> pts = HandMath.project(corners, tanHalf, aspect, sw, sh);
            if (pts.size() < 3) continue;
            // calibration: scale about the centroid of the projected points, then shift
            double mx = 0, my = 0;
            for (double[] q : pts) {
                mx += q[0];
                my += q[1];
            }
            mx /= pts.size();
            my /= pts.size();
            double sc = fitScale.get(), ox = offX.get(), oy = offY.get();
            for (double[] q : pts) {
                q[0] = mx + (q[0] - mx) * sc + ox;
                q[1] = my + (q[1] - my) * sc + oy;
            }
            double[][] hull = HandMath.hull(pts);
            if (hull.length >= 3) drawOutline(ctx, hull, sw, sh, i);
        }
    }

    /** Solid thick outline hugging the hull + glow bands fading outward, filled row by row. */
    private void drawOutline(DrawContext ctx, double[][] hull, int sw, int sh, int hand) {
        int n = layers.i();
        double thick = thickness.get();
        double gs = n > 0 ? glowSpread.get() / n : 0;
        int bands = 1 + (gs > 0 ? n : 0);
        double[] radius = new double[bands + 1];
        int[] col = new int[bands];
        radius[0] = 0;
        radius[1] = thick;
        col[0] = color(hand * 0.5f);
        float base = glowAlpha.f() / 100f;
        for (int k = 1; k < bands; k++) {
            radius[k + 1] = thick + k * gs;
            float fall = 1f - (k - 1) / (float) n;
            col[k] = Gfx.alpha(color(hand * 0.5f + k * 0.04f), base * fall * fall);
        }

        double minY = Double.POSITIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY, minX = Double.POSITIVE_INFINITY, maxX = Double.NEGATIVE_INFINITY;
        for (double[] v : hull) {
            minY = Math.min(minY, v[1]);
            maxY = Math.max(maxY, v[1]);
            minX = Math.min(minX, v[0]);
            maxX = Math.max(maxX, v[0]);
        }
        // a wrong / degenerate projection can produce a hull covering the screen: drawing that is what made the game lag
        if ((maxX - minX) * (maxY - minY) > 0.55 * sw * sh) return;
        double reach = radius[bands];
        int y0 = Math.max(0, (int) Math.floor(minY - reach)), y1 = Math.min(sh, (int) Math.ceil(maxY + reach));
        // fill budget: rows are drawn `step` pixels tall so the number of fill calls stays bounded
        int step = Math.max(1, (int) Math.ceil((y1 - y0) * (double) bands * 2.0 / 900.0));
        step = Math.min(step, 4);
        double[][] sp = new double[bands + 1][2];
        boolean[] has = new boolean[bands + 1];
        for (int y = y0; y < y1; y += step) {
            int yEnd = Math.min(y1, y + step);
            double yc = y + step * 0.5;
            for (int k = 0; k <= bands; k++) has[k] = HandMath.span(hull, radius[k], yc, sp[k]);
            for (int k = 0; k < bands; k++) {
                if (!has[k + 1]) continue; // band k lies between radius[k] (inner) and radius[k + 1] (outer)
                int lo = clamp(Math.round(sp[k + 1][0]), sw), hi = clamp(Math.round(sp[k + 1][1]), sw);
                if (has[k]) {
                    int li = clamp(Math.round(sp[k][0]), sw), ri = clamp(Math.round(sp[k][1]), sw);
                    if (li > lo) ctx.fill(lo, y, li, yEnd, col[k]);
                    if (hi > ri) ctx.fill(ri, y, hi, yEnd, col[k]);
                } else if (hi > lo) {
                    ctx.fill(lo, y, hi, yEnd, col[k]);
                }
            }
        }
    }

    private static int clamp(long v, int w) {
        return (int) Math.max(0, Math.min(w, v));
    }
}
