package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.util.Gfx;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Configurable Christmas / winter HUD visuals. Enable individual effects in settings.
 */
public class Christmas extends Module {
    public static final Christmas INSTANCE = new Christmas();

    public final Setting.Bool snow = add(new Setting.Bool("Snowflakes", true));
    public final Setting.Bool fallingSnow = add(new Setting.Bool("Falling Snow", true));
    public final Setting.Bool twinkle = add(new Setting.Bool("Twinkle Lights", true));
    public final Setting.Bool garland = add(new Setting.Bool("Top Garland", true));
    public final Setting.Bool cornerTrees = add(new Setting.Bool("Corner Trees", false));
    public final Setting.Bool candyCane = add(new Setting.Bool("Candy Cane Borders", false));
    public final Setting.Bool mistletoe = add(new Setting.Bool("Mistletoe", false));
    public final Setting.Bool gifts = add(new Setting.Bool("Gift Icons", false));
    public final Setting.Bool stars = add(new Setting.Bool("Golden Stars", true));
    public final Setting.Bool aurora = add(new Setting.Bool("Aurora Tint", false));
    public final Setting.Bool frost = add(new Setting.Bool("Frost Corners", true));
    public final Setting.Bool santaHat = add(new Setting.Bool("Santa Hat HUD", false));
    public final Setting.Bool bells = add(new Setting.Bool("Jingle Bells", false));
    public final Setting.Bool holly = add(new Setting.Bool("Holly Leaves", false));
    public final Setting.Bool candles = add(new Setting.Bool("Candles", false));
    public final Setting.Bool stockings = add(new Setting.Bool("Stockings", false));
    public final Setting.Bool fireworks = add(new Setting.Bool("Sparkles", true));
    public final Setting.Bool reindeer = add(new Setting.Bool("Reindeer Silhouette", false));
    public final Setting.Num density = add(new Setting.Num("Snow Density", 10, 120, 40, 5));
    public final Setting.Num speed = add(new Setting.Num("Fall Speed", 0.2, 3.0, 1.0, 0.1));
    public final Setting.Num intensity = add(new Setting.Num("Effect Intensity", 10, 100, 70, 5));

    private static final class Flake {
        float x, y, s, vy, vx, a;
    }

    private final List<Flake> flakes = new ArrayList<>();
    private final Random rng = new Random(42);
    private long last;

    private Christmas() {
        super("Christmas", Category.RENDER);
        showInHud = false;
    }

    public void render(MinecraftClient mc, DrawContext ctx) {
        if (!enabled || mc.options.hudHidden) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        float a = intensity.f() / 100f;
        long now = System.currentTimeMillis();
        float dt = Math.min(0.05f, (now - last) / 1000f);
        last = now;

        if (fallingSnow.get() || snow.get()) updateSnow(w, h, dt);
        if (fallingSnow.get() || snow.get()) drawSnow(ctx, w, h, a);
        if (twinkle.get()) drawTwinkle(ctx, w, h, a, now);
        if (garland.get()) drawGarland(ctx, w, a, now);
        if (frost.get()) drawFrost(ctx, w, h, a);
        if (stars.get()) drawStars(ctx, w, h, a, now);
        if (aurora.get()) drawAurora(ctx, w, h, a, now);
        if (cornerTrees.get()) drawTrees(ctx, w, h, a);
        if (candyCane.get()) drawCandy(ctx, w, h, a);
        if (sparklesOn()) drawSparkles(ctx, w, h, a, now);
        if (santaHat.get()) drawSantaHat(ctx, w, a);
        if (mistletoe.get()) drawMistletoe(ctx, w, a);
        if (gifts.get()) drawGifts(ctx, w, h, a);
        if (holly.get()) drawHolly(ctx, w, h, a);
        if (candles.get()) drawCandles(ctx, w, h, a, now);
        if (stockings.get()) drawStockings(ctx, w, h, a);
        if (bells.get()) drawBells(ctx, w, a, now);
        if (reindeer.get()) drawReindeer(ctx, w, h, a);
    }

    private boolean sparklesOn() { return fireworks.get(); }

    private void updateSnow(int w, int h, float dt) {
        int target = density.i();
        while (flakes.size() < target) {
            Flake f = new Flake();
            f.x = rng.nextFloat() * w;
            f.y = rng.nextFloat() * h;
            f.s = 1.2f + rng.nextFloat() * 2.8f;
            f.vy = 20f + rng.nextFloat() * 40f;
            f.vx = (rng.nextFloat() - 0.5f) * 18f;
            f.a = 0.4f + rng.nextFloat() * 0.6f;
            flakes.add(f);
        }
        while (flakes.size() > target) flakes.remove(flakes.size() - 1);
        float sp = (float) speed.get();
        for (Flake f : flakes) {
            f.y += f.vy * sp * dt;
            f.x += f.vx * sp * dt + (float) Math.sin(f.y * 0.02) * 8f * dt;
            if (f.y > h + 4) {
                f.y = -4;
                f.x = rng.nextFloat() * w;
            }
            if (f.x < -4) f.x = w + 4;
            if (f.x > w + 4) f.x = -4;
        }
    }

    private void drawSnow(DrawContext ctx, int w, int h, float a) {
        for (Flake f : flakes) {
            int col = Gfx.alpha(0xFFFFFFFF, a * f.a);
            int s = Math.max(1, Math.round(f.s));
            ctx.fill((int) f.x, (int) f.y, (int) f.x + s, (int) f.y + s, col);
        }
    }

    private void drawTwinkle(DrawContext ctx, int w, int h, float a, long now) {
        int[] colors = {0xFFFF4444, 0xFF44FF44, 0xFF4488FF, 0xFFFFFF44, 0xFFFF88FF};
        for (int i = 0; i < 18; i++) {
            float phase = (now / 400f + i * 1.7f) % (float) (Math.PI * 2);
            float pulse = 0.35f + 0.65f * (0.5f + 0.5f * (float) Math.sin(phase));
            int x = (i * 97 + 40) % Math.max(1, w - 8);
            int y = 4 + (i * 13) % 18;
            int c = Gfx.alpha(colors[i % colors.length], a * pulse);
            ctx.fill(x, y, x + 3, y + 3, c);
        }
    }

    private void drawGarland(DrawContext ctx, int w, float a, long now) {
        int[] colors = {0xFFE53935, 0xFF43A047, 0xFFFFD54F, 0xFF1E88E5};
        for (int x = 0; x < w; x += 14) {
            int yi = (int) (6 + 3 * Math.sin(x * 0.08 + now / 600.0));
            int c = Gfx.alpha(colors[(x / 14) % colors.length], a * 0.85f);
            ctx.fill(x, yi, x + 6, yi + 6, c);
        }
    }

    private void drawFrost(DrawContext ctx, int w, int h, float a) {
        int c = Gfx.alpha(0xFFB3E5FC, a * 0.25f);
        for (int i = 0; i < 40; i++) {
            ctx.fill(i, 0, i + 1, 40 - i, c);
            ctx.fill(w - 1 - i, 0, w - i, 40 - i, c);
            ctx.fill(i, h - (40 - i), i + 1, h, c);
            ctx.fill(w - 1 - i, h - (40 - i), w - i, h, c);
        }
    }

    private void drawStars(DrawContext ctx, int w, int h, float a, long now) {
        for (int i = 0; i < 12; i++) {
            float pulse = 0.4f + 0.6f * (0.5f + 0.5f * (float) Math.sin(now / 500.0 + i));
            int x = (i * 73 + 20) % Math.max(1, w - 10);
            int y = 30 + (i * 41) % Math.max(1, h - 60);
            int c = Gfx.alpha(0xFFFFD700, a * pulse * 0.7f);
            ctx.fill(x + 2, y, x + 4, y + 6, c);
            ctx.fill(x, y + 2, x + 6, y + 4, c);
        }
    }

    private void drawAurora(DrawContext ctx, int w, int h, float a, long now) {
        for (int y = 0; y < h / 3; y++) {
            float t = y / (float) (h / 3);
            float wave = (float) Math.sin(y * 0.05 + now / 800.0);
            int c = Gfx.alpha(Gfx.lerp(0xFF00C853, 0xFF00B0FF, 0.5f + 0.5f * wave), a * (1f - t) * 0.15f);
            ctx.fill(0, y, w, y + 1, c);
        }
    }

    private void drawTrees(DrawContext ctx, int w, int h, float a) {
        int c = Gfx.alpha(0xFF2E7D32, a * 0.8f);
        int trunk = Gfx.alpha(0xFF5D4037, a * 0.8f);
        for (int side = 0; side < 2; side++) {
            int bx = side == 0 ? 16 : w - 28;
            ctx.fill(bx + 4, h - 36, bx + 8, h - 20, trunk);
            for (int k = 0; k < 3; k++) {
                int top = h - 50 - k * 10;
                int half = 10 - k * 2;
                ctx.fill(bx + 6 - half, top, bx + 6 + half, top + 10, c);
            }
        }
    }

    private void drawCandy(DrawContext ctx, int w, int h, float a) {
        for (int y = 0; y < h; y += 12) {
            int c1 = Gfx.alpha(0xFFE53935, a * 0.5f);
            int c2 = Gfx.alpha(0xFFFFFFFF, a * 0.5f);
            ctx.fill(0, y, 4, y + 6, c1);
            ctx.fill(0, y + 6, 4, y + 12, c2);
            ctx.fill(w - 4, y, w, y + 6, c1);
            ctx.fill(w - 4, y + 6, w, y + 12, c2);
        }
    }

    private void drawSparkles(DrawContext ctx, int w, int h, float a, long now) {
        for (int i = 0; i < 20; i++) {
            float p = (float) ((now / 300.0 + i * 0.37) % 1.0);
            if (p > 0.35f) continue;
            float fade = 1f - p / 0.35f;
            int x = (i * 89 + (int) (now / 50)) % Math.max(1, w);
            int y = (i * 53 + (int) (now / 70)) % Math.max(1, h);
            int c = Gfx.alpha(0xFFFFFFFF, a * fade * 0.8f);
            ctx.fill(x, y, x + 2, y + 2, c);
        }
    }

    private void drawSantaHat(DrawContext ctx, int w, float a) {
        int red = Gfx.alpha(0xFFE53935, a);
        int white = Gfx.alpha(0xFFFFFFFF, a);
        int x = w - 36, y = 8;
        ctx.fill(x + 4, y + 10, x + 24, y + 18, red);
        ctx.fill(x + 8, y + 2, x + 20, y + 12, red);
        ctx.fill(x + 2, y + 16, x + 26, y + 20, white);
        ctx.fill(x + 18, y, x + 24, y + 6, white);
    }

    private void drawMistletoe(DrawContext ctx, int w, float a) {
        int leaf = Gfx.alpha(0xFF2E7D32, a);
        int berry = Gfx.alpha(0xFFE53935, a);
        int x = w / 2 - 8, y = 10;
        ctx.fill(x + 2, y, x + 14, y + 4, leaf);
        ctx.fill(x + 6, y + 4, x + 10, y + 12, leaf);
        ctx.fill(x + 4, y + 10, x + 7, y + 13, berry);
        ctx.fill(x + 9, y + 10, x + 12, y + 13, berry);
    }

    private void drawGifts(DrawContext ctx, int w, int h, float a) {
        int[] cols = {0xFFE53935, 0xFF1E88E5, 0xFFFFD54F};
        for (int i = 0; i < 3; i++) {
            int x = 20 + i * 22, y = h - 28;
            int c = Gfx.alpha(cols[i], a * 0.85f);
            int ribbon = Gfx.alpha(0xFFFFFFFF, a * 0.9f);
            ctx.fill(x, y, x + 14, y + 14, c);
            ctx.fill(x + 6, y, x + 8, y + 14, ribbon);
            ctx.fill(x, y + 6, x + 14, y + 8, ribbon);
        }
    }

    private void drawHolly(DrawContext ctx, int w, int h, float a) {
        int leaf = Gfx.alpha(0xFF1B5E20, a * 0.8f);
        int berry = Gfx.alpha(0xFFC62828, a);
        for (int i = 0; i < 4; i++) {
            int x = 8 + i * (w / 5);
            ctx.fill(x, h - 16, x + 10, h - 10, leaf);
            ctx.fill(x + 3, h - 12, x + 6, h - 9, berry);
        }
    }

    private void drawCandles(DrawContext ctx, int w, int h, float a, long now) {
        for (int i = 0; i < 3; i++) {
            int x = w / 2 - 30 + i * 30, y = h - 34;
            ctx.fill(x, y + 6, x + 6, y + 20, Gfx.alpha(0xFFFFF8E1, a));
            float flicker = 0.6f + 0.4f * (0.5f + 0.5f * (float) Math.sin(now / 120.0 + i));
            ctx.fill(x + 1, y, x + 5, y + 6, Gfx.alpha(0xFFFF9800, a * flicker));
        }
    }

    private void drawStockings(DrawContext ctx, int w, int h, float a) {
        int red = Gfx.alpha(0xFFC62828, a * 0.85f);
        int white = Gfx.alpha(0xFFFFFFFF, a);
        for (int i = 0; i < 3; i++) {
            int x = w - 70 + i * 20, y = 28;
            ctx.fill(x, y, x + 12, y + 18, red);
            ctx.fill(x, y, x + 12, y + 4, white);
            ctx.fill(x + 8, y + 14, x + 16, y + 20, red);
        }
    }

    private void drawBells(DrawContext ctx, int w, float a, long now) {
        int gold = Gfx.alpha(0xFFFFD54F, a * (0.7f + 0.3f * (0.5f + 0.5f * (float) Math.sin(now / 200.0))));
        ctx.fill(24, 22, 32, 30, gold);
        ctx.fill(w - 32, 22, w - 24, 30, gold);
    }

    private void drawReindeer(DrawContext ctx, int w, int h, float a) {
        int c = Gfx.alpha(0xFF5D4037, a * 0.7f);
        int x = w / 2 - 20, y = h - 40;
        ctx.fill(x + 8, y + 8, x + 28, y + 18, c);
        ctx.fill(x + 24, y + 2, x + 32, y + 12, c);
        ctx.fill(x + 4, y, x + 8, y + 10, c);
        ctx.fill(x + 30, y, x + 34, y + 10, c);
    }
}
