package dev.noon.util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.Desktop;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Free music search for ClickGUI – full tracks, no API key, no 30s previews.
 * Uses public Invidious + Piped instances so you can search real songs
 * (montagem, super funk, baile funk, etc.) and open the full track.
 */
public final class MusicPlayer {
    private MusicPlayer() {}

    public static final class Station {
        public final String name;
        public final String url;
        public final String tags;
        public final String videoId;

        public Station(String name, String url, String tags) {
            this(name, url, tags, null);
        }

        public Station(String name, String url, String tags, String videoId) {
            this.name = name;
            this.url = url;
            this.tags = tags == null ? "" : tags;
            this.videoId = videoId;
        }
    }

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(7))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    private static final String[] INVIDIOUS = {
            "https://invidious.fdn.fr",
            "https://inv.nadeko.net",
            "https://invidious.privacyredirect.com",
            "https://yewtu.be"
    };

    private static final String[] PIPED = {
            "https://pipedapi.kavin.rocks",
            "https://pipedapi.adminforge.de"
    };

    private static final String[] DEFAULT_QUERIES = {
            "montagem funk",
            "super funk montagem",
            "funk brasileiro",
            "montagem viral",
            "baile funk",
            "funk mandelão",
            "montagem phonk"
    };

    private static volatile List<Station> stations = new ArrayList<>();
    private static volatile Station current;
    private static final AtomicBoolean loading = new AtomicBoolean(false);
    private static volatile String status = "Search funk / montagem…";
    private static volatile String lastQuery = "montagem funk";

    public static List<Station> getStations() {
        if (stations.isEmpty() && !loading.get()) search(lastQuery);
        return stations;
    }

    public static Station current() { return current; }
    public static String status() { return status; }
    public static boolean isLoading() { return loading.get(); }
    public static String lastQuery() { return lastQuery; }

    public static void search(String query) {
        if (query == null || query.isBlank()) query = "montagem funk";
        lastQuery = query.trim();
        if (!loading.compareAndSet(false, true)) return;
        status = "Searching…";
        final String q = lastQuery;
        CompletableFuture.runAsync(() -> {
            try {
                List<Station> list = searchInvidious(q);
                if (list.isEmpty()) list = searchPiped(q);
                if (list.isEmpty()) {
                    list = new ArrayList<>();
                    String yt = "https://www.youtube.com/results?search_query=" +
                            URLEncoder.encode(q, StandardCharsets.UTF_8);
                    list.add(new Station(q + " – open results", yt, "search"));
                    status = "Open results";
                } else {
                    status = list.size() + " tracks";
                }
                stations = list;
            } catch (Exception e) {
                stations = new ArrayList<>();
                status = "Retry search";
            } finally {
                loading.set(false);
            }
        });
    }

    public static void refresh() {
        search(lastQuery);
    }

    public static void cycleDefaultQuery() {
        int idx = 0;
        for (int i = 0; i < DEFAULT_QUERIES.length; i++) {
            if (DEFAULT_QUERIES[i].equalsIgnoreCase(lastQuery)) {
                idx = (i + 1) % DEFAULT_QUERIES.length;
                break;
            }
        }
        search(DEFAULT_QUERIES[idx]);
    }

    private static List<Station> searchInvidious(String q) {
        List<Station> out = new ArrayList<>();
        String path = "/api/v1/search?type=video&q=" + URLEncoder.encode(q, StandardCharsets.UTF_8);
        for (String base : INVIDIOUS) {
            try {
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(base + path))
                        .header("User-Agent", "PocoClient/1.0")
                        .timeout(Duration.ofSeconds(9))
                        .GET()
                        .build();
                HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() != 200) continue;
                JsonArray arr = JsonParser.parseString(res.body()).getAsJsonArray();
                for (JsonElement el : arr) {
                    JsonObject o = el.getAsJsonObject();
                    String type = o.has("type") ? o.get("type").getAsString() : "";
                    if (!"video".equalsIgnoreCase(type)) continue;
                    String title = o.has("title") ? o.get("title").getAsString() : null;
                    String videoId = o.has("videoId") ? o.get("videoId").getAsString() : null;
                    if (title == null || videoId == null || videoId.isBlank()) continue;
                    String invWatch = base + "/watch?v=" + videoId;
                    out.add(new Station(title.trim(), invWatch, "youtube", videoId));
                    if (out.size() >= 18) break;
                }
                if (!out.isEmpty()) return out;
            } catch (Exception ignored) {}
        }
        return out;
    }

    private static List<Station> searchPiped(String q) {
        List<Station> out = new ArrayList<>();
        String path = "/search?q=" + URLEncoder.encode(q, StandardCharsets.UTF_8) + "&filter=videos";
        for (String base : PIPED) {
            try {
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(base + path))
                        .header("User-Agent", "PocoClient/1.0")
                        .timeout(Duration.ofSeconds(9))
                        .GET()
                        .build();
                HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() != 200) continue;
                JsonObject root = JsonParser.parseString(res.body()).getAsJsonObject();
                if (!root.has("items")) continue;
                JsonArray arr = root.getAsJsonArray("items");
                for (JsonElement el : arr) {
                    JsonObject o = el.getAsJsonObject();
                    String type = o.has("type") ? o.get("type").getAsString() : "";
                    if (!"stream".equalsIgnoreCase(type) && !"video".equalsIgnoreCase(type)) continue;
                    String title = o.has("title") ? o.get("title").getAsString() : null;
                    String url = o.has("url") ? o.get("url").getAsString() : null;
                    if (title == null) continue;
                    if (url != null && url.startsWith("/")) url = "https://www.youtube.com" + url;
                    if (url == null || url.isBlank()) continue;
                    out.add(new Station(title.trim(), url, "youtube"));
                    if (out.size() >= 18) break;
                }
                if (!out.isEmpty()) return out;
            } catch (Exception ignored) {}
        }
        return out;
    }

    public static boolean play(Station s) {
        if (s == null || s.url == null || s.url.isBlank()) return false;
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(URI.create(s.url));
                current = s;
                status = "Playing: " + truncate(s.name, 32);
                Sounds.click();
                return true;
            }
        } catch (Exception e) {
            status = "Could not open track";
        }
        return false;
    }

    public static void stop() {
        current = null;
        status = "Stopped";
        Sounds.click();
    }

    private static String truncate(String s, int n) {
        if (s == null) return "";
        return s.length() <= n ? s : s.substring(0, n - 1) + "…";
    }
}
