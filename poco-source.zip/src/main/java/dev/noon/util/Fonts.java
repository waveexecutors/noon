package dev.noon.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Custom resource-pack fonts used by Poco's interface. */
public final class Fonts {
    private Fonts() {}

    private static Identifier id(String name) {
        String path = (name == null || name.isBlank()) ? "ui" : name;
        return Identifier.of("noon", path);
    }

    public static Text text(String s, String font) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(id(font)));
    }

    public static int width(String s, String font) {
        return MinecraftClient.getInstance().textRenderer.getWidth(text(s, font));
    }

    public static void draw(DrawContext c, String font, String s, int x, int y, int color) {
        if ((color >>> 24) < 5 || s.isEmpty()) return;
        c.drawText(MinecraftClient.getInstance().textRenderer, text(s, font), x, y, color, false);
    }
}
