package dev.noon.util;

import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.text.TextCodecs;

/**
 * Smooth TrueType fonts (assets/noon/font/*.json). Text is built through the vanilla text codec with a "font" key, which keeps
 * this independent of the Style API. Fonts: ui (Garet Book 9), bold (Garet Heavy 9), m (Garet 13), l (Garet Heavy 22).
 */
public final class Fonts {
    private Fonts() {}

    private static final Map<String, Text> CACHE = new HashMap<>();

    public static Text text(String s, String font) {
        String key = font + "|" + s;
        Text t = CACHE.get(key);
        if (t == null) {
            JsonObject o = new JsonObject();
            o.addProperty("text", s);
            o.addProperty("font", "noon:" + font);
            t = TextCodecs.CODEC.parse(JsonOps.INSTANCE, o).result().orElseGet(() -> Text.literal(s));
            if (CACHE.size() > 2000) CACHE.clear();
            CACHE.put(key, t);
        }
        return t;
    }

    public static int width(String s, String font) {
        return MinecraftClient.getInstance().textRenderer.getWidth(text(s, font));
    }

    public static void draw(DrawContext c, String font, String s, int x, int y, int color) {
        if ((color >>> 24) < 5 || s.isEmpty()) return;
        c.drawText(MinecraftClient.getInstance().textRenderer, text(s, font), x, y, color, false);
    }
}
