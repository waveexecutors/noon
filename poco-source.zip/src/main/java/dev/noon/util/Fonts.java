package dev.noon.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Uses Minecraft's built-in font for all Poco interface text. */
public final class Fonts {
    private Fonts() {}

    public static Text text(String s, String ignoredFont) {
        return Text.literal(s);
    }

    public static int width(String s, String ignoredFont) {
        return MinecraftClient.getInstance().textRenderer.getWidth(s);
    }

    public static void draw(DrawContext c, String ignoredFont, String s, int x, int y, int color) {
        if ((color >>> 24) < 5 || s.isEmpty()) return;
        c.drawText(MinecraftClient.getInstance().textRenderer, s, x, y, color, false);
    }
}
