package dev.noon.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public final class Sounds {
    private Sounds() {}

    private static SoundEvent ev(Object o) {
        if (o instanceof RegistryEntry<?> e) return (SoundEvent) e.value();
        return (SoundEvent) o;
    }

    private static void play(Object sound, float pitch, float volume) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.getSoundManager() == null) return;
        mc.getSoundManager().play(PositionedSoundInstance.master(ev(sound), pitch, volume));
    }

    /** Whoosh used when the ClickGUI slides in/out. */
    public static void slide(boolean open) {
        play(KEYS[1], open ? 1.0f : 0.85f, 0.7f);
    }

    private static final SoundEvent[] KEYS = {
            SoundEvent.of(net.minecraft.util.Identifier.of("noon", "keypress1")),
            SoundEvent.of(net.minecraft.util.Identifier.of("noon", "keypress2")),
            SoundEvent.of(net.minecraft.util.Identifier.of("noon", "keypress3")),
            SoundEvent.of(net.minecraft.util.Identifier.of("noon", "keypress4"))};
    private static final SoundEvent NOTIFY = SoundEvent.of(net.minecraft.util.Identifier.of("noon", "notification"));
    private static final SoundEvent CHARGING = SoundEvent.of(net.minecraft.util.Identifier.of("noon", "charging"));

    /** Custom key click (random of 4 samples). */
    public static void click() {
        play(KEYS[java.util.concurrent.ThreadLocalRandom.current().nextInt(KEYS.length)], 1.0f, 0.8f);
    }

    public static void notification() {
        play(NOTIFY, 1.0f, 0.9f);
    }

    public static void charging() {
        play(CHARGING, 1.0f, 0.9f);
    }

    /** Loud two-tone siren step. Several stacked layers make it much louder than a single sound. */
    public static void alarmTone(int step, int layers) {
        boolean hi = (step & 1) == 0;
        for (int i = 0; i < Math.max(1, layers); i++) {
            play(SoundEvents.BLOCK_NOTE_BLOCK_PLING, hi ? 2.0f : 1.35f, 1.0f);
            play(SoundEvents.BLOCK_NOTE_BLOCK_BELL, hi ? 1.9f : 1.2f, 1.0f);
        }
        if (step == 0) {
            for (int i = 0; i < Math.max(1, layers); i++) {
                play(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 1.4f, 1.0f);
                play(SoundEvents.BLOCK_BELL_USE, 0.8f, 1.0f);
            }
        }
    }

    public static void ping() {
        notification();
    }

    public static void warn() {
        notification();
    }
}
