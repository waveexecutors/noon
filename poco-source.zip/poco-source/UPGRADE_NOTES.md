# Poco upgrade notes

## Implemented in this revision

- Native `.anim` loading/playback clock now supports pause/resume. Player model pose integration applies head/body/arms/legs transforms to the local player's render state only. Emote modules pause according to their walking/running settings.
- FakeLag now queues only `PlayerMoveC2SPacket` packets, supports configured delay and jitter, uses a bounded queue, flushes on disable and connection disconnect, and never delays keepalive/login/disconnect packets. The delayed send is re-dispatched onto the Minecraft client executor; it does not block the network or render thread.
- HandGlow now reuses per-thread coverage/distance scratch arrays and its color lookup table rather than allocating those full-frame buffers on every render.
- Main menu panel is smaller and darker, with low-cost animated ambient lighting and restrained hover/glow treatment. Existing menu actions and intro are retained.
- MusicPlayer uses an explicit JLayer audio device wrapper for MP3 playback, applies a live 1%-500% software gain with sample saturation, reports more useful playback errors, and applies supported gain to WAV playback. The Music tab includes a clickable/drag volume bar.

## Important limitations

- Emotes are client-side visuals. They are not sent to the server and are not visible to other players unless a compatible server-side protocol/mod is present. The animation mixin targets the local player's model only.
- FakeLag deliberately delays only outgoing movement packets. It is an experimental network-testing feature and can still cause rubber-banding, timeouts, or server corrections at high values. Critical packets are not buffered.
- MP3 amplification above 100% can clip; samples are saturated to prevent numeric overflow, but this is not a loudness limiter. Some audio backends on Android/Pojav may not expose desktop Java Sound controls; MP3 playback uses JLayer's audio backend.
- Build/runtime verification could not be completed in this environment because the Gradle wrapper distribution is not cached and `services.gradle.org` is unreachable. No claim of successful compilation is made.
