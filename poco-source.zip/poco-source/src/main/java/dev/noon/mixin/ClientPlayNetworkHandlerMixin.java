package dev.noon.mixin;

import dev.noon.module.combat.Velocity;
import dev.noon.module.smp.StaffRadar;
import net.minecraft.entity.EntityType;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void noon$velocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (Velocity.INSTANCE.enabled && mc.player != null && packet.getEntityId() == mc.player.getId()
                && java.util.concurrent.ThreadLocalRandom.current().nextInt(100) < Velocity.INSTANCE.chance.i()) {
            ci.cancel();
        }
    }

    /** A player entity spawning without a tab list entry = vanished / hidden player (vanilla would silently drop it). */
    @Inject(method = "onEntitySpawn", at = @At("HEAD"))
    private void noon$hiddenSpawn(EntitySpawnS2CPacket packet, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!StaffRadar.INSTANCE.enabled || !mc.isOnThread() || packet.getEntityType() != EntityType.PLAYER) return;
        ClientPlayNetworkHandler self = (ClientPlayNetworkHandler) (Object) this;
        if (self.getPlayerListEntry(packet.getUuid()) == null) {
            StaffRadar.onHiddenSpawn(packet.getUuid(), packet.getX(), packet.getY(), packet.getZ());
        }
    }

    /** Sounds that only a player could make (steps, hurt, eating...) with nobody visible next to the source. */
    @Inject(method = "onPlaySound", at = @At("HEAD"))
    private void noon$sound(PlaySoundS2CPacket packet, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!StaffRadar.INSTANCE.enabled || !mc.isOnThread()) return;
        StaffRadar.onSound(packet.getSound().getIdAsString(), packet.getX(), packet.getY(), packet.getZ());
    }
}
