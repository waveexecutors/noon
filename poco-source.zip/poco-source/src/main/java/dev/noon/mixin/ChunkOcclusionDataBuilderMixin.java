package dev.noon.mixin;

import dev.noon.module.render.XRay;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** X-Ray: stop opaque blocks from occluding chunk sections, so ores show from every side. */
@Mixin(targets = "net.minecraft.client.render.chunk.ChunkOcclusionDataBuilder")
public abstract class ChunkOcclusionDataBuilderMixin {
    @Inject(method = "markClosed", at = @At("HEAD"), cancellable = true)
    private void noon$noOcclusion(BlockPos pos, CallbackInfo ci) {
        if (XRay.INSTANCE.enabled) {
            ci.cancel();
        }
    }
}
