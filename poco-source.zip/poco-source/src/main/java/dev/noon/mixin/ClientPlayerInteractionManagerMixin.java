package dev.noon.mixin;

import dev.noon.module.player.FastBreak;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {
    @Shadow
    private int blockBreakingCooldown;

    @Shadow
    private float currentBreakingProgress;

    @Inject(method = "updateBlockBreakingProgress", at = @At("HEAD"))
    private void noon$noCooldown(BlockPos pos, Direction direction, CallbackInfoReturnable<Boolean> cir) {
        if (FastBreak.INSTANCE.enabled && FastBreak.INSTANCE.noCooldown.get()) {
            blockBreakingCooldown = 0;
        }
    }

    @Inject(method = "updateBlockBreakingProgress", at = @At("RETURN"))
    private void noon$boost(BlockPos pos, Direction direction, CallbackInfoReturnable<Boolean> cir) {
        if (FastBreak.INSTANCE.enabled && currentBreakingProgress > 0f && currentBreakingProgress < 1f) {
            currentBreakingProgress = Math.min(1f, currentBreakingProgress * FastBreak.INSTANCE.speed.f());
        }
    }
}
