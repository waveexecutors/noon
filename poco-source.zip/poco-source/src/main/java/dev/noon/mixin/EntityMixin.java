package dev.noon.mixin;

import dev.noon.module.combat.HitBox;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true)
    private void noon$hitbox(CallbackInfoReturnable<Float> cir) {
        if (HitBox.INSTANCE.enabled && (Object) this instanceof PlayerEntity
                && (Object) this != MinecraftClient.getInstance().player) {
            cir.setReturnValue(cir.getReturnValue() + HitBox.INSTANCE.expand.f());
        }
    }
}
