package dev.noon.mixin;

import dev.noon.module.client.GlassMenu;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.PressableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PressableWidget.class)
public abstract class PressableWidgetMixin {
    @Inject(method = "renderWidget", at = @At("HEAD"), cancellable = true)
    private void noon$glass(DrawContext context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        if (GlassMenu.active()) {
            GlassMenu.drawButton(context, (PressableWidget) (Object) this);
            ci.cancel();
        }
    }
}
