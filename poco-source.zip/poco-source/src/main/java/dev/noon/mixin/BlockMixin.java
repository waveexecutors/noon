package dev.noon.mixin;

import dev.noon.module.render.XRay;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Block.class)
public abstract class BlockMixin {
    @Inject(method = "shouldDrawSide", at = @At("RETURN"), cancellable = true)
    private static void noon$xray(BlockState state, BlockState neighbor, Direction side, CallbackInfoReturnable<Boolean> cir) {
        if (XRay.INSTANCE.enabled) {
            cir.setReturnValue(XRay.isVisible(state.getBlock()));
        }
    }
}
