package dev.noon.mixin;

import dev.noon.emote.EmoteAnimation;
import dev.noon.emote.EmoteController;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.model.ModelPart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Applies native Poco clip transforms to the vanilla player model pose. Client-side visual only. */
@Mixin(PlayerEntityModel.class)
public abstract class PlayerEntityModelMixin {
 @Shadow public ModelPart head; @Shadow public ModelPart body;
 @Shadow public ModelPart rightArm; @Shadow public ModelPart leftArm;
 @Shadow public ModelPart rightLeg; @Shadow public ModelPart leftLeg;
 @Inject(method="setAngles",at=@At("TAIL"),require=0)
 private void noon$applyEmote(PlayerEntityRenderState state, CallbackInfo ci){
  EmoteController c=EmoteController.get(); if(!EmoteRenderContext.isLocal(state)||!c.playing())return;
  boolean degrees=c.current().degrees();
  apply(head,c.sample("head"),degrees); apply(body,c.sample("body"),degrees);
  apply(rightArm,c.sample("rightArm"),degrees); apply(leftArm,c.sample("leftArm"),degrees);
  apply(rightLeg,c.sample("rightLeg"),degrees); apply(leftLeg,c.sample("leftLeg"),degrees);
 }
 private static void apply(ModelPart p,EmoteAnimation.Transform t,boolean degrees){
  double k=degrees?Math.PI/180.0:1.0; p.pitch+=(float)(t.pitch()*k);p.yaw+=(float)(t.yaw()*k);p.roll+=(float)(t.roll()*k);
  p.pivotX+=(float)t.x();p.pivotY+=(float)t.y();p.pivotZ+=(float)t.z();
 }
}
