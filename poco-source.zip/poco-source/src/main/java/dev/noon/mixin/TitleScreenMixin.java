package dev.noon.mixin;

import dev.noon.gui.PocoMenu;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Keeps the real TitleScreen but draws the Poco menu instead of its widgets. */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
    protected TitleScreenMixin(Text title) {
        super(title);
    }

    @Inject(method = "init", at = @At("RETURN"))
    private void noon$clear(CallbackInfo ci) {
        this.clearChildren(); // drop vanilla buttons: the Poco menu handles its own clicks
    }

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void noon$render(DrawContext context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        PocoMenu.render((TitleScreen) (Object) this, context, mouseX, mouseY);
        ci.cancel();
    }
}
