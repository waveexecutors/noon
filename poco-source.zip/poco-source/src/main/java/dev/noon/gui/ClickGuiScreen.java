package dev.noon.gui;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.ModuleManager;
import dev.noon.module.Setting;
import dev.noon.util.Anim;
import dev.noon.util.Gfx;
import dev.noon.util.Keys;
import dev.noon.util.MusicPlayer;
import dev.noon.util.Sounds;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Poco ClickGUI. Tabs on the left, module pills with inline settings on the right, search on top.
 * Input is polled straight from GLFW (no Screen input signatures).
 * Left click toggles, right click (or the chevron) expands settings, scroll wheel / Up / Down scrolls.
 */
public class ClickGuiScreen extends Screen {
    // palette (Poco: charcoal + signal yellow)
    private static final int BG = 0xFF121212, EDGE = 0xFF262626, PILL = 0xFF1C1C1C, PILL_HOVER = 0xFF252525, CARD = 0xFF171717;
    private static final int TEXT = 0xFFF2F2F2, DIM = 0xFF8B8B8B, FAINT = 0xFF555555, ACC = 0xFFFFCB00, ACC_DIM = 0xFF2B2406, ON_ACC = 0xFF111111;

    // Base design size (kept small). Actual window scales to a fraction of the screen so it auto-fits any resolution.
    private static final int BASE_W = 520, BASE_H = 340, TOP = 46, TAB_W = 128, TAB_H = 26, ROW_H = 26, SET_H = 22, CHIP_H = 16, CHIP_GAP = 4, GAP = 5;

    private static final net.minecraft.util.Identifier LOGO = net.minecraft.util.Identifier.of("noon", "textures/gui/poco.png");

    private final Anim open = new Anim();
    private final Anim scrollAnim = new Anim();
    private final Anim tabBar = new Anim();
    private final Anim tabScrollAnim = new Anim();
    private final Anim[] tabHover = new Anim[Category.values().length];

    private boolean closing;
    private Category selected = Category.COMBAT;
    private long switchTime = System.nanoTime();
    private float scrollTarget;
    private int maxScroll;
    private float tabScrollTarget;
    private int maxTabScroll;
    private boolean prevL, prevR;
    private Setting.Num dragging;
    private int dragX, dragW;
    private Module binding;
    private Setting.Mode hoverMode;
    private final boolean[] prevKeys = new boolean[GLFW.GLFW_KEY_LAST + 1];

    private boolean searching;
    private final StringBuilder query = new StringBuilder();
    private int musicIndex;
    private int musicPx = -1, musicPy = -1;
    private boolean musicDrag;
    private int musicDragOx, musicDragOy;
    private boolean musicSearch;
    private final StringBuilder musicQuery = new StringBuilder();
    private int lastGuiX, lastGuiY, lastTabW, lastTabTop, lastTabBottom;

    public boolean isBinding() {
        return binding != null || searching || musicSearch;
    }

    public ClickGuiScreen() {
        super(Text.literal("Poco"));
        for (int i = 0; i < tabHover.length; i++) tabHover[i] = new Anim();
        tabBar.v = selected.ordinal() * TAB_H;
        Sounds.slide(true);
        MusicPlayer.refresh();
    }

    public void requestClose() {
        if (!closing) {
            closing = true;
            Sounds.slide(false);
        }
    }

    @Override
    public void close() {
        if (binding != null) {
            binding = null;
            return;
        }
        if (searching) {
            searching = false;
            return;
        }
        requestClose();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // vanilla mouse wheel (no @Override on purpose: arrow keys also scroll if the signature ever changes)
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (hoverMode != null) {
            if (verticalAmount > 0) hoverMode.prev();
            else hoverMode.next();
            Sounds.click();
            return true;
        }
        float amount = (float) verticalAmount * 28f;
        // Prefer tab list when cursor is over the left tab strip
        if (mouseX >= lastGuiX + 4 && mouseX < lastGuiX + lastTabW
                && mouseY >= lastTabTop && mouseY < lastTabBottom && maxTabScroll > 0) {
            tabScrollTarget -= amount;
        } else {
            scrollTarget -= amount;
        }
        return true;
    }

    // ---- small drawing helpers ----------------------------------------------------------------

    /** Pill switch, t = 0 off .. 1 on. */
    private static void toggle(DrawContext c, int x, int y, int w, int h, float t, float a) {
        Gfx.rrect(c, x, y, w, h, h / 2, Gfx.alpha(Gfx.lerp(0xFF3A3A3A, ACC, t), a));
        int k = h - 4;
        int kx = x + 2 + Math.round((w - k - 4) * t);
        Gfx.rrect(c, kx, y + 2, k, k, k / 2, Gfx.alpha(Gfx.lerp(0xFFB5B5B5, ON_ACC, t), a));
    }

    /** Soft quarter-circle used as a corner accent (same motif as the Poco main menu). */
    private static void disc(DrawContext c, int cx, int cy, int r, float a) {
        for (int dy = -r; dy <= r; dy += 2) {
            int half = (int) Math.sqrt((double) r * r - (double) dy * dy);
            float t = (dy + r) / (2f * r);
            c.fill(cx - half, cy + dy, cx + half, cy + dy + 2, Gfx.alpha(Gfx.lerp(0xFFE9B340, 0xFF9A6E22, t), a));
        }
    }

    private static String fmt(Setting.Num n) {
        if (n.step >= 1) return Integer.toString(n.i());
        return String.format(Locale.ROOT, "%.2f", n.get());
    }

    private static boolean chips(Setting s) {
        return s instanceof Setting.Mode md && md.modes.length > 3;
    }

    private static int chipRows(Setting.Mode md, int availW) {
        int rows = 1, x = 0;
        for (String n : md.modes) {
            int w = Gfx.uiW(n) + 16;
            if (x > 0 && x + w > availW) {
                rows++;
                x = 0;
            }
            x += w + CHIP_GAP;
        }
        return rows;
    }

    private static int rowHeight(Setting s, int cw) {
        if (chips(s)) return 18 + chipRows((Setting.Mode) s, cw - 48) * (CHIP_H + CHIP_GAP) + 2;
        return SET_H;
    }

    private static int settingsHeight(Module m, int cw) {
        int h = SET_H + 10;
        for (Setting s : m.settings) h += rowHeight(s, cw);
        return h;
    }

    private List<Module> visible() {
        if (selected == Category.MUSIC) return List.of();
        if (query.length() == 0) return ModuleManager.byCategory(selected);
        String q = query.toString().toLowerCase(Locale.ROOT);
        List<Module> out = new ArrayList<>();
        for (Module m : ModuleManager.all()) if (m.name.toLowerCase(Locale.ROOT).contains(q)) out.add(m);
        return out;
    }

    private void typeKeys(long handle) {
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            boolean d = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
            boolean edge = d && !prevKeys[k];
            prevKeys[k] = d;
            if (!edge) continue;
            if (k == GLFW.GLFW_KEY_BACKSPACE) {
                if (query.length() > 0) query.setLength(query.length() - 1);
                Sounds.click();
            } else if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE) {
                searching = false;
            } else if ((k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z) && query.length() < 24) {
                query.append((char) ('a' + (k - GLFW.GLFW_KEY_A)));
                scrollTarget = 0;
                Sounds.click();
            } else if ((k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9) && query.length() < 24) {
                query.append((char) ('0' + (k - GLFW.GLFW_KEY_0)));
                Sounds.click();
            } else if (k == GLFW.GLFW_KEY_SPACE && query.length() < 24) {
                query.append(' ');
            }
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        float openRaw = open.to(closing ? 0f : 1f, closing ? 16f : 14f);
        float o = Anim.clamp01(openRaw);
        if (closing && openRaw <= 0.03f) {
            ModuleManager.save();
            this.client.setScreen(null);
            return;
        }
        boolean ready = !closing && openRaw > 0.8f;

        // ---- input (polled) ----
        long handle = this.client.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean clickL = l && !prevL && ready, clickR = r && !prevR && ready;
        prevL = l;
        prevR = r;
        if (!l || !ready) dragging = null;
        if (!searching) {
            if (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_DOWN) == GLFW.GLFW_PRESS) scrollTarget += 7f;
            if (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_UP) == GLFW.GLFW_PRESS) scrollTarget -= 7f;
        }

        if (binding != null) {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                boolean d = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
                if (d && !prevKeys[k] && k != GLFW.GLFW_KEY_ESCAPE) {
                    binding.key = (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) ? -1 : k;
                    binding = null;
                    Sounds.click();
                }
                prevKeys[k] = d;
                if (binding == null) break;
            }
        } else if (searching) {
            typeKeys(handle);
        } else {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) prevKeys[k] = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
        }

        // ---- window (auto-size to resolution, kept a bit smaller) ----
        // Target ~55% of width / ~58% of height, clamped so it never exceeds the design base on small screens.
        int ww = Math.min(Math.max(380, (int) (this.width * 0.52f)), this.width - 24);
        int hh = Math.min(Math.max(280, (int) (this.height * 0.55f)), this.height - 24);
        // Prefer the smaller base proportions on very large displays so the GUI stays compact.
        if (ww > BASE_W * 1.35f) ww = (int) (BASE_W * 1.35f);
        if (hh > BASE_H * 1.35f) hh = (int) (BASE_H * 1.35f);
        int x = (this.width - ww) / 2;
        int y = (this.height - hh) / 2 + Math.round((1f - o) * 10f);

        ctx.fill(0, 0, this.width, this.height, Gfx.alpha(0xA0000000, o));
        Gfx.rrect(ctx, x - 1, y - 1, ww + 2, hh + 2, 13, Gfx.alpha(EDGE, o));
        Gfx.rrect(ctx, x, y, ww, hh, 12, Gfx.alpha(BG, o));
        ctx.enableScissor(x, y, x + ww, y + hh);
        disc(ctx, x - 16, y - 18, 80, o * 0.16f);
        disc(ctx, x + ww + 16, y + hh + 24, 100, o * 0.13f);
        ctx.disableScissor();

        // ---- header ----
        int lgW = Math.max(42, Math.min(52, ww / 12)), lgH = Math.round(lgW * 212f / 700f);
        ctx.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED, LOGO, x + 16, y + 14, 0f, 0f, lgW, lgH, 700, 212, 700, 212);
        if (o < 0.99f) ctx.fill(x + 16, y + 14, x + 16 + lgW, y + 14 + lgH, Gfx.alpha(BG, 1f - o));

        int sbW = Math.min(160, ww / 3), sbH = 20, sbX = x + ww - sbW - 14, sbY = y + 12;
        boolean sbHov = ready && mx >= sbX && mx < sbX + sbW && my >= sbY && my < sbY + sbH;
        Gfx.rrect(ctx, sbX, sbY, sbW, sbH, 10, Gfx.alpha(searching ? ACC : EDGE, o));
        Gfx.rrect(ctx, sbX + 1, sbY + 1, sbW - 2, sbH - 2, 9, Gfx.alpha(sbHov ? PILL_HOVER : PILL, o));
        String shown = query.length() == 0 && !searching ? "Search" : query.toString() + (searching && (System.currentTimeMillis() / 500) % 2 == 0 ? "|" : "");
        Gfx.ui(ctx, shown, sbX + 10, sbY + 6, Gfx.alpha(query.length() == 0 && !searching ? FAINT : TEXT, o));
        if (clickL && sbHov) {
            searching = true;
            binding = null;
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) prevKeys[k] = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
        } else if (clickL && searching && !sbHov) {
            searching = false;
        }

        // ---- tabs (scrollable) ----
        Category[] cats = Category.values();
        int tabAreaTop = y + TOP + 4;
        int tabAreaBottom = y + hh - 12;
        int tabAreaH = tabAreaBottom - tabAreaTop;
        int tabTotalH = cats.length * (TAB_H + 3);
        maxTabScroll = Math.max(0, tabTotalH - tabAreaH);
        tabScrollTarget = Math.max(0f, Math.min(tabScrollTarget, maxTabScroll));
        float tabScroll = tabScrollAnim.to(tabScrollTarget, 18f);

        lastGuiX = x;
        lastGuiY = y;
        lastTabW = TAB_W;
        lastTabTop = tabAreaTop;
        lastTabBottom = tabAreaBottom;

        int tx = x + 10, tw = TAB_W - 16;
        float bar = tabBar.to(selected.ordinal() * (TAB_H + 3), 16f);

        ctx.enableScissor(x + 6, tabAreaTop, x + TAB_W, tabAreaBottom);
        if (query.length() == 0) {
            int barY = tabAreaTop + Math.round(bar - tabScroll);
            if (barY + TAB_H > tabAreaTop && barY < tabAreaBottom) {
                Gfx.rrect(ctx, tx, barY, tw, TAB_H, 8, Gfx.alpha(ACC, o));
            }
        }
        for (int i = 0; i < cats.length; i++) {
            Category c = cats[i];
            int ry = tabAreaTop + i * (TAB_H + 3) - Math.round(tabScroll);
            if (ry + TAB_H < tabAreaTop || ry > tabAreaBottom) continue;
            boolean hov = ready && mx >= tx && mx < tx + tw && my >= Math.max(ry, tabAreaTop) && my < Math.min(ry + TAB_H, tabAreaBottom);
            float hv = tabHover[i].to(hov ? 1f : 0f, 14f);
            boolean sel = selected == c && query.length() == 0;
            if (!sel && hv > 0.01f) Gfx.rrect(ctx, tx, ry, tw, TAB_H, 8, Gfx.alpha(PILL, o * hv));
            int col = sel ? ON_ACC : Gfx.lerp(DIM, TEXT, hv);
            Gfx.ui(ctx, c.label, tx + 10, ry + (TAB_H - 8) / 2, Gfx.alpha(col, o));
            int cnt = 0;
            for (Module m : ModuleManager.byCategory(c)) if (m.enabled) cnt++;
            if (cnt > 0) {
                String cs = Integer.toString(cnt);
                Gfx.ui(ctx, cs, tx + tw - 10 - Gfx.uiW(cs), ry + (TAB_H - 8) / 2, Gfx.alpha(sel ? ON_ACC : ACC, o));
            }
            if (clickL && hov && (selected != c || query.length() > 0)) {
                selected = c;
                query.setLength(0);
                searching = false;
                scrollTarget = 0;
                scrollAnim.set(0);
                switchTime = System.nanoTime();
                Sounds.click();
            }
        }
        ctx.disableScissor();

        // thin scrollbar for tabs when needed
        if (maxTabScroll > 0) {
            int trackH = tabAreaH - 4;
            int thumbH = Math.max(14, Math.round(trackH * (tabAreaH / (float) (tabAreaH + maxTabScroll))));
            int thumbY = tabAreaTop + 2 + Math.round((trackH - thumbH) * (tabScroll / maxTabScroll));
            Gfx.rrect(ctx, x + TAB_W - 5, thumbY, 2, thumbH, 1, Gfx.alpha(0xFF3F3F3F, o));
        }

        // ---- content ----
        int cx = x + TAB_W + 4, cw = ww - TAB_W - 4 - 12;
        int viewTop = y + TOP, viewBottom = y + hh - 12, viewH = viewBottom - viewTop;
        List<Module> mods = visible();

        scrollTarget = Math.max(0f, Math.min(scrollTarget, maxScroll));
        float scroll = scrollAnim.to(scrollTarget, 18f);
        boolean mouseInView = my >= viewTop && my < viewBottom && mx >= cx && mx < cx + cw;
        boolean mouseInTabs = mx >= x + 6 && mx < x + TAB_W && my >= tabAreaTop && my < tabAreaBottom;
        float sinceSwitch = (System.nanoTime() - switchTime) / 1_000_000_000f;

        ctx.enableScissor(cx - 2, viewTop, cx + cw + 2, viewBottom);
        hoverMode = null;
        int yy = viewTop - Math.round(scroll);
        int startY = yy;
        int rw = cw - 6;

        // ---- Music tab content ----
        if (selected == Category.MUSIC && query.length() == 0) {
            drawMusicTab(ctx, cx, viewTop, cw, viewH, mx, my, clickL, o, ready);
            yy = viewTop + 220;
        } else if (mods.isEmpty()) {
            Gfx.ui(ctx, "Nothing found", cx + 8, viewTop + 8, Gfx.alpha(DIM, o));
        }

        for (int mi = 0; mi < mods.size(); mi++) {
            Module m = mods.get(mi);
            float ex = Math.max(0f, m.expand.to(m.expanded ? 1f : 0f, 16f));
            int setH = settingsHeight(m, rw);
            int cardH = ROW_H + Math.round(setH * ex);
            float ap = Anim.easeOutCubic(sinceSwitch * 5f - mi * 0.04f);
            float co = o * ap;

            if (yy > viewBottom || yy + cardH < viewTop) {
                yy += cardH + GAP;
                continue;
            }

            boolean hov = mouseInView && my >= yy && my < yy + ROW_H;
            float hv = m.hover.to(hov ? 1f : 0f, 18f);
            float tg = m.toggle.to(m.enabled ? 1f : 0f, 18f);

            // pill: yellow edge when on
            int edge = Gfx.lerp(0xFF2A2A2A, ACC, tg);
            Gfx.rrect(ctx, cx, yy, rw, ROW_H, 8, Gfx.alpha(edge, co));
            Gfx.rrect(ctx, cx + 1, yy + 1, rw - 2, ROW_H - 2, 7, Gfx.alpha(Gfx.lerp(Gfx.lerp(PILL, PILL_HOVER, hv), ACC_DIM, tg * 0.8f), co));
            int ty = yy + (ROW_H - 8) / 2;
            Gfx.ui(ctx, m.name, cx + 12, ty, Gfx.alpha(Gfx.lerp(0xFFC9C9C9, ACC, tg), co));
            if (m.key >= 0) Gfx.ui(ctx, Keys.name(m.key), cx + 12 + Gfx.uiW(m.name) + 6, ty, Gfx.alpha(FAINT, co));

            int sw = 26, sh = 14, swX = cx + rw - sw - 10, swY = yy + (ROW_H - sh) / 2;
            toggle(ctx, swX, swY, sw, sh, tg, co);
            if (!m.settings.isEmpty()) {
                String ch = m.expanded ? "-" : "+";
                Gfx.ui(ctx, ch, swX - 16, ty, Gfx.alpha(Gfx.lerp(FAINT, TEXT, hv), co));
            }

            if (hov && clickL) {
                if (mx >= swX - 26 && mx < swX - 6 && !m.settings.isEmpty()) m.expanded = !m.expanded;
                else m.toggle();
                Sounds.click();
            } else if (hov && clickR) {
                m.expanded = !m.expanded;
                Sounds.click();
            }

            if (ex > 0.02f) {
                int top = yy + ROW_H + 3;
                Gfx.rrect(ctx, cx + 6, top, rw - 12, Math.max(0, yy + cardH - top), 8, Gfx.alpha(CARD, co));
                int sy = top + 4;
                boolean interactive = ex > 0.9f && mouseInView;
                float sa = co * Math.min(1f, ex * 1.4f);
                int lx = cx + 16, rx = cx + rw - 16;

                if (sy + SET_H <= yy + cardH) {
                    boolean kHov = interactive && my >= sy && my < sy + SET_H;
                    Gfx.ui(ctx, "Keybind", lx, sy + (SET_H - 8) / 2, Gfx.alpha(DIM, sa));
                    String kn = binding == m ? "press a key" : Keys.name(m.key);
                    int kw = Gfx.uiW(kn) + 16;
                    int kx = rx - kw;
                    Gfx.rrect(ctx, kx, sy + 2, kw, SET_H - 4, (SET_H - 4) / 2, Gfx.alpha(binding == m ? ACC : EDGE, sa));
                    Gfx.rrect(ctx, kx + 1, sy + 3, kw - 2, SET_H - 6, (SET_H - 6) / 2, Gfx.alpha(PILL, sa));
                    Gfx.ui(ctx, kn, kx + 8, sy + (SET_H - 8) / 2, Gfx.alpha(binding == m ? ACC : TEXT, sa));
                    if (kHov && clickL && mx >= kx - 4) {
                        binding = binding == m ? null : m;
                        searching = false;
                        if (binding != null) {
                            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) prevKeys[k] = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
                        }
                        Sounds.click();
                    }
                    sy += SET_H;
                }

                for (Setting st : m.settings) {
                    int rh = rowHeight(st, rw);
                    if (sy + rh > yy + cardH) break;
                    boolean rowHov = interactive && my >= sy && my < sy + rh;
                    Gfx.ui(ctx, st.name, lx, sy + (SET_H - 8) / 2, Gfx.alpha(rowHov ? TEXT : DIM, sa));

                    if (st instanceof Setting.Bool b) {
                        toggle(ctx, rx - 24, sy + (SET_H - 12) / 2, 24, 12, b.anim.to(b.value ? 1f : 0f, 16f), sa);
                        if (rowHov && clickL) {
                            b.value = !b.value;
                            Sounds.click();
                        }
                    } else if (st instanceof Setting.Num n) {
                        String val = fmt(n);
                        int vw = Math.max(28, Gfx.uiW(val));
                        int tw2 = Math.min(120, rw / 3);
                        int tx2 = rx - vw - 10 - tw2;
                        int ty2 = sy + SET_H / 2;
                        double range = n.max - n.min;
                        double frac = range > 0 ? (n.get() - n.min) / range : 0.0;
                        float fa = n.anim.to((float) frac, 22f);
                        int fillW = Math.round(tw2 * fa);
                        Gfx.rrect(ctx, tx2, ty2 - 2, tw2, 3, 1, Gfx.alpha(0xFF333333, sa));
                        if (fillW > 1) Gfx.rrect(ctx, tx2, ty2 - 2, fillW, 3, 1, Gfx.alpha(ACC, sa));
                        boolean active = dragging == n;
                        int kr = active ? 5 : 4;
                        Gfx.rrect(ctx, tx2 + fillW - kr, ty2 - kr, kr * 2, kr * 2, kr, Gfx.alpha(0xFFFFFFFF, sa));
                        Gfx.ui(ctx, val, rx - Gfx.uiW(val), sy + (SET_H - 8) / 2, Gfx.alpha(TEXT, sa));
                        if (interactive && clickL && mx >= tx2 - 6 && mx < tx2 + tw2 + 6 && my >= sy && my < sy + SET_H) {
                            dragging = n;
                            dragX = tx2;
                            dragW = tw2;
                        }
                    } else if (st instanceof Setting.Mode md && chips(md)) {
                        int chx = lx, chy = sy + 18, availW = rw - 48;
                        for (int ci = 0; ci < md.modes.length; ci++) {
                            int chw = Gfx.uiW(md.modes[ci]) + 12;
                            if (chx > lx && chx + chw > lx + availW) {
                                chx = lx;
                                chy += CHIP_H + CHIP_GAP;
                            }
                            boolean sel = md.index == ci;
                            boolean chipHov = interactive && mx >= chx && mx < chx + chw && my >= chy && my < chy + CHIP_H;
                            Gfx.rrect(ctx, chx, chy, chw, CHIP_H, CHIP_H / 2, Gfx.alpha(sel ? ACC : (chipHov ? 0xFF2C2C2C : 0xFF222222), sa));
                            Gfx.ui(ctx, md.modes[ci], chx + 6, chy + 4, Gfx.alpha(sel ? ON_ACC : (chipHov ? TEXT : DIM), sa));
                            if (chipHov && clickL && !sel) {
                                md.index = ci;
                                Sounds.click();
                            }
                            chx += chw + CHIP_GAP;
                        }
                    } else if (st instanceof Setting.Mode md) {
                        String val = md.get();
                        int pw = Gfx.uiW(val) + 28;
                        int px = rx - pw;
                        Gfx.rrect(ctx, px, sy + 2, pw, SET_H - 4, (SET_H - 4) / 2, Gfx.alpha(rowHov ? 0xFF2C2C2C : 0xFF222222, sa));
                        Gfx.ui(ctx, "<", px + 7, sy + (SET_H - 8) / 2, Gfx.alpha(FAINT, sa));
                        Gfx.ui(ctx, ">", px + pw - 7 - Gfx.uiW(">"), sy + (SET_H - 8) / 2, Gfx.alpha(FAINT, sa));
                        Gfx.ui(ctx, val, px + (pw - Gfx.uiW(val)) / 2, sy + (SET_H - 8) / 2, Gfx.alpha(ACC, sa));
                        if (rowHov) hoverMode = md;
                        if (rowHov && clickL) {
                            md.next();
                            Sounds.click();
                        } else if (rowHov && clickR) {
                            md.prev();
                            Sounds.click();
                        }
                    }
                    sy += rh;
                }
            }
            yy += cardH + GAP;
        }
        ctx.disableScissor();

        maxScroll = Math.max(0, (yy - startY) - viewH);

        if (maxScroll > 0) {
            int trackH = viewH - 6;
            int thumbH = Math.max(14, Math.round(trackH * (viewH / (float) (viewH + maxScroll))));
            int thumbY = viewTop + 3 + Math.round((trackH - thumbH) * (scroll / maxScroll));
            Gfx.rrect(ctx, cx + cw + 2, thumbY, 2, thumbH, 1, Gfx.alpha(0xFF3F3F3F, o));
        }

        if (dragging != null && l) {
            double f = (mx - dragX) / (double) dragW;
            f = Math.max(0.0, Math.min(1.0, f));
            dragging.set(dragging.min + f * (dragging.max - dragging.min));
        }

        Notify.render(ctx);
    }

    /** Full Music tab: local MP3 list, filter, reload, play controls. */
    private void drawMusicTab(DrawContext ctx, int cx, int viewTop, int cw, int viewH, int mx, int my, boolean clickL, float o, boolean ready) {
        long handle = client.getWindow().getHandle();
        int pad = 8;
        int y = viewTop + 6;

        Gfx.ui(ctx, "Local Music", cx + pad, y, Gfx.alpha(TEXT, o));
        y += 14;
        Path folder = MusicPlayer.musicFolder();
        String folderHint = folder != null ? folder.toString() : "poco-music";
        if (folderHint.length() > 48) folderHint = "…" + folderHint.substring(folderHint.length() - 46);
        Gfx.ui(ctx, folderHint, cx + pad, y, Gfx.alpha(DIM, o));
        y += 16;

        // filter box
        int sx = cx + pad, sy = y, swb = cw - pad * 2 - 70, shb = 16;
        boolean sHov = ready && mx >= sx && mx < sx + swb && my >= sy && my < sy + shb;
        Gfx.rrect(ctx, sx, sy, swb, shb, 6, Gfx.alpha(musicSearch ? ACC : EDGE, o));
        Gfx.rrect(ctx, sx + 1, sy + 1, swb - 2, shb - 2, 5, Gfx.alpha(PILL, o));
        String mq = musicQuery.length() == 0 && !musicSearch ? "Filter tracks…" : musicQuery.toString() + (musicSearch && (System.currentTimeMillis() / 500) % 2 == 0 ? "|" : "");
        Gfx.ui(ctx, mq.length() > 28 ? mq.substring(0, 26) + "…" : mq, sx + 6, sy + 4, Gfx.alpha(musicQuery.length() == 0 && !musicSearch ? FAINT : TEXT, o));
        if (clickL && sHov) {
            musicSearch = true;
            searching = false;
            binding = null;
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) prevKeys[k] = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
        } else if (clickL && musicSearch && !sHov) {
            musicSearch = false;
            MusicPlayer.setFilter(musicQuery.toString());
        }

        // Reload button
        int rbx = sx + swb + 6, rbw = 60;
        boolean rHov = ready && mx >= rbx && mx < rbx + rbw && my >= sy && my < sy + shb;
        Gfx.rrect(ctx, rbx, sy, rbw, shb, 6, Gfx.alpha(rHov ? ACC : EDGE, o));
        Gfx.ui(ctx, "Reload", rbx + (rbw - Gfx.uiW("Reload")) / 2, sy + 4, Gfx.alpha(rHov ? ON_ACC : TEXT, o));
        if (clickL && rHov) {
            MusicPlayer.reload();
            musicIndex = 0;
            Sounds.click();
        }
        y += 22;

        // status + current
        Gfx.ui(ctx, MusicPlayer.status(), cx + pad, y, Gfx.alpha(DIM, o));
        y += 14;
        MusicPlayer.Station cur = MusicPlayer.current();
        if (cur != null) {
            String now = "Now: " + cur.name;
            if (now.length() > 40) now = now.substring(0, 38) + "…";
            Gfx.ui(ctx, now, cx + pad, y, Gfx.alpha(ACC, o));
        }
        y += 16;

        // controls
        int bw = 28, gap = 6;
        String[] icons = {"Prev", "Play", "Next", "Stop"};
        int totalW = icons.length * bw + (icons.length - 1) * gap;
        int bx = cx + pad;
        for (int i = 0; i < icons.length; i++) {
            int bx0 = bx + i * (bw + gap);
            boolean hov = ready && mx >= bx0 && mx < bx0 + bw && my >= y && my < y + 16;
            Gfx.rrect(ctx, bx0, y, bw, 16, 5, Gfx.alpha(hov ? ACC : EDGE, o));
            Gfx.ui(ctx, icons[i], bx0 + (bw - Gfx.uiW(icons[i])) / 2, y + 4, Gfx.alpha(hov ? ON_ACC : TEXT, o));
            if (clickL && hov) {
                List<MusicPlayer.Station> stations = MusicPlayer.getStations();
                if (musicIndex >= stations.size()) musicIndex = 0;
                MusicPlayer.Station st = stations.isEmpty() ? null : stations.get(musicIndex);
                if (i == 0) {
                    if (!stations.isEmpty()) musicIndex = (musicIndex - 1 + stations.size()) % stations.size();
                    Sounds.click();
                } else if (i == 1) {
                    if (st != null) MusicPlayer.play(st);
                    else MusicPlayer.reload();
                } else if (i == 2) {
                    if (!stations.isEmpty()) musicIndex = (musicIndex + 1) % stations.size();
                    Sounds.click();
                } else {
                    MusicPlayer.stop();
                }
            }
        }
        y += 24;

        // track list
        List<MusicPlayer.Station> stations = MusicPlayer.getStations();
        if (musicIndex >= stations.size()) musicIndex = Math.max(0, stations.size() - 1);
        int listTop = y;
        int rowH = 18;
        for (int i = 0; i < stations.size(); i++) {
            MusicPlayer.Station s = stations.get(i);
            int ry = listTop + i * rowH;
            if (ry + rowH > viewTop + viewH) break;
            boolean sel = i == musicIndex;
            boolean hov = ready && mx >= cx + pad && mx < cx + cw - pad && my >= ry && my < ry + rowH;
            if (sel || hov) Gfx.rrect(ctx, cx + pad - 2, ry, cw - pad * 2 + 4, rowH - 1, 4, Gfx.alpha(sel ? ACC : PILL, o * (sel ? 0.35f : 0.5f)));
            String name = s.name;
            if (name.length() > 36) name = name.substring(0, 34) + "…";
            Gfx.ui(ctx, (sel ? "▶ " : "  ") + name, cx + pad, ry + 5, Gfx.alpha(sel ? ON_ACC : TEXT, o));
            if (clickL && hov) {
                musicIndex = i;
                MusicPlayer.play(s);
            }
        }

        // typing for filter
        if (musicSearch && ready) {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                boolean d = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
                boolean edge = d && !prevKeys[k];
                prevKeys[k] = d;
                if (!edge) continue;
                if (k == GLFW.GLFW_KEY_BACKSPACE) {
                    if (musicQuery.length() > 0) musicQuery.setLength(musicQuery.length() - 1);
                    MusicPlayer.setFilter(musicQuery.toString());
                    Sounds.click();
                } else if (k == GLFW.GLFW_KEY_ENTER) {
                    MusicPlayer.setFilter(musicQuery.toString());
                    musicSearch = false;
                    Sounds.click();
                } else if (k == GLFW.GLFW_KEY_ESCAPE) {
                    musicSearch = false;
                } else if ((k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z) && musicQuery.length() < 40) {
                    musicQuery.append((char) ('a' + (k - GLFW.GLFW_KEY_A)));
                    MusicPlayer.setFilter(musicQuery.toString());
                } else if ((k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9) && musicQuery.length() < 40) {
                    musicQuery.append((char) ('0' + (k - GLFW.GLFW_KEY_0)));
                    MusicPlayer.setFilter(musicQuery.toString());
                } else if (k == GLFW.GLFW_KEY_SPACE && musicQuery.length() < 40) {
                    musicQuery.append(' ');
                    MusicPlayer.setFilter(musicQuery.toString());
                }
            }
        }
    }
}
