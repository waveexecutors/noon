package dev.noon.gui;

import dev.noon.module.client.HudModule;
import dev.noon.util.Anim;
import dev.noon.util.Fonts;
import dev.noon.util.Gfx;
import dev.noon.util.Sounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;

/** Slide-in toast shown when a module is switched on or off. */
public final class Notify {
    private Notify() {}

    private static final class Toast {
        String title;
        boolean on;
        long born;
        float slot; // smoothed vertical position (in toast slots)
    }

    private static final List<Toast> LIST = new ArrayList<>();
    /** > 0 while configs are loading / presets applying (no toasts). */
    public static int mute;
    private static final long LIFE = 2400, IN = 380, OUT = 320;
    private static final int W = 158, H = 32;

    public static void push(String module, boolean on) {
        if (mute > 0 || !HudModule.INSTANCE.notifications.get()) return;
        for (Toast t : LIST) {
            if (t.title.equals(module)) { // replace an older toast of the same module
                t.on = on;
                t.born = System.currentTimeMillis();
                if (HudModule.INSTANCE.notifySound.get()) Sounds.notification();
                return;
            }
        }
        Toast t = new Toast();
        t.title = module;
        t.on = on;
        t.born = System.currentTimeMillis();
        t.slot = LIST.size();
        LIST.add(t);
        if (LIST.size() > 5) LIST.remove(0);
        if (HudModule.INSTANCE.notifySound.get()) Sounds.notification();
    }

    private static float easeOutBack(float x) {
        float c1 = 1.70158f, c3 = c1 + 1f;
        float u = x - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }

    public static void render(DrawContext ctx) {
        if (LIST.isEmpty()) return;
        long now = System.currentTimeMillis();
        int sw = ctx.getScaledWindowWidth();
        LIST.removeIf(t -> now - t.born > LIFE);
        int idx = 0;
        for (Toast t : LIST) {
            long age = now - t.born;
            float in = Anim.clamp01(age / (float) IN);
            float out = Anim.clamp01((age - (LIFE - OUT)) / (float) OUT);
            float enter = 1f - easeOutBack(in);                         // 1 -> 0 (overshoots slightly)
            t.slot += (idx - t.slot) * 0.25f;
            float off = enter + (out > 0f ? out * out : 0f);          // 0 = resting position, 1 = fully off screen
            int x = sw - W - 10 + Math.round(off * (W + 24));
            int y = 10 + Math.round(t.slot * (H + 6));
            float a = Math.min(Anim.clamp01(in * 2.2f), 1f - out);

            int accent = t.on ? 0xFFFFCB00 : 0xFF8E8E93;
            Gfx.rrect(ctx, x - 1, y - 1, W + 2, H + 2, 9, Gfx.alpha(t.on ? 0x40FFCB00 : 0x30FFFFFF, a));
            Gfx.rrect(ctx, x, y, W, H, 8, Gfx.alpha(0xF0161616, a));
            // status dot
            Gfx.rrect(ctx, x + 10, y + H / 2 - 5, 10, 10, 5, Gfx.alpha(accent, a));
            if (t.on) Gfx.rrect(ctx, x + 13, y + H / 2 - 2, 4, 4, 2, Gfx.alpha(0xFF161616, a));
            Fonts.draw(ctx, "bold", t.title, x + 28, y + 6, Gfx.alpha(0xFFFFFFFF, a));
            Fonts.draw(ctx, "ui", t.on ? "Enabled" : "Disabled", x + 28, y + 18, Gfx.alpha(accent, a));
            // life bar
            float left = 1f - Anim.clamp01(age / (float) LIFE);
            int bw = Math.round((W - 16) * left);
            if (bw > 0) Gfx.rrect(ctx, x + 8, y + H - 4, bw, 2, 1, Gfx.alpha(accent, a * 0.85f));
            idx++;
        }
    }
}
