package dev.noon.gui;

import dev.noon.alt.AltManager;
import dev.noon.util.Anim;
import dev.noon.util.Gfx;
import dev.noon.util.Sounds;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Alt manager: add / create / random / switch / delete offline accounts. Click a row to log in. */
public class AltScreen extends Screen {
    private static final int W = 320, H = 270, ROW = 22;

    private final Screen parent;
    private TextFieldWidget field;
    private String status = "";
    private int statusColor = Gfx.GREY;
    private float scrollTarget, maxScroll;
    private final Anim scroll = new Anim(), open = new Anim();
    private boolean prevL, prevEnter;

    public AltScreen(Screen parent) {
        super(Text.literal("Alt Manager"));
        this.parent = parent;
        AltManager.load();
    }

    private int px() {
        return (this.width - W) / 2;
    }

    private int py() {
        return (this.height - H) / 2;
    }

    @Override
    protected void init() {
        int x = px(), y = py();
        field = new TextFieldWidget(this.textRenderer, x + 16, y + 52, W - 32 - 150, 20, Text.literal("Username"));
        field.setMaxLength(16);
        field.setPlaceholder(Text.literal("Username (3-16)"));
        addDrawableChild(field);
        setInitialFocus(field);
        addDrawableChild(ButtonWidget.builder(Text.literal("Add"), b -> add(field.getText()))
                .dimensions(x + W - 16 - 142, y + 52, 46, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Random"), b -> {
            String n = AltManager.random();
            AltManager.add(n);
            AltManager.login(n);
            say("Created & logged in as " + n, Gfx.GREEN);
        }).dimensions(x + W - 16 - 92, y + 52, 92, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close())
                .dimensions(x + W / 2 - 50, y + H - 30, 100, 20).build());
    }

    private void say(String s, int c) {
        status = s;
        statusColor = c;
    }

    private void add(String name) {
        name = name.trim();
        if (!AltManager.valid(name)) {
            say("Invalid name: 3-16 letters, numbers or _", Gfx.RED);
            return;
        }
        if (!AltManager.add(name)) {
            say(name + " already saved", Gfx.ORANGE);
            return;
        }
        AltManager.login(name);
        field.setText("");
        say("Added & logged in as " + name, Gfx.GREEN);
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    // vanilla wheel (no @Override on purpose, same as ClickGUI)
    public boolean mouseScrolled(double mouseX, double mouseY, double h, double v) {
        scrollTarget -= (float) v * 24f;
        return true;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        super.renderBackground(ctx, mx, my, delta);
        float o = Math.min(1f, open.to(1f, 10f));
        int x = px(), y = py() + Math.round((1f - o) * 20f);
        Gfx.shadow(ctx, x, y, W, H, 20, o);
        Gfx.glass(ctx, x, y, W, H, 20, o);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        float o = Math.min(1f, open.v);
        int x = px(), y = py() + Math.round((1f - o) * 20f);

        long h = this.client.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean click = l && !prevL;
        prevL = l;
        boolean enter = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_ENTER) == GLFW.GLFW_PRESS;
        if (enter && !prevEnter && field != null && field.isFocused()) add(field.getText());
        prevEnter = enter;

        Gfx.textShadow(ctx, "Alt Manager", x + 18, y + 16, Gfx.alpha(Gfx.WHITE, o));
        Gfx.text(ctx, "Logged in as: " + AltManager.current(), x + 18, y + 30, Gfx.alpha(Gfx.GREY, o));

        int lx = x + 16, ly = y + 82, lw = W - 32, lh = H - 82 - 42;
        if (!status.isEmpty()) Gfx.text(ctx, status, lx + 2, ly - 10, Gfx.alpha(statusColor, o));

        int total = AltManager.ALTS.size() * (ROW + 4);
        maxScroll = Math.max(0, total - lh);
        scrollTarget = Math.max(0, Math.min(scrollTarget, maxScroll));
        float sc = scroll.to(scrollTarget, 16f);

        ctx.enableScissor(lx, ly, lx + lw, ly + lh);
        String cur = AltManager.current();
        int ry = ly - Math.round(sc);
        String del = null;
        for (String n : AltManager.ALTS) {
            if (ry + ROW >= ly && ry <= ly + lh) {
                boolean hov = mx >= lx && mx < lx + lw && my >= Math.max(ry, ly) && my < Math.min(ry + ROW, ly + lh);
                boolean isCur = n.equals(cur);
                Gfx.card(ctx, lx, ry, lw, ROW, 10, o, hov ? 1f : 0f);
                if (isCur) Gfx.rrect(ctx, lx, ry, lw, ROW, 10, Gfx.alpha(0x400A84FF, o));
                Gfx.text(ctx, n, lx + 12, ry + 7, Gfx.alpha(Gfx.WHITE, o));
                if (isCur) Gfx.text(ctx, "active", lx + lw - 70, ry + 7, Gfx.alpha(Gfx.GREEN, o));
                boolean xHov = hov && mx >= lx + lw - 22;
                Gfx.text(ctx, "x", lx + lw - 16, ry + 7, Gfx.alpha(xHov ? Gfx.RED : Gfx.GREY, o));
                if (click && hov) {
                    if (xHov) del = n;
                    else {
                        AltManager.login(n);
                        say("Logged in as " + n, Gfx.GREEN);
                        Sounds.click();
                    }
                }
            }
            ry += ROW + 4;
        }
        ctx.disableScissor();
        if (AltManager.ALTS.isEmpty()) Gfx.text(ctx, "No accounts yet - type a name and press Add", lx + 8, ly + 8, Gfx.alpha(Gfx.GREY, o));
        if (del != null) {
            AltManager.remove(del);
            say("Removed " + del, Gfx.ORANGE);
        }
    }
}
