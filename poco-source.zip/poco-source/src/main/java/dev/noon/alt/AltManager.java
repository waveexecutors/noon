package dev.noon.alt;

import dev.noon.mixin.MinecraftClientAccessor;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;

/** Cracked / offline account list. Switching really replaces the client session (offline UUID, like a cracked launcher). */
public final class AltManager {
    private AltManager() {}

    public static final List<String> ALTS = new ArrayList<>();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("noon_alts.txt");
    }

    public static void load() {
        ALTS.clear();
        try {
            if (Files.exists(file())) {
                for (String l : Files.readAllLines(file(), StandardCharsets.UTF_8)) {
                    l = l.trim();
                    if (valid(l) && !ALTS.contains(l)) ALTS.add(l);
                }
            }
        } catch (IOException ignored) {
        }
    }

    public static void save() {
        try {
            Files.write(file(), ALTS, StandardCharsets.UTF_8);
        } catch (IOException ignored) {
        }
    }

    public static boolean valid(String n) {
        return n != null && n.matches("[A-Za-z0-9_]{3,16}");
    }

    public static String current() {
        return MinecraftClient.getInstance().getSession().getUsername();
    }

    public static String random() {
        String[] a = {"Swift", "Shadow", "Pixel", "Frost", "Nova", "Blaze", "Echo", "Rogue", "Lunar", "Storm"};
        String[] b = {"Fox", "Wolf", "Hawk", "Byte", "Rider", "Knight", "Ghost", "Spark", "Drift", "Cat"};
        java.util.Random r = new java.util.Random();
        return a[r.nextInt(a.length)] + b[r.nextInt(b.length)] + (10 + r.nextInt(90));
    }

    public static boolean add(String name) {
        if (!valid(name)) return false;
        if (!ALTS.contains(name)) ALTS.add(name);
        save();
        return true;
    }

    public static void remove(String name) {
        ALTS.remove(name);
        save();
    }

    /** Offline-mode UUID, identical to what vanilla servers in offline mode compute. */
    public static UUID offlineUuid(String name) {
        return UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
    }

    /** Builds a Session via reflection so it works whichever constructor shape this MC version has. */
    private static Session makeSession(String name) throws Exception {
        for (Constructor<?> c : Session.class.getConstructors()) {
            Class<?>[] t = c.getParameterTypes();
            Object[] args = new Object[t.length];
            int strings = 0;
            boolean ok = true;
            for (int i = 0; i < t.length && ok; i++) {
                if (t[i] == String.class) args[i] = strings++ == 0 ? name : "0";
                else if (t[i] == UUID.class) args[i] = offlineUuid(name);
                else if (t[i] == Optional.class) args[i] = Optional.empty();
                else if (t[i].isEnum()) {
                    Object[] vals = t[i].getEnumConstants();
                    Object pick = vals[0];
                    for (Object v : vals) if (v.toString().equalsIgnoreCase("LEGACY")) pick = v;
                    args[i] = pick;
                } else ok = false;
            }
            if (ok && strings == 2) return (Session) c.newInstance(args);
        }
        throw new IllegalStateException("No compatible Session constructor");
    }

    /** Alias of use(), kept so older screens that call login() still compile. */
    public static boolean login(String name) {
        return use(name);
    }

    public static boolean use(String name) {
        if (!valid(name)) return false;
        try {
            ((MinecraftClientAccessor) MinecraftClient.getInstance()).noon$setSession(makeSession(name));
            return true;
        } catch (Throwable t) {
            t.printStackTrace();
            return false;
        }
    }
}
