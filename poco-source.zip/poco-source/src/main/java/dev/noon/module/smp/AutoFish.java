package dev.noon.module.smp;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Reels in when the bobber is pulled under and recasts. Hold a fishing rod. */
public class AutoFish extends Module {
    public static final AutoFish INSTANCE = new AutoFish();

    public final Setting.Num sensitivity = add(new Setting.Num("Bite Threshold", 0.04, 0.4, 0.12, 0.01));
    public final Setting.Num recast = add(new Setting.Num("Recast Delay (ticks)", 5, 60, 20, 1));
    public final Setting.Num reaction = add(new Setting.Num("Reaction (ticks)", 0, 10, 2, 1));

    private int wait = -1, react = -1;

    private AutoFish() {
        super("AutoFish", Category.SMP);
    }

    @Override
    public void onDisable() {
        wait = -1;
        react = -1;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        Hand hand = p.getMainHandStack().isOf(Items.FISHING_ROD) ? Hand.MAIN_HAND
                : p.getOffHandStack().isOf(Items.FISHING_ROD) ? Hand.OFF_HAND : null;
        if (hand == null) return;

        if (wait >= 0) {
            if (--wait < 0) mc.interactionManager.interactItem(p, hand); // recast
            return;
        }
        if (react >= 0) {
            if (--react < 0) {
                mc.interactionManager.interactItem(p, hand); // reel in
                wait = recast.i();
            }
            return;
        }
        FishingBobberEntity hook = p.fishHook;
        if (hook == null) return;
        if (hook.age > 25 && hook.isTouchingWater() && hook.getVelocity().y < -sensitivity.get()) react = reaction.i();
    }
}
