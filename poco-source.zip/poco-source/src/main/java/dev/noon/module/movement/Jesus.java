package dev.noon.module.movement;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Keeps you on top of water (and optionally lava) instead of sinking. Sneak to dive. */
public class Jesus extends Module {
    public static final Jesus INSTANCE = new Jesus();

    public final Setting.Bool lava = add(new Setting.Bool("Lava", false));
    public final Setting.Num lift = add(new Setting.Num("Lift", 0.05, 0.25, 0.11, 0.01));

    private Jesus() {
        super("Jesus", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || mc.options.sneakKey.isPressed()) return;
        boolean liquid = p.isTouchingWater() || (lava.get() && p.isInLava());
        if (!liquid) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, lift.get(), v.z);
    }
}
