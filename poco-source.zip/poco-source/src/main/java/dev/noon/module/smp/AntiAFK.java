package dev.noon.module.smp;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;

/** Small random actions at random intervals so idle-kick timers keep resetting. */
public class AntiAFK extends Module {
    public static final AntiAFK INSTANCE = new AntiAFK();

    public final Setting.Num minSec = add(new Setting.Num("Min Interval (s)", 5, 120, 15, 1));
    public final Setting.Num maxSec = add(new Setting.Num("Max Interval (s)", 5, 180, 40, 1));
    public final Setting.Bool jump = add(new Setting.Bool("Jump", true));
    public final Setting.Bool look = add(new Setting.Bool("Look Around", true));
    public final Setting.Bool swing = add(new Setting.Bool("Swing Arm", true));

    private int timer = -1;

    private AntiAFK() {
        super("AntiAFK", Category.SMP);
    }

    private void reset() {
        double lo = Math.min(minSec.get(), maxSec.get()), hi = Math.max(minSec.get(), maxSec.get());
        timer = (int) ((lo + ThreadLocalRandom.current().nextDouble() * (hi - lo)) * 20);
    }

    @Override
    public void onEnable() {
        timer = -1;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (timer < 0) reset();
        if (--timer > 0) return;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (look.get()) {
            p.setYaw(p.getYaw() + (float) r.nextDouble(-18, 18));
            p.setPitch(Math.max(-60f, Math.min(60f, p.getPitch() + (float) r.nextDouble(-6, 6))));
        }
        if (jump.get() && p.isOnGround()) p.jump();
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        reset();
    }
}
