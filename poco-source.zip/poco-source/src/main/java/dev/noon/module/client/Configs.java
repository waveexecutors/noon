package dev.noon.module.client;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.ModuleManager;
import dev.noon.module.Presets;
import dev.noon.module.Setting;
import net.minecraft.text.Text;

/** Config tab: conservative presets + 3 custom save slots. Flip a switch to run it (it flips back by itself). */
public class Configs extends Module {
    public static final Configs INSTANCE = new Configs();

    public final Setting.Mode preset = add(new Setting.Mode("Preset", 0, Presets.NAMES));
    public final Setting.Bool apply = add(new Setting.Bool("Apply Preset", false));
    public final Setting.Num slot = add(new Setting.Num("Slot", 1, 3, 1, 1));
    public final Setting.Bool save = add(new Setting.Bool("Save To Slot", false));
    public final Setting.Bool load = add(new Setting.Bool("Load From Slot", false));
    public final Setting.Bool disable = add(new Setting.Bool("Disable All Modules", false));

    private Configs() {
        super("Configs", Category.CONFIG);
        showInHud = false;
        enabled = true;
        toggle.v = 1f;
    }

    private void msg(String s) {
        if (mc().player != null) mc().player.sendMessage(Text.literal("[Poco] " + s), false);
    }

    /** Called every client tick from ModuleManager (independent of the module switch). */
    public void poll() {
        if (apply.value) {
            apply.value = false;
            Presets.apply(preset.get());
            ModuleManager.save();
            msg("Preset applied: " + preset.get());
        }
        if (save.value) {
            save.value = false;
            ModuleManager.saveTo(ModuleManager.slotFile(slot.i()));
            msg("Saved to slot " + slot.i());
        }
        if (load.value) {
            load.value = false;
            boolean ok = ModuleManager.loadFrom(ModuleManager.slotFile(slot.i()));
            msg(ok ? "Loaded slot " + slot.i() : "Slot " + slot.i() + " is empty");
        }
        if (disable.value) {
            disable.value = false;
            Presets.disableAll();
            msg("All modules disabled");
        }
    }
}
