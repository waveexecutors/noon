package dev.noon.module.emotes;
public final class BloodyPop extends EmoteModule { public static final BloodyPop INSTANCE=new BloodyPop(); private BloodyPop(){super("Bloody Pop","bloody_pop");} }
