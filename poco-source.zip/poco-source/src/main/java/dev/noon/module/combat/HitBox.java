package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;

/** Enlarges other players' targeting hitbox (client-side raycast). See EntityMixin. */
public class HitBox extends Module {
    public static final HitBox INSTANCE = new HitBox();

    public final Setting.Num expand = add(new Setting.Num("Expand", 0.0, 0.5, 0.1, 0.01));

    private HitBox() {
        super("HitBox", Category.COMBAT);
    }
}
