package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;

/** Raises your interaction range attributes (only works where the server does not enforce vanilla reach). */
public class Reach extends Module {
    public static final Reach INSTANCE = new Reach();

    public final Setting.Num entity = add(new Setting.Num("Entity Range", 3.0, 6.0, 4.0, 0.1));
    public final Setting.Num block = add(new Setting.Num("Block Range", 4.5, 8.0, 5.5, 0.1));

    private Reach() {
        super("Reach", Category.COMBAT);
    }

    private static void set(ClientPlayerEntity p, double e, double b) {
        EntityAttributeInstance ei = p.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
        if (ei != null) ei.setBaseValue(e);
        EntityAttributeInstance bi = p.getAttributeInstance(EntityAttributes.BLOCK_INTERACTION_RANGE);
        if (bi != null) bi.setBaseValue(b);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p != null) set(p, entity.get(), block.get());
    }

    @Override
    public void onDisable() {
        ClientPlayerEntity p = mc().player;
        if (p != null) set(p, 3.0, 4.5);
    }
}
