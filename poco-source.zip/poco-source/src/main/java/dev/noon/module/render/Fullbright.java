package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;

/** Handled centrally in ModuleManager.tick() together with X-Ray's light option. */
public class Fullbright extends Module {
    public static final Fullbright INSTANCE = new Fullbright();

    private Fullbright() {
        super("Fullbright", Category.FPS);
    }
}
