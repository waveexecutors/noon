package dev.noon.module.movement;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** Jumps up one-block steps automatically (or constantly while you move). */
public class AutoJump extends Module {
    public static final AutoJump INSTANCE = new AutoJump();

    public final Setting.Bool constant = add(new Setting.Bool("Constant Hopping", false));

    private AutoJump() {
        super("AutoJump", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || !p.isOnGround() || !Move.moving(mc) || mc.options.sneakKey.isPressed()) return;
        if (constant.get() || p.horizontalCollision) p.jump();
    }
}
