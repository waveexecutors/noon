package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.util.Gfx;
import dev.noon.util.HandMath;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Arm;

/**
 * Real hand outline: HeldItemRendererMixin captures the exact first-person matrix of each hand every frame, HandMath rebuilds
 * the vanilla arm transform on top of it and projects the actual arm box, and this module fills a thick outline that hugs
 * that silhouette, plus a soft glow fading outward. It follows swing, equip, bobbing, Animations and Hand Customization.
 */
public class HandGlow extends Module {
    public static final HandGlow INSTANCE = new HandGlow();

    public final Setting.Mode colorMode = add(new Setting.Mode("Color Mode", 0, "Rainbow", "Custom", "Fade", "Pulse", "White"));
    public final Setting.Num r1 = add(new Setting.Num("Red", 0, 255, 80, 1));
    public final Setting.Num g1 = add(new Setting.Num("Green", 0, 255, 160, 1));
    public final Setting.Num b1 = add(new Setting.Num("Blue", 0, 255, 255, 1));
    public final Setting.Num r2 = add(new Setting.Num("Fade Red", 0, 255, 255, 1));
    public final Setting.Num g2 = add(new Setting.Num("Fade Green", 0, 255, 60, 1));
    public final Setting.Num b2 = add(new Setting.Num("Fade Blue", 0, 255, 180, 1));
    public final Setting.Num speed = add(new Setting.Num("Speed", 0.1, 5.0, 1.0, 0.1));
    public final Setting.Num thickness = add(new Setting.Num("Outline Thickness", 1, 12, 3, 0.5));
    public final Setting.Num glowSpread = add(new Setting.Num("Glow Spread", 0, 30, 8, 1));
    public final Setting.Num glowAlpha = add(new Setting.Num("Glow Intensity", 5, 100, 60, 1));
    public final Setting.Num layers = add(new Setting.Num("Glow Layers", 1, 8, 4, 1));
    public final Setting.Bool mainHand = add(new Setting.Bool("Main Hand", true));
    public final Setting.Bool offHand = add(new Setting.Bool("Off Hand", true));
    public final Setting.Bool needItem = add(new Setting.Bool("Only With Item", false));
    public final Setting.Bool outlineItems = add(new Setting.Bool("Glow Held Items", true));
    public final Setting.Num itemFit = add(new Setting.Num("Item Fit", 0.4, 1.0, 1.0, 0.02));
    public final Setting.Bool slimArms = add(new Setting.Bool("Slim Arms", false));
    public final Setting.Num handFov = add(new Setting.Num("Hand FOV", 40, 110, 70, 1));
    // manual calibration, in case a different GUI scale / FOV mod shifts the projection
    public final Setting.Mode camFix = add(new Setting.Mode("Camera Fix", 0, "Auto", "Off", "Force"));
    public final Setting.Num offX = add(new Setting.Num("Align X", -60, 60, 0, 1));
    public final Setting.Num offY = add(new Setting.Num("Align Y", -60, 60, 0, 1));
    public final Setting.Num fitScale = add(new Setting.Num("Align Scale", 0.6, 1.6, 1.0, 0.01));

    private HandGlow() {
        super("Hand Glow", Category.RENDER);
        showInHud = false;
    }

    private int color(float t) {
        double ph = System.currentTimeMillis() / 1000.0 * speed.get();
        int c1 = 0xFF000000 | (r1.i() << 16) | (g1.i() << 8) | b1.i();
        int c2 = 0xFF000000 | (r2.i() << 16) | (g2.i() << 8) | b2.i();
        switch (colorMode.index) {
            case 0:
                return 0xFF000000 | java.awt.Color.HSBtoRGB((float) ((ph * 0.25 + t * 0.15) % 1.0), 0.7f, 1f);
            case 1:
                return c1;
            case 2:
                return Gfx.lerp(c1, c2, (float) (0.5 + 0.5 * Math.sin(ph * 2.0 + t * 2.0)));
            case 4:
                return 0xFFFFFFFF; // White
            default:
                return Gfx.lerp(0xFF000000 | ((r1.i() / 3) << 16) | ((g1.i() / 3) << 8) | (b1.i() / 3), c1,
                        (float) (0.5 + 0.5 * Math.sin(ph * 3.0)));
        }
    }

    // ---- per-frame capture from HeldItemRendererMixin ------------------------------------------

    private static final float[][] MAT = new float[2][16];
    private static final float[] SWING = new float[2], EQUIP = new float[2];
    private static final boolean[] EMPTY = new boolean[2], BLOCK = new boolean[2];
    private static final long[] CAP_T = new long[2];
    private static boolean inverseSeen;
    private static final String[] ITEM = {"", ""};

    /** Hand matrix (view space, after Hand Customization + Animations) at the start of renderFirstPersonItem. */
    public static void capture(boolean main, float[] mat, boolean empty, boolean block, String itemId) {
        int i = main ? 0 : 1;
        ITEM[i] = itemId == null ? "" : itemId;
        System.arraycopy(mat, 0, MAT[i], 0, 16);
        EMPTY[i] = empty;
        BLOCK[i] = block;
        CAP_T[i] = System.nanoTime();
    }

    /** swingProgress / equipProgress arguments of renderFirstPersonItem. */
    public static void params(boolean main, float swing, float equip) {
        int i = main ? 0 : 1;
        SWING[i] = swing;
        EQUIP[i] = equip;
    }

    // ---- drawing ------------------------------------------------------------------------------

    public void render(MinecraftClient mc, DrawContext ctx, float td) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson()) return;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        double tanHalf = Math.tan(Math.toRadians(handFov.get()) / 2.0);
        double aspect = (double) sw / sh;
        long now = System.nanoTime();
        for (int i = 0; i < 2; i++) {
            boolean main = i == 0;
            if (main ? !mainHand.get() : !offHand.get()) continue;
            if (now - CAP_T[i] > 100_000_000L) continue; // vanilla did not draw this hand this frame
            boolean empty = EMPTY[i];
            if (empty && (!main || p.isInvisible())) continue; // vanilla draws no bare off hand / no arm when invisible
            if (!empty && !outlineItems.get()) continue;
            if (main && needItem.get() && empty) continue;

            Arm arm = main ? p.getMainArm() : p.getMainArm().getOpposite();
            boolean right = arm == Arm.RIGHT;
            float swing = SWING[i];
            if (swing > 0f && Animations.overridesSwing()) swing = 0f; // mixin zeroes vanilla's swing in that case
            double[] base = HandMath.fromColumnMajor(MAT[i]);
            // Since 1.21.2 the hand matrix stack starts with the INVERSE of the camera rotation (the real view matrix is applied
            // afterwards by the renderer). Without cancelling it the glow swings around whenever you look around. Auto latches
            // on once a hand matrix rotates by more than a hand ever can (a real hand tilts ~15 degrees at most).
            if (camFix.index != 1) {
                double tr = base[0] + base[5] + base[10];
                double ang = Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, (tr - 1.0) / 2.0))));
                if (ang > 40.0) inverseSeen = true;
                if (camFix.index == 2 || inverseSeen) {
                    net.minecraft.client.render.Camera cam = mc.gameRenderer.getCamera();
                    double[] v = HandMath.rotX(HandMath.id(), cam.getPitch());
                    v = HandMath.rotY(v, cam.getYaw() - 180.0);
                    base = HandMath.mul(v, base);
                }
            }
            List<double[][]> polys = new ArrayList<>();
            double[][] corners;
            boolean[] mask = (!empty && !BLOCK[i]) ? spriteMask(mc, ITEM[i]) : null;
            if (mask != null) {
                int n = (int) Math.round(Math.sqrt(mask.length));
                double[] m = HandMath.itemMatrix(base, right, false, swing, EQUIP[i]);
                for (double[][] q : HandMath.spriteQuads(m, mask, n, itemFit.get())) {
                    double[][] pq = new double[4][];
                    boolean ok = true;
                    for (int k = 0; k < 4 && ok; k++) {
                        double d = -q[k][2];
                        if (d < 0.05) { ok = false; break; }
                        pq[k] = new double[]{sw / 2.0 + (q[k][0] / d) / (tanHalf * aspect) * (sw / 2.0), sh / 2.0 - (q[k][1] / d) / tanHalf * (sh / 2.0)};
                    }
                    if (ok) polys.add(pq);
                }
            } else {
                corners = empty
                        ? HandMath.arm(base, right, slimArms.get(), swing, EQUIP[i])
                        : HandMath.item(base, right, BLOCK[i], swing, EQUIP[i], itemFit.get());
                List<double[]> pts = HandMath.project(corners, tanHalf, aspect, sw, sh);
                if (pts.size() >= 3) {
                    double[][] hull = HandMath.hull(pts);
                    if (hull.length >= 3) polys.add(hull);
                }
            }
            if (polys.isEmpty()) continue;
            // calibration: scale about the centre of the shape, then shift
            double mx = 0, my = 0;
            int cnt = 0;
            for (double[][] pl : polys) for (double[] q : pl) { mx += q[0]; my += q[1]; cnt++; }
            mx /= cnt;
            my /= cnt;
            double sc = fitScale.get(), ox = offX.get(), oy = offY.get();
            for (double[][] pl : polys) for (double[] q : pl) {
                q[0] = mx + (q[0] - mx) * sc + ox;
                q[1] = my + (q[1] - my) * sc + oy;
            }
            drawGlow(mc, ctx, polys, sw, sh, i);
        }
    }

    // ---- exact item silhouette from the item's own texture -------------------------------------

    private static final java.util.Map<String, boolean[]> MASKS = new java.util.HashMap<>();

    private static boolean[] spriteMask(MinecraftClient mc, String id) {
        if (id == null || id.isEmpty()) return null;
        if (MASKS.containsKey(id)) return MASKS.get(id);
        boolean[] out = null;
        try {
            var res = mc.getResourceManager().getResource(net.minecraft.util.Identifier.of("minecraft", "textures/item/" + id + ".png"));
            if (res.isPresent()) {
                try (java.io.InputStream in = res.get().getInputStream()) {
                    java.awt.image.BufferedImage img = javax.imageio.ImageIO.read(in);
                    if (img != null) {
                        int n = img.getWidth(); // animated strips: first frame only (square)
                        if (n >= 4 && img.getHeight() >= n) {
                            out = new boolean[n * n];
                            for (int y = 0; y < n; y++)
                                for (int x = 0; x < n; x++) out[y * n + x] = (img.getRGB(x, y) >>> 24) > 24;
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        MASKS.put(id, out);
        return out;
    }

    // ---- smooth glow: rasterised at real pixel resolution into a texture ------------------------

    private static final int TEX = 768;
    private static final class Scratch { boolean[] coverage = new boolean[0]; float[] distance = new float[0]; void resize(int n) { if (coverage.length != n) { coverage = new boolean[n]; distance = new float[n]; } else java.util.Arrays.fill(coverage, false); } }
    private static final ThreadLocal<Scratch> SCRATCH = ThreadLocal.withInitial(Scratch::new);
    private final int[] colorLut = new int[33];
    private final net.minecraft.client.texture.NativeImageBackedTexture[] tex = new net.minecraft.client.texture.NativeImageBackedTexture[2];
    private final net.minecraft.util.Identifier[] texId = new net.minecraft.util.Identifier[2];

    private void ensureTex(MinecraftClient mc, int i) {
        if (tex[i] != null) return;
        final int idx = i;
        net.minecraft.client.texture.NativeImage img = new net.minecraft.client.texture.NativeImage(TEX, TEX, true);
        tex[i] = new net.minecraft.client.texture.NativeImageBackedTexture(() -> "poco_hand_glow_" + idx, img);
        texId[i] = net.minecraft.util.Identifier.of("noon", "hand_glow_" + i);
        mc.getTextureManager().registerTexture(texId[i], tex[i]);
    }

    private void drawGlow(MinecraftClient mc, DrawContext ctx, List<double[][]> polys, int sw, int sh, int hand) {
        double minX = Double.POSITIVE_INFINITY, minY = minX, maxX = Double.NEGATIVE_INFINITY, maxY = maxX;
        for (double[][] pl : polys) for (double[] v : pl) {
            minX = Math.min(minX, v[0]);
            maxX = Math.max(maxX, v[0]);
            minY = Math.min(minY, v[1]);
            maxY = Math.max(maxY, v[1]);
        }
        // a wrong / degenerate projection can cover the whole screen: skip instead of lagging
        if ((maxX - minX) * (maxY - minY) > 0.55 * sw * sh) return;
        double thick = thickness.get(), spread = glowSpread.get();
        double reach = thick + spread + 2;
        int gx = (int) Math.floor(minX - reach), gy = (int) Math.floor(minY - reach);
        int gw = (int) Math.ceil(maxX + reach) - gx, gh = (int) Math.ceil(maxY + reach) - gy;
        int k = (int) Math.min(Math.max(1.0, Math.floor(mc.getWindow().getScaleFactor())), Math.min(TEX / (double) gw, TEX / (double) gh));
        if (k < 1 || gw < 2 || gh < 2) return;
        int W = gw * k, H = gh * k;
        Scratch scratch = SCRATCH.get();
        scratch.resize(W * H);
        boolean[] cov = scratch.coverage;
        for (double[][] pl : polys) {
            double[][] g = new double[pl.length][];
            for (int a = 0; a < pl.length; a++) g[a] = new double[]{(pl[a][0] - gx) * k, (pl[a][1] - gy) * k};
            dev.noon.util.GlowRaster.fillConvex(cov, W, H, g);
        }
        float[] d = dev.noon.util.GlowRaster.distance(cov, W, H, scratch.distance);
        ensureTex(mc, hand);
        net.minecraft.client.texture.NativeImage img = tex[hand].getImage();
        if (img == null) return;
        int c0 = color(hand * 0.5f);
        int[] lut = colorLut;
        for (int a = 0; a <= 32; a++) lut[a] = color(hand * 0.5f + a / 32f * 0.16f);
        double thickPx = thick * k, spreadPx = Math.max(0.001, spread * k);
        float base = glowAlpha.f() / 100f;
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                float dist = d[y * W + x];
                int out = 0;
                if (dist > 0f && dist < thickPx + spreadPx + 1) {
                    double a0 = Math.max(0.0, Math.min(1.0, thickPx - dist + 0.5));
                    double t = Math.max(0.0, Math.min(1.0, (dist - thickPx) / spreadPx));
                    double g = spread > 0 ? base * (1 - t) * (1 - t) : 0;
                    double al = a0 + (1 - a0) * g;
                    if (al > 0.003) {
                        int gc = lut[(int) (t * 32)];
                        int cr = (int) (((c0 >> 16 & 255) * a0 + (gc >> 16 & 255) * (1 - a0)));
                        int cg = (int) (((c0 >> 8 & 255) * a0 + (gc >> 8 & 255) * (1 - a0)));
                        int cb = (int) (((c0 & 255) * a0 + (gc & 255) * (1 - a0)));
                        out = ((int) (al * 255) << 24) | (cr << 16) | (cg << 8) | cb;
                    }
                }
                img.setColorArgb(x, y, out);
            }
        }
        tex[hand].upload();
        ctx.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED, texId[hand], gx, gy, 0f, 0f, gw, gh, W, H, TEX, TEX);
    }
}
