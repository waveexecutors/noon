package dev.noon.module.emotes;
public final class PhitHon extends EmoteModule { public static final PhitHon INSTANCE=new PhitHon(); private PhitHon(){super("Phit Hon","phit_hon");} }
