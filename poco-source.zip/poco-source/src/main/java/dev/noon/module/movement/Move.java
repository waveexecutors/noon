package dev.noon.module.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;

/** Shared helpers for the movement modules. */
final class Move {
    private Move() {}

    static boolean moving(MinecraftClient mc) {
        return mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed() || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
    }

    /** Horizontal unit vector (x, z) of the pressed movement keys relative to the player's yaw; {0,0} when idle. */
    static double[] dir(MinecraftClient mc, ClientPlayerEntity p) {
        float f = (mc.options.forwardKey.isPressed() ? 1f : 0f) - (mc.options.backKey.isPressed() ? 1f : 0f);
        float s = (mc.options.leftKey.isPressed() ? 1f : 0f) - (mc.options.rightKey.isPressed() ? 1f : 0f);
        if (f == 0 && s == 0) return new double[]{0, 0};
        double yaw = Math.toRadians(p.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double x = -sin * f + cos * s, z = cos * f + sin * s;
        double len = Math.sqrt(x * x + z * z);
        return new double[]{x / len, z / len};
    }

    /** True when there is no solid ground a short step ahead of the player's feet. */
    static boolean edgeAhead(MinecraftClient mc, ClientPlayerEntity p, double reach) {
        double[] d = dir(mc, p);
        double vx = d[0], vz = d[1];
        if (vx == 0 && vz == 0) {
            vx = p.getVelocity().x;
            vz = p.getVelocity().z;
            double l = Math.sqrt(vx * vx + vz * vz);
            if (l < 1.0e-4) return false;
            vx /= l;
            vz /= l;
        }
        BlockPos below = BlockPos.ofFloored(p.getX() + vx * reach, p.getY() - 0.6, p.getZ() + vz * reach);
        return mc.world.getBlockState(below).getCollisionShape(mc.world, below).isEmpty();
    }
}
