package dev.noon.module.emotes;
public final class SadCat1 extends EmoteModule { public static final SadCat1 INSTANCE=new SadCat1(); private SadCat1(){super("Sad Cat 1","sad_cat_1");} }
