package dev.noon.module.emotes;
public final class SadCat2 extends EmoteModule { public static final SadCat2 INSTANCE=new SadCat2(); private SadCat2(){super("Sad Cat 2","sad_cat_2");} }
