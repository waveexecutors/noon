package dev.noon.module.smp;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** Refills hotbar stacks (blocks, food, pearls, potions...) from your inventory when they run low or empty. */
public class AutoReplenish extends Module {
    public static final AutoReplenish INSTANCE = new AutoReplenish();

    public final Setting.Num threshold = add(new Setting.Num("Refill At", 0, 32, 8, 1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 1, 20, 4, 1));

    private final Item[] lastItem = new Item[9];
    private int cd;

    private AutoReplenish() {
        super("AutoReplenish", Category.SMP);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (cd > 0) {
            cd--;
            return;
        }
        for (int h = 0; h < 9; h++) {
            ItemStack s = p.getInventory().getStack(h);
            Item item = s.isEmpty() ? lastItem[h] : s.getItem();
            if (!s.isEmpty()) lastItem[h] = s.getItem();
            if (item == null || item == Items.AIR) continue;
            boolean low = s.isEmpty() || (s.getMaxCount() > 1 && s.getCount() <= threshold.i() && s.getCount() < s.getMaxCount());
            if (!low) continue;
            int from = -1, bestCount = 0;
            for (int i = 9; i < 36; i++) {
                ItemStack o = p.getInventory().getStack(i);
                if (o.isOf(item) && o.getMaxCount() > 1 && o.getCount() > bestCount) {
                    from = i;
                    bestCount = o.getCount();
                }
            }
            if (from < 0) {
                if (s.isEmpty()) lastItem[h] = null;
                continue;
            }
            mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, from, h, SlotActionType.SWAP, p);
            cd = delay.i();
            return;
        }
    }
}
