package dev.noon.module.smp;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/** Shift-clicks everything out of an opened chest / barrel / shulker. */
public class ChestStealer extends Module {
    public static final ChestStealer INSTANCE = new ChestStealer();

    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 0, 10, 1, 1));
    public final Setting.Bool close = add(new Setting.Bool("Auto Close", true));

    private int timer;

    private ChestStealer() {
        super("ChestStealer", Category.SMP);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (!(mc.currentScreen instanceof GenericContainerScreen gs)) {
            timer = 0;
            return;
        }
        if (--timer > 0) return;
        GenericContainerScreenHandler h = gs.getScreenHandler();
        int n = h.getRows() * 9;
        for (int i = 0; i < n; i++) {
            if (!h.getSlot(i).getStack().isEmpty()) {
                mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
                timer = delay.i();
                return;
            }
        }
        if (close.get()) p.closeHandledScreen();
    }
}
