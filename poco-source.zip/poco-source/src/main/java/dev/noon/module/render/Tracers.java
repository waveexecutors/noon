package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.render.Esp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;

/** Lines from the screen to players / hostile mobs. */
public class Tracers extends Module {
    public static final Tracers INSTANCE = new Tracers();

    public final Setting.Mode from = add(new Setting.Mode("From", 0, "Bottom", "Crosshair"));
    public final Setting.Mode color = add(new Setting.Mode("Color", 5, Esp.COLORS));
    public final Setting.Bool players = add(new Setting.Bool("Players", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Hostile Mobs", false));
    public final Setting.Num range = add(new Setting.Num("Range", 16, 256, 128, 8));
    public final Setting.Num max = add(new Setting.Num("Max Lines", 1, 32, 12, 1));

    private Tracers() {
        super("Tracers", Category.RENDER);
    }

    public void render(MinecraftClient mc, DrawContext ctx) {
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null) return;
        List<Entity> list = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (e == me || !e.isAlive()) continue;
            boolean ok = (players.get() && e instanceof PlayerEntity) || (mobs.get() && e instanceof Monster);
            if (ok && me.distanceTo(e) <= range.get()) list.add(e);
        }
        list.sort(Comparator.comparingDouble(me::distanceTo));
        float ox = Esp.sw / 2f, oy = from.index == 0 ? Esp.sh : Esp.sh / 2f;
        float[] o = new float[2];
        int n = 0;
        for (Entity e : list) {
            if (n >= max.i()) break;
            Box b = Esp.lerped(e);
            Esp.project((b.minX + b.maxX) / 2, (b.minY + b.maxY) / 2, (b.minZ + b.maxZ) / 2, o);
            double d = me.distanceTo(e);
            int col = Esp.color(color.index, d, range.get(), n);
            Esp.line(ctx, ox, oy, o[0], o[1], 0x90000000);
            Esp.line(ctx, ox, oy, o[0], o[1], col);
            n++;
        }
    }
}
