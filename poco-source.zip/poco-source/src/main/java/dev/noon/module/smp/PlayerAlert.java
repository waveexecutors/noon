package dev.noon.module.smp;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.util.Sounds;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

/** Chat message + sound when another player comes into render distance. */
public class PlayerAlert extends Module {
    public static final PlayerAlert INSTANCE = new PlayerAlert();

    public final Setting.Bool chat = add(new Setting.Bool("Chat", true));
    public final Setting.Bool sound = add(new Setting.Bool("Sound", true));

    private final Set<UUID> seen = new HashSet<>();

    private PlayerAlert() {
        super("PlayerAlert", Category.SMP);
    }

    @Override
    public void onDisable() {
        seen.clear();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null) return;
        Set<UUID> now = new HashSet<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == me) continue;
            now.add(p.getUuid());
            if (seen.add(p.getUuid())) {
                if (chat.get()) {
                    me.sendMessage(Text.literal("[Poco] " + p.getName().getString() + " entered render distance (" + Math.round(me.distanceTo(p)) + "m)"), false);
                }
                if (sound.get()) Sounds.click();
            }
        }
        seen.retainAll(now);
    }
}
