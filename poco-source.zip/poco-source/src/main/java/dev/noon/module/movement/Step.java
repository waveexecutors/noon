package dev.noon.module.movement;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;

/** Walk up blocks without jumping. */
public class Step extends Module {
    public static final Step INSTANCE = new Step();

    public final Setting.Num height = add(new Setting.Num("Height", 0.6, 2.5, 1.0, 0.1));

    private Step() {
        super("Step", Category.MOVEMENT);
    }

    private static void set(ClientPlayerEntity p, double h) {
        EntityAttributeInstance a = p.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (a != null) a.setBaseValue(h);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p != null) set(p, height.get());
    }

    @Override
    public void onDisable() {
        ClientPlayerEntity p = mc().player;
        if (p != null) set(p, 0.6);
    }
}
