package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.network.ClientPlayerEntity;

/** Resets your sprint right after you hit, so the next hit deals full sprint knockback. Pairs with AutoSprint. */
public class WTap extends Module {
    public static final WTap INSTANCE = new WTap();

    public final Setting.Num ticks = add(new Setting.Num("Pause (ticks)", 1, 5, 2, 1));
    private static int left;

    private WTap() {
        super("WTap", Category.COMBAT);
    }

    public static void onAttack() {
        if (INSTANCE.enabled) left = INSTANCE.ticks.i();
    }

    public static boolean active() {
        return INSTANCE.enabled && left > 0;
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p == null) return;
        if (left > 0) {
            left--;
            p.setSprinting(false);
        }
    }
}
