package dev.noon.module;

public enum Category {
    COMBAT("Combat"),
    EMOTES("Emotes"),
    MOVEMENT("Movement"),
    PLAYER("Player"),
    RENDER("Render"),
    SMP("SMP"),
    FPS("FPS"),
    CLIENT("Client"),
    CONFIG("Configs"),
    MUSIC("Music");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
