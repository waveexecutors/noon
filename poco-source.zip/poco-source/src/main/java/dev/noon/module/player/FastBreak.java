package dev.noon.module.player;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;

/** Removes the delay between breaking blocks and speeds up break progress. See ClientPlayerInteractionManagerMixin. */
public class FastBreak extends Module {
    public static final FastBreak INSTANCE = new FastBreak();

    public final Setting.Num speed = add(new Setting.Num("Speed", 1.0, 3.0, 1.3, 0.05));

    public final Setting.Bool noCooldown = add(new Setting.Bool("No Cooldown", true));

    private FastBreak() {
        super("FastBreak", Category.PLAYER);
    }
}
