package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Smoothly pulls your aim toward the closest player inside your FOV. Runs every frame (see NoonClient). */
public class AimAssist extends Module {
    public static final AimAssist INSTANCE = new AimAssist();

    public final Setting.Num range = add(new Setting.Num("Range", 2, 8, 4.5, 0.1));
    public final Setting.Num fov = add(new Setting.Num("FOV", 10, 180, 70, 5));
    public final Setting.Num speed = add(new Setting.Num("Speed", 1, 20, 6, 0.5));
    public final Setting.Bool vertical = add(new Setting.Bool("Vertical", true));
    public final Setting.Bool onClick = add(new Setting.Bool("Only While Clicking", true));

    private long last = System.nanoTime();

    private AimAssist() {
        super("AimAssist", Category.COMBAT);
    }

    public void frame() {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1_000_000_000f);
        last = now;
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (!enabled || p == null || mc.world == null || mc.currentScreen != null) return;
        if (onClick.get() && !mc.options.attackKey.isPressed()) return;

        PlayerEntity best = null;
        float bestDiff = fov.f() / 2f;
        Vec3d eye = p.getEyePos();
        for (PlayerEntity t : mc.world.getPlayers()) {
            if (t == p || !t.isAlive() || t.isSpectator() || p.distanceTo(t) > range.get()) continue;
            Vec3d c = t.getBoundingBox().getCenter();
            float yawTo = (float) (Math.toDegrees(Math.atan2(c.z - eye.z, c.x - eye.x)) - 90.0);
            float d = Math.abs(MathHelper.wrapDegrees(yawTo - p.getYaw()));
            if (d < bestDiff) {
                bestDiff = d;
                best = t;
            }
        }
        if (best == null) return;

        Vec3d c = best.getBoundingBox().getCenter();
        double dx = c.x - eye.x, dy = c.y - eye.y, dz = c.z - eye.z;
        float yawTo = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitchTo = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        float k = 1f - (float) Math.exp(-speed.f() * dt);
        p.setYaw(p.getYaw() + MathHelper.wrapDegrees(yawTo - p.getYaw()) * k);
        if (vertical.get()) p.setPitch(MathHelper.clamp(p.getPitch() + (pitchTo - p.getPitch()) * k, -90f, 90f));
    }
}
