package dev.noon.module.movement;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** Sneaks for you at the edge of a block so you can bridge and walk ledges without falling. */
public class SafeWalk extends Module {
    public static final SafeWalk INSTANCE = new SafeWalk();

    public final Setting.Num reach = add(new Setting.Num("Edge Distance", 0.2, 1.0, 0.45, 0.05));
    public final Setting.Bool onlyBackward = add(new Setting.Bool("Only When Looking Down", false));

    private boolean forced;

    private SafeWalk() {
        super("SafeWalk", Category.MOVEMENT);
    }

    @Override
    public void onDisable() {
        release();
    }

    private void release() {
        if (forced) {
            mc().options.sneakKey.setPressed(false);
            forced = false;
        }
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) {
            release();
            return;
        }
        boolean want = p.isOnGround() && (!onlyBackward.get() || p.getPitch() > 60f) && Move.edgeAhead(mc, p, reach.get());
        if (want) {
            mc.options.sneakKey.setPressed(true);
            forced = true;
        } else {
            release();
        }
    }
}
