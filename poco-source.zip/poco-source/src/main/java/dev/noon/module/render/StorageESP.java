package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.render.Esp;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;

/** Boxes around chests, barrels, shulkers, furnaces, hoppers, spawners... (great for stash hunting). */
public class StorageESP extends Module {
    public static final StorageESP INSTANCE = new StorageESP();

    public final Setting.Bool chests = add(new Setting.Bool("Chests", true));
    public final Setting.Bool ender = add(new Setting.Bool("Ender Chests", true));
    public final Setting.Bool barrels = add(new Setting.Bool("Barrels", true));
    public final Setting.Bool shulkers = add(new Setting.Bool("Shulkers", true));
    public final Setting.Bool furnaces = add(new Setting.Bool("Furnaces", false));
    public final Setting.Bool hoppers = add(new Setting.Bool("Hoppers/Dispensers", false));
    public final Setting.Bool spawners = add(new Setting.Bool("Spawners", true));
    public final Setting.Num range = add(new Setting.Num("Range", 16, 256, 96, 8));

    private record Hit(Box box, int color) {}

    private volatile List<Hit> hits = new ArrayList<>();
    private int timer;

    private StorageESP() {
        super("Storage ESP", Category.RENDER);
    }

    @Override
    public void onDisable() {
        hits = new ArrayList<>();
    }

    private int colorFor(BlockEntity be) {
        if (be instanceof EnderChestBlockEntity) return ender.get() ? 0xFFBF5AF2 : 0;
        if (be instanceof ChestBlockEntity) return chests.get() ? 0xFFFF9F0A : 0;
        if (be instanceof BarrelBlockEntity) return barrels.get() ? 0xFFAC8E68 : 0;
        if (be instanceof ShulkerBoxBlockEntity) return shulkers.get() ? 0xFFFF2D92 : 0;
        if (be instanceof AbstractFurnaceBlockEntity) return furnaces.get() ? 0xFFAEAEB2 : 0;
        if (be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity) return hoppers.get() ? 0xFF64D2FF : 0;
        if (be instanceof MobSpawnerBlockEntity) return spawners.get() ? 0xFFFF453A : 0;
        return 0;
    }

    @Override
    public void onTick() {
        if (--timer > 0) return;
        timer = 10;
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        List<Hit> out = new ArrayList<>();
        int pcx = p.getBlockX() >> 4, pcz = p.getBlockZ() >> 4;
        int cr = (int) Math.ceil(range.get() / 16.0);
        double r2 = range.get() * range.get();
        for (int dx = -cr; dx <= cr; dx++) {
            for (int dz = -cr; dz <= cr; dz++) {
                Chunk ch = mc.world.getChunk(pcx + dx, pcz + dz, ChunkStatus.FULL, false);
                if (!(ch instanceof net.minecraft.world.chunk.WorldChunk)) continue;
                for (BlockEntity be : ((net.minecraft.world.chunk.WorldChunk) ch).getBlockEntities().values()) {
                    int col = colorFor(be);
                    if (col == 0) continue;
                    double ddx = be.getPos().getX() + 0.5 - p.getX(), ddy = be.getPos().getY() + 0.5 - p.getY(), ddz = be.getPos().getZ() + 0.5 - p.getZ();
                    if (ddx * ddx + ddy * ddy + ddz * ddz > r2) continue;
                    out.add(new Hit(new Box(be.getPos()).contract(0.06), col));
                }
            }
        }
        if (out.size() > 300) out = out.subList(0, 300);
        hits = out;
    }

    public void render(MinecraftClient mc, DrawContext ctx) {
        for (Hit h : hits) Esp.box3d(ctx, h.box(), h.color());
    }
}
