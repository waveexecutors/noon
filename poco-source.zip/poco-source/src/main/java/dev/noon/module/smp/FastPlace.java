package dev.noon.module.smp;

import dev.noon.mixin.MinecraftClientAccessor;
import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;

/** Removes / shortens the delay between placing blocks or using items. */
public class FastPlace extends Module {
    public static final FastPlace INSTANCE = new FastPlace();

    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 0, 4, 0, 1));

    private FastPlace() {
        super("FastPlace", Category.SMP);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        if (mc.player == null) return;
        MinecraftClientAccessor a = (MinecraftClientAccessor) mc;
        if (a.noon$getUseCooldown() > delay.i()) a.noon$setUseCooldown(delay.i());
    }
}
