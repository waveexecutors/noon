package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Throws a splash Instant Health potion at your feet when your health gets low. */
public class AutoPot extends Module {
    public static final AutoPot INSTANCE = new AutoPot();

    public final Setting.Num health = add(new Setting.Num("Health", 2, 18, 8, 1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 4, 40, 10, 1));

    private int cd;

    private AutoPot() {
        super("AutoPot", Category.COMBAT);
    }

    private static boolean healing(ItemStack s) {
        if (!s.isOf(Items.SPLASH_POTION)) return false;
        PotionContentsComponent pc = s.get(DataComponentTypes.POTION_CONTENTS);
        if (pc == null) return false;
        for (StatusEffectInstance e : pc.getEffects()) {
            if (e.getEffectType().equals(StatusEffects.INSTANT_HEALTH)) return true;
        }
        return false;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null || !p.isAlive()) return;
        if (cd > 0) {
            cd--;
            return;
        }
        if (p.getHealth() > health.get()) return;
        int slot = -1;
        for (int i = 0; i < 9; i++) if (healing(p.getInventory().getStack(i))) { slot = i; break; }
        if (slot < 0) return;
        int prev = p.getInventory().getSelectedSlot();
        float pitch = p.getPitch();
        p.getInventory().setSelectedSlot(slot);
        p.setPitch(90f);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.setPitch(pitch);
        p.getInventory().setSelectedSlot(prev);
        cd = delay.i();
    }
}
