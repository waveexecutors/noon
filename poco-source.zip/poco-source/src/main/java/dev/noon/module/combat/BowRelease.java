package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;

/** Releases the bow automatically at full draw so every arrow is a full-power shot. */
public class BowRelease extends Module {
    public static final BowRelease INSTANCE = new BowRelease();

    public final Setting.Num ticks = add(new Setting.Num("Draw Ticks", 5, 20, 20, 1));

    private BowRelease() {
        super("BowRelease", Category.COMBAT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (p.isUsingItem() && p.getActiveItem().isOf(Items.BOW) && p.getItemUseTime() >= ticks.i()) {
            mc.interactionManager.stopUsingItem(p);
        }
    }
}
