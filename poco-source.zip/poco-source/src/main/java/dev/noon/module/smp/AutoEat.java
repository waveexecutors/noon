package dev.noon.module.smp;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

/** Eats the best hotbar food when hungry (skips rotten flesh, pufferfish, etc.), then restores your slot. */
public class AutoEat extends Module {
    public static final AutoEat INSTANCE = new AutoEat();

    public final Setting.Num hunger = add(new Setting.Num("Eat Below (hunger)", 1, 19, 14, 1));
    public final Setting.Bool gapples = add(new Setting.Bool("Use Golden Apples", false));

    private boolean eating;
    private int prevSlot = -1, ticks;

    private AutoEat() {
        super("AutoEat", Category.SMP);
    }

    private static boolean bad(String id) {
        return id.equals("rotten_flesh") || id.equals("spider_eye") || id.equals("poisonous_potato") || id.equals("pufferfish")
                || id.equals("suspicious_stew") || id.equals("chorus_fruit") || id.equals("raw_chicken") || id.equals("chicken");
    }

    private int findFood(ClientPlayerEntity p) {
        int best = -1, bestN = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (st.isEmpty() || st.get(DataComponentTypes.FOOD) == null) continue;
            String id = Registries.ITEM.getId(st.getItem()).getPath();
            if (bad(id)) continue;
            boolean golden = id.contains("golden_apple") || id.equals("enchanted_golden_apple");
            if (golden && !gapples.get()) continue;
            int n = st.get(DataComponentTypes.FOOD).nutrition();
            if (n > bestN) {
                bestN = n;
                best = i;
            }
        }
        return best;
    }

    private void stop(MinecraftClient mc, ClientPlayerEntity p) {
        mc.options.useKey.setPressed(false);
        if (prevSlot >= 0) p.getInventory().setSelectedSlot(prevSlot);
        prevSlot = -1;
        eating = false;
        ticks = 0;
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = mc();
        if (eating && mc.player != null) stop(mc, mc.player);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        int food = p.getHungerManager().getFoodLevel();

        if (eating) {
            ticks++;
            boolean full = food >= 20;
            if ((!p.isUsingItem() && ticks > 4) || full || ticks > 80) stop(mc, p);
            else mc.options.useKey.setPressed(true);
            return;
        }
        if (food > hunger.i() || mc.options.attackKey.isPressed()) return;
        int slot = findFood(p);
        if (slot < 0) return;
        prevSlot = p.getInventory().getSelectedSlot();
        p.getInventory().setSelectedSlot(slot);
        mc.options.useKey.setPressed(true);
        eating = true;
        ticks = 0;
    }
}
