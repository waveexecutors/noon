package dev.noon.module.smp;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.render.Esp;
import dev.noon.util.Gfx;
import dev.noon.util.Sounds;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BeaconBlockEntity;
import net.minecraft.block.entity.BedBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BrewingStandBlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnchantingTableBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;

/**
 * BaseFinder: scores every loaded chunk by player-made stuff (storage, furnaces, beds, shulkers, redstone, concrete, glass...)
 * and groups high-scoring chunks into "bases". Results are remembered while you stay in the world, shown as
 * on-screen markers (with an edge arrow when off-screen) and in a HUD list. Incremental scan -> no lag spikes.
 */
public class BaseFinder extends Module {
    public static final BaseFinder INSTANCE = new BaseFinder();

    public final Setting.Num radius = add(new Setting.Num("Scan Radius (chunks)", 4, 32, 16, 1));
    public final Setting.Num minScore = add(new Setting.Num("Min Score", 3, 60, 10, 1));
    public final Setting.Num perTick = add(new Setting.Num("Chunks / Tick", 1, 32, 8, 1));
    public final Setting.Bool markers = add(new Setting.Bool("Markers", true));
    public final Setting.Bool list = add(new Setting.Bool("List", true));
    public final Setting.Bool tracer = add(new Setting.Bool("Tracer", false));
    public final Setting.Bool notify = add(new Setting.Bool("Chat Notify", true));
    public final Setting.Bool ping = add(new Setting.Bool("Sound", true));

    public record Base(int x, int y, int z, int score, int chunks) {}

    private final Map<Long, Integer> scores = new HashMap<>();
    private final Map<Long, Integer> scoredAt = new HashMap<>();
    private final Set<Long> announced = new HashSet<>();
    private volatile List<Base> bases = new ArrayList<>();
    private final Map<Long, Integer> yOf = new HashMap<>();
    private List<long[]> queue = new ArrayList<>();
    private int qi, nextFull, tick;
    private Object lastWorld;

    private List<Set<Block>> cats;
    private int[] catW;

    private BaseFinder() {
        super("BaseFinder", Category.SMP);
    }

    @Override
    public String suffix() {
        return bases.isEmpty() ? "" : Integer.toString(bases.size());
    }

    @Override
    public void onDisable() {
        reset();
    }

    private void reset() {
        scores.clear();
        scoredAt.clear();
        announced.clear();
        yOf.clear();
        queue = new ArrayList<>();
        qi = 0;
        nextFull = 0;
        bases = new ArrayList<>();
    }

    // ---- scoring ------------------------------------------------------------------------------

    private void buildCats() {
        List<Set<Block>> c = new ArrayList<>();
        List<Integer> w = new ArrayList<>();
        add(c, w, 3, b -> b.endsWith("_concrete") || b.endsWith("_concrete_powder"));
        add(c, w, 2, b -> b.endsWith("glass") || b.endsWith("glass_pane"));
        add(c, w, 2, b -> b.endsWith("glazed_terracotta"));
        add(c, w, 3, b -> b.equals("repeater") || b.equals("comparator") || b.equals("observer") || b.equals("piston")
                || b.equals("sticky_piston") || b.equals("redstone_lamp") || b.equals("redstone_wire") || b.equals("target"));
        add(c, w, 4, b -> b.equals("diamond_block") || b.equals("netherite_block") || b.equals("emerald_block")
                || b.equals("gold_block") || b.equals("iron_block") || b.equals("lapis_block") || b.equals("redstone_block")
                || b.equals("beacon") || b.equals("tnt") || b.equals("conduit"));
        add(c, w, 2, b -> b.equals("crafting_table") || b.equals("smithing_table") || b.equals("anvil")
                || b.equals("chipped_anvil") || b.equals("damaged_anvil") || b.equals("grindstone") || b.equals("stonecutter"));
        add(c, w, 2, b -> b.equals("smooth_stone") || b.equals("smooth_quartz") || b.equals("quartz_block")
                || b.equals("quartz_pillar") || b.startsWith("cut_") || b.equals("sea_lantern") || b.equals("end_rod"));
        add(c, w, 2, b -> b.equals("obsidian") || b.equals("crying_obsidian") || b.equals("respawn_anchor"));
        add(c, w, 1, b -> b.equals("ladder") || b.equals("scaffolding") || b.equals("cauldron") || b.equals("composter"));
        cats = c;
        catW = w.stream().mapToInt(Integer::intValue).toArray();
    }

    private static void add(List<Set<Block>> sets, List<Integer> w, int weight, Predicate<String> p) {
        Set<Block> s = new HashSet<>();
        for (Block b : Registries.BLOCK) {
            if (p.test(Registries.BLOCK.getId(b).getPath())) s.add(b);
        }
        sets.add(s);
        w.add(weight);
    }

    private static float beWeight(BlockEntity be) {
        if (be instanceof ShulkerBoxBlockEntity) return 4f;
        if (be instanceof BeaconBlockEntity) return 6f;
        if (be instanceof EnchantingTableBlockEntity) return 3f;
        if (be instanceof ChestBlockEntity) return 2f;
        if (be instanceof BarrelBlockEntity) return 2f;
        if (be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity) return 2f;
        if (be instanceof BrewingStandBlockEntity) return 2f;
        if (be instanceof AbstractFurnaceBlockEntity) return 1.5f;
        if (be instanceof EnderChestBlockEntity) return 1f;
        if (be instanceof BedBlockEntity) return 1f;
        if (be instanceof SignBlockEntity) return 1f;
        return 0f;
    }

    private int scoreChunk(Chunk ch, long key) {
        float s = 0f;
        int topY = Integer.MIN_VALUE;
        for (BlockEntity be : ((net.minecraft.world.chunk.WorldChunk) ch).getBlockEntities().values()) {
            float wgt = beWeight(be);
            if (wgt > 0f) {
                s += wgt;
                topY = Math.max(topY, be.getPos().getY());
            }
        }
        ChunkSection[] secs = ch.getSectionArray();
        for (int i = 0; i < secs.length; i++) {
            ChunkSection sec = secs[i];
            if (sec == null || sec.isEmpty()) continue;
            for (int k = 0; k < cats.size(); k++) {
                final Set<Block> set = cats.get(k);
                if (sec.hasAny((Predicate<BlockState>) st -> set.contains(st.getBlock()))) {
                    s += catW[k];
                    if (topY == Integer.MIN_VALUE) topY = ch.getBottomY() + i * 16 + 8;
                }
            }
        }
        if (topY != Integer.MIN_VALUE) yOf.put(key, topY);
        return Math.round(s);
    }

    private static long key(int x, int z) {
        return ((long) x << 32) ^ (z & 0xFFFFFFFFL);
    }

    private static int kx(long k) {
        return (int) (k >> 32);
    }

    private static int kz(long k) {
        return (int) k;
    }

    // ---- scanning -----------------------------------------------------------------------------

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null) return;
        if (w != lastWorld) {
            lastWorld = w;
            reset();
        }
        if (cats == null) buildCats();
        tick++;

        if (qi >= queue.size() && tick >= nextFull) {
            queue = new ArrayList<>();
            int pcx = p.getBlockX() >> 4, pcz = p.getBlockZ() >> 4;
            int r = radius.i();
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    int cx = pcx + dx, cz = pcz + dz;
                    Integer at = scoredAt.get(key(cx, cz));
                    if (at != null && tick - at < 600) continue; // recently scored
                    queue.add(new long[]{cx, cz, (long) dx * dx + (long) dz * dz});
                }
            }
            queue.sort((a, b) -> Long.compare(a[2], b[2]));
            qi = 0;
        }

        int done = 0;
        while (qi < queue.size() && done < perTick.i()) {
            long[] q = queue.get(qi++);
            Chunk ch = w.getChunk((int) q[0], (int) q[1], ChunkStatus.FULL, false);
            if (!(ch instanceof net.minecraft.world.chunk.WorldChunk)) continue;
            long k = key((int) q[0], (int) q[1]);
            scores.put(k, scoreChunk(ch, k));
            scoredAt.put(k, tick);
            done++;
        }
        if (qi >= queue.size() && done > 0 || tick % 100 == 0) {
            cluster(p);
            nextFull = tick + 40;
        }
    }

    private void cluster(ClientPlayerEntity p) {
        int min = minScore.i();
        List<long[]> hot = new ArrayList<>();
        for (Map.Entry<Long, Integer> e : scores.entrySet()) {
            if (e.getValue() >= Math.max(2, min / 2)) hot.add(new long[]{e.getKey(), e.getValue()});
        }
        hot.sort((a, b) -> Long.compare(b[1], a[1]));
        List<double[]> cl = new ArrayList<>(); // sumX, sumZ, weight, score, chunks, y
        for (long[] h : hot) {
            int cx = kx(h[0]), cz = kz(h[0]);
            double[] hit = null;
            for (double[] c : cl) {
                double mx = c[0] / c[2], mz = c[1] / c[2];
                if (Math.abs(mx - cx) <= 4 && Math.abs(mz - cz) <= 4) {
                    hit = c;
                    break;
                }
            }
            double wt = h[1];
            int y = yOf.getOrDefault(h[0], 64);
            if (hit == null) {
                cl.add(new double[]{cx * wt, cz * wt, wt, h[1], 1, y});
            } else {
                hit[0] += cx * wt;
                hit[1] += cz * wt;
                hit[2] += wt;
                hit[3] += h[1];
                hit[4] += 1;
            }
        }
        List<Base> out = new ArrayList<>();
        for (double[] c : cl) {
            if (c[3] < min) continue;
            int bx = (int) Math.round(c[0] / c[2] * 16 + 8), bz = (int) Math.round(c[1] / c[2] * 16 + 8);
            out.add(new Base(bx, (int) c[5], bz, (int) c[3], (int) c[4]));
        }
        out.sort((a, b) -> Double.compare(dist2(p, a), dist2(p, b)));
        for (Base b : out) {
            long ak = key(Math.floorDiv(b.x, 64), Math.floorDiv(b.z, 64));
            if (announced.add(ak)) {
                if (notify.get()) {
                    p.sendMessage(Text.literal("[Poco] Possible base at " + b.x + ", " + b.y + ", " + b.z + "  (score " + b.score + ", " + Math.round(Math.sqrt(dist2(p, b))) + "m)"), false);
                }
                if (ping.get()) Sounds.click();
            }
        }
        bases = out;
    }

    private static double dist2(ClientPlayerEntity p, Base b) {
        double dx = b.x - p.getX(), dz = b.z - p.getZ();
        return dx * dx + dz * dz;
    }

    // ---- rendering ----------------------------------------------------------------------------

    public void render(MinecraftClient mc, DrawContext ctx) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        List<Base> bs = bases;
        if (bs.isEmpty()) return;

        if (markers.get() || tracer.get()) {
            float[] o = new float[2];
            int n = 0;
            for (Base b : bs) {
                if (n++ >= 12) break;
                boolean front = Esp.project(b.x, b.y + 2, b.z, o);
                int dist = (int) Math.round(Math.sqrt(dist2(p, b)));
                String label = "Base  " + dist + "m";
                int lw = Gfx.width(label) + 16;
                int px = Math.round(o[0]), py = Math.round(o[1]);
                boolean on = front && px > lw / 2 && px < Esp.sw - lw / 2 && py > 12 && py < Esp.sh - 12;
                if (!on) {
                    px = Math.max(lw / 2 + 4, Math.min(Esp.sw - lw / 2 - 4, px));
                    py = Math.max(16, Math.min(Esp.sh - 16, py));
                }
                if (tracer.get()) Esp.line(ctx, Esp.sw / 2f, Esp.sh / 2f, px, py, Gfx.alpha(Gfx.ORANGE, 0.8f));
                if (markers.get()) {
                    Gfx.glass(ctx, px - lw / 2, py - 9, lw, 18, 9, on ? 1f : 0.75f);
                    Gfx.rrect(ctx, px - lw / 2 + 6, py - 2, 4, 4, 2, Gfx.ORANGE);
                    Gfx.text(ctx, label, px - lw / 2 + 13, py - 4, 0xFFFFFFFF);
                }
            }
        }

        if (list.get()) {
            int x = 6, y = 30;
            int w = 150;
            int rows = Math.min(5, bs.size());
            Gfx.glass(ctx, x, y, w, 18 + rows * 11, 10, 1f);
            Gfx.text(ctx, "Bases", x + 9, y + 6, 0xFF64B5FF);
            for (int i = 0; i < rows; i++) {
                Base b = bs.get(i);
                Gfx.text(ctx, b.x + ", " + b.z + "  [" + b.score + "]", x + 9, y + 18 + i * 11, 0xFFFFFFFF);
            }
        }
    }
}
