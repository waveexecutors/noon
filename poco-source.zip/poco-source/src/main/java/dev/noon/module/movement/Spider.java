package dev.noon.module.movement;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Climb walls by pushing into them. */
public class Spider extends Module {
    public static final Spider INSTANCE = new Spider();

    public final Setting.Num speed = add(new Setting.Num("Climb Speed", 0.05, 0.5, 0.2, 0.01));

    private Spider() {
        super("Spider", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || !p.horizontalCollision || !Move.moving(mc) || mc.options.sneakKey.isPressed()) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, speed.get(), v.z);
    }
}
