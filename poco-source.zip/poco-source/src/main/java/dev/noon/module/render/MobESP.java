package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.render.Esp;
import dev.noon.render.EntityDraw;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;

/** ESP for hostile / passive / neutral mobs and dropped items. */
public class MobESP extends Module {
    public static final MobESP INSTANCE = new MobESP();

    public final Setting.Mode style = add(new Setting.Mode("Style", 1, EntityDraw.STYLES));
    public final Setting.Bool hostile = add(new Setting.Bool("Hostile", true));
    public final Setting.Bool passive = add(new Setting.Bool("Passive", true));
    public final Setting.Bool neutral = add(new Setting.Bool("Neutral", false));
    public final Setting.Bool items = add(new Setting.Bool("Items", false));
    public final Setting.Bool health = add(new Setting.Bool("Health Bar", true));
    public final Setting.Bool name = add(new Setting.Bool("Name", true));
    public final Setting.Bool distance = add(new Setting.Bool("Distance", false));
    public final Setting.Num range = add(new Setting.Num("Range", 8, 128, 64, 4));

    private static final int HOSTILE = 0xFFFF453A, PASSIVE = 0xFF30D158, NEUTRAL = 0xFFFFD60A, ITEM = 0xFF64D2FF;

    private MobESP() {
        super("Mob ESP", Category.RENDER);
    }

    public void render(MinecraftClient mc, DrawContext ctx) {
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null) return;
        double r = range.get();
        for (Entity e : mc.world.getEntities()) {
            if (e == me || e instanceof PlayerEntity || e instanceof ArmorStandEntity || !e.isAlive()) continue;
            double d = me.distanceTo(e);
            if (d > r) continue;
            if (e instanceof LivingEntity le) {
                int col;
                if (le instanceof Monster) {
                    if (!hostile.get()) continue;
                    col = HOSTILE;
                } else if (le instanceof PassiveEntity) {
                    if (!passive.get()) continue;
                    col = PASSIVE;
                } else {
                    if (!neutral.get()) continue;
                    col = NEUTRAL;
                }
                EntityDraw.draw(ctx, le, style.index, col, false, health.get(), name.get(), distance.get(), false, d);
            } else if (items.get() && e instanceof ItemEntity ie) {
                Box b = Esp.lerped(ie);
                Esp.box3d(ctx, b.expand(0.05), ITEM);
                float[] o = new float[2];
                if (Esp.project((b.minX + b.maxX) / 2, b.maxY + 0.2, (b.minZ + b.maxZ) / 2, o) && name.get()) {
                    String s = ie.getStack().getName().getString() + (ie.getStack().getCount() > 1 ? " x" + ie.getStack().getCount() : "");
                    Esp.label(ctx, s, Math.round(o[0]), Math.round(o[1]) - 8, 0xFFFFFFFF);
                }
            }
        }
    }
}
