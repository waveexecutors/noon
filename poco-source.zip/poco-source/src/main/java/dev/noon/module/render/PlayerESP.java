package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.render.Esp;
import dev.noon.render.EntityDraw;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;

/** CS2-style player ESP: corner boxes, health bar with number, name, weapon, distance. */
public class PlayerESP extends Module {
    public static final PlayerESP INSTANCE = new PlayerESP();

    public final Setting.Mode style = add(new Setting.Mode("Style", 0, EntityDraw.STYLES));
    public final Setting.Mode color = add(new Setting.Mode("Color", 0, Esp.COLORS));
    public final Setting.Bool health = add(new Setting.Bool("Health Bar", true));
    public final Setting.Bool name = add(new Setting.Bool("Name", true));
    public final Setting.Bool weapon = add(new Setting.Bool("Held Item", true));
    public final Setting.Bool distance = add(new Setting.Bool("Distance", true));
    public final Setting.Bool fill = add(new Setting.Bool("Fill", false));
    public final Setting.Num range = add(new Setting.Num("Range", 16, 256, 128, 8));

    private PlayerESP() {
        super("Player ESP", Category.RENDER);
    }

    @Override
    public String suffix() {
        return style.get();
    }

    public void render(MinecraftClient mc, DrawContext ctx) {
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null) return;
        int i = 0;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == me || !p.isAlive() || p.isSpectator()) continue;
            double d = me.distanceTo(p);
            if (d > range.get()) continue;
            int col = Esp.color(color.index, d, range.get(), i++);
            EntityDraw.draw(ctx, p, style.index, col, fill.get(), health.get(), name.get(), distance.get(), weapon.get(), d);
        }
    }
}
