package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Attacks automatically when your crosshair is on a living entity and the weapon is charged. */
public class TriggerBot extends Module {
    public static final TriggerBot INSTANCE = new TriggerBot();

    public final Setting.Num cooldown = add(new Setting.Num("Cooldown", 0.5, 1.0, 0.95, 0.01));

    public final Setting.Bool players = add(new Setting.Bool("Players", true));
    public final Setting.Bool hostile = add(new Setting.Bool("Hostile Mobs", true));
    public final Setting.Bool passive = add(new Setting.Bool("Passive Mobs", false));

    private TriggerBot() {
        super("TriggerBot", Category.COMBAT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        if (mc.player == null || mc.currentScreen != null) return;
        HitResult hit = mc.crosshairTarget;
        if (!(hit instanceof EntityHitResult ehr)) return;
        if (!(ehr.getEntity() instanceof LivingEntity le) || !le.isAlive()) return;
        boolean ok = (players.get() && le instanceof net.minecraft.entity.player.PlayerEntity)
                || (hostile.get() && le instanceof net.minecraft.entity.mob.Monster)
                || (passive.get() && le instanceof net.minecraft.entity.passive.PassiveEntity);
        if (!ok) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < cooldown.f()) return;
        Criticals.attack(le);
    }
}
