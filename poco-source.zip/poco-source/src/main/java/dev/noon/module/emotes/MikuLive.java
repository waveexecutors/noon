package dev.noon.module.emotes;
public final class MikuLive extends EmoteModule { public static final MikuLive INSTANCE=new MikuLive(); private MikuLive(){super("Miku Live","miku_live");} }
