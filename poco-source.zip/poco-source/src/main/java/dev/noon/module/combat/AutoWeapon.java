package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;

/** Switches to your best melee weapon the moment you attack something. */
public class AutoWeapon extends Module {
    public static final AutoWeapon INSTANCE = new AutoWeapon();

    public final Setting.Mode prefer = add(new Setting.Mode("Prefer", 0, "Sword", "Axe"));
    public final Setting.Bool onlyAttacking = add(new Setting.Bool("Only While Attacking", true));

    private AutoWeapon() {
        super("AutoWeapon", Category.COMBAT);
    }

    @Override
    public String suffix() {
        return prefer.get();
    }

    private int score(ItemStack s) {
        boolean sword = s.isIn(ItemTags.SWORDS), axe = s.isIn(ItemTags.AXES);
        if (!sword && !axe) return 0;
        boolean pref = prefer.is("Sword") ? sword : axe;
        return (pref ? 20 : 10) + (s.getMaxDamage() > 0 ? Math.min(9, s.getMaxDamage() / 400) : 0);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (onlyAttacking.get() && !mc.options.attackKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult ehr) || !(ehr.getEntity() instanceof LivingEntity)) return;
        int cur = p.getInventory().getSelectedSlot(), best = cur, bestScore = score(p.getInventory().getStack(cur));
        for (int i = 0; i < 9; i++) {
            int sc = score(p.getInventory().getStack(i));
            if (sc > bestScore) {
                bestScore = sc;
                best = i;
            }
        }
        if (best != cur) p.getInventory().setSelectedSlot(best);
    }
}
