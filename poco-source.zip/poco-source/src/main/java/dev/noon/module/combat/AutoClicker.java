package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;

/** Holds left click -> clicks at a randomised CPS while your crosshair is on an entity. */
public class AutoClicker extends Module {
    public static final AutoClicker INSTANCE = new AutoClicker();

    public final Setting.Num minCps = add(new Setting.Num("Min CPS", 1, 20, 8, 1));
    public final Setting.Num maxCps = add(new Setting.Num("Max CPS", 1, 20, 12, 1));
    public final Setting.Bool cooldown = add(new Setting.Bool("Respect Cooldown", true));

    private float acc;

    private AutoClicker() {
        super("AutoClicker", Category.COMBAT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        if (mc.player == null || mc.currentScreen != null || !mc.options.attackKey.isPressed()) {
            acc = 0;
            return;
        }
        if (!(mc.crosshairTarget instanceof EntityHitResult ehr) || !(ehr.getEntity() instanceof LivingEntity le) || !le.isAlive()) return;
        double lo = Math.min(minCps.get(), maxCps.get()), hi = Math.max(minCps.get(), maxCps.get());
        double cps = lo + ThreadLocalRandom.current().nextDouble() * (hi - lo);
        acc += (float) (cps / 20.0);
        if (acc < 1f) return;
        acc -= 1f;
        if (cooldown.get() && mc.player.getAttackCooldownProgress(0.5f) < 0.9f) return;
        Criticals.attack(le);
    }
}
