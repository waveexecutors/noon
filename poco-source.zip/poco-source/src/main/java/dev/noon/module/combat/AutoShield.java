package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.math.MathHelper;

/** Raises your shield (hold use) while an armed player is close and facing you. Needs a shield in the offhand. */
public class AutoShield extends Module {
    public static final AutoShield INSTANCE = new AutoShield();

    public final Setting.Num range = add(new Setting.Num("Range", 2, 8, 4.5, 0.1));
    public final Setting.Num angle = add(new Setting.Num("Facing Angle", 10, 90, 45, 5));

    private boolean pressed;

    private AutoShield() {
        super("AutoShield", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        release();
    }

    private void release() {
        if (pressed) {
            mc().options.useKey.setPressed(false);
            pressed = false;
        }
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null || !p.getOffHandStack().isOf(Items.SHIELD)) {
            release();
            return;
        }
        boolean threat = false;
        for (PlayerEntity t : mc.world.getPlayers()) {
            if (t == p || !t.isAlive() || t.isSpectator() || p.distanceTo(t) > range.get()) continue;
            if (!t.getMainHandStack().isIn(ItemTags.SWORDS) && !t.getMainHandStack().isIn(ItemTags.AXES)) continue;
            double yawToMe = Math.toDegrees(Math.atan2(p.getZ() - t.getZ(), p.getX() - t.getX())) - 90.0;
            if (Math.abs(MathHelper.wrapDegrees((float) (yawToMe - t.getYaw()))) <= angle.get()) {
                threat = true;
                break;
            }
        }
        if (threat) {
            mc.options.useKey.setPressed(true);
            pressed = true;
        } else {
            release();
        }
    }
}
