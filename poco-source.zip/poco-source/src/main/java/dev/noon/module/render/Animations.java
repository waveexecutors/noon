package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

/** 10 swing animations each for attacking and mining (first-person). See HeldItemRendererMixin. */
public class Animations extends Module {
    private static final String[] NAMES = {
            "Vanilla", "Slash", "Spin", "Punch", "Smash", "Swipe", "Flip", "Wobble", "Bounce", "Pull", "Corkscrew",
            "Whip", "Chop", "Jab", "Windmill", "Sway", "Drop", "Yoyo", "Twirl", "Stab", "Orbit", "Shake", "Slam", "Spiral"
    };

    // NAMES must be declared BEFORE INSTANCE: static init runs top-to-bottom, otherwise the Mode settings get no options ("None")
    public static final Animations INSTANCE = new Animations();


    public final Setting.Mode attack = add(new Setting.Mode("Attack Anim", 1, NAMES));
    public final Setting.Mode mining = add(new Setting.Mode("Mining Anim", 2, NAMES));
    public final Setting.Num speed = add(new Setting.Num("Speed", 0.5, 2.5, 1.0, 0.05));
    public final Setting.Num intensity = add(new Setting.Num("Intensity", 0.3, 2.0, 1.0, 0.05));
    public final Setting.Bool idleSway = add(new Setting.Bool("Idle Sway", false));
    public final Setting.Num swayAmount = add(new Setting.Num("Sway Amount", 0.2, 3.0, 1.0, 0.1));
    public final Setting.Bool walkBob = add(new Setting.Bool("Walk Bob", false));
    public final Setting.Mode bobStyle = add(new Setting.Mode("Walk Bob Style", 0, "Smooth", "Swagger", "Bounce", "Figure 8", "Drift", "Stomp"));
    public final Setting.Num bobAmount = add(new Setting.Num("Walk Bob Amount", 0.3, 3.0, 1.0, 0.1));
    public final Setting.Bool lookSway = add(new Setting.Bool("Look Sway", false));
    public final Setting.Bool swingBoth = add(new Setting.Bool("Animate Off Hand", false));

    private Animations() {
        super("Animations", Category.RENDER);
        showInHud = false;
    }

    /** True when a custom swing replaces vanilla's (so the mixin zeroes vanilla's swing progress). */
    public static boolean overridesSwing() {
        Animations a = INSTANCE;
        if (!a.enabled) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean isMining = mc.interactionManager != null && mc.interactionManager.isBreakingBlock();
        return (isMining ? a.mining : a.attack).index != 0;
    }

    // shared per-frame state (idle() runs once per hand, so the clock is advanced only once per frame)
    private static long stT = System.nanoTime();
    private static float phase, amp, swayYaw, swayPitch, lastYaw, lastPitch;
    private static boolean stInit;

    private static void tickState(MinecraftClient mc) {
        long now = System.nanoTime();
        if (now - stT < 2_000_000L) return;
        float dt = Math.min(0.05f, (now - stT) / 1.0e9f);
        stT = now;
        var p = mc.player;
        double spd = p.getVelocity().horizontalLength();
        boolean moving = spd > 0.03 && p.isOnGround() && !p.isSneaking();
        float target = moving ? (float) Math.min(1.7, 0.45 + spd / 0.15 * 0.55) : 0f;
        amp += (target - amp) * (1f - (float) Math.exp(-(moving ? 9f : 6f) * dt));
        if (amp > 0.01f) phase += dt * (float) (5.5 + Math.min(0.3, spd) * 24.0);
        float yaw = p.getYaw(), pitch = p.getPitch();
        if (!stInit) {
            lastYaw = yaw;
            lastPitch = pitch;
            stInit = true;
        }
        float dyaw = net.minecraft.util.math.MathHelper.wrapDegrees(yaw - lastYaw), dpitch = pitch - lastPitch;
        lastYaw = yaw;
        lastPitch = pitch;
        float ty = net.minecraft.util.math.MathHelper.clamp(-dyaw / dt * 0.010f, -9f, 9f);
        float tp = net.minecraft.util.math.MathHelper.clamp(-dpitch / dt * 0.010f, -7f, 7f);
        float k = 1f - (float) Math.exp(-11f * dt);
        swayYaw += (ty - swayYaw) * k;
        swayPitch += (tp - swayPitch) * k;
    }

    /** Idle breathing, look sway and walking bob; independent of the swing animations. */
    private static void idle(Animations a, MinecraftClient mc, MatrixStack m, Hand hand, boolean mainArmIsRight) {
        if (mc.player == null) return;
        tickState(mc);
        double t = (System.nanoTime() / 1.0e9) * 1.6;
        float side = (hand == Hand.MAIN_HAND) == mainArmIsRight ? 1f : -1f;
        float k = a.swayAmount.f();
        if (a.idleSway.get()) {
            m.translate(0.004f * k * side * (float) Math.sin(t * 0.7), 0.006f * k * (float) Math.sin(t), 0f);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 0.9f * k * (float) Math.sin(t * 0.8)));
        }
        if (a.lookSway.get()) {
            m.translate(swayYaw * 0.006f, swayPitch * 0.006f, 0f);
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(swayYaw * 0.9f));
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-swayPitch * 0.9f));
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(swayYaw * 0.5f * side));
        }
        if (a.walkBob.get() && amp > 0.01f) {
            float A = amp * a.bobAmount.f();
            float ph = phase + (side < 0 ? (float) Math.PI : 0f); // hands move in opposite phase
            float s = (float) Math.sin(ph), c = (float) Math.cos(ph);
            float s2 = (float) Math.sin(ph * 2f), ab = Math.abs(s);
            switch (a.bobStyle.index) {
                case 1 -> { // Swagger: wide hip roll
                    m.translate(s * 0.030f * A, s2 * 0.010f * A, 0f);
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s * 5.5f * A));
                    m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(s * 4f * A));
                    m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-ab * 3f * A));
                }
                case 2 -> { // Bounce: springy hops
                    m.translate(0f, ab * 0.050f * A, -ab * 0.012f * A);
                    m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-ab * 5f * A));
                }
                case 3 -> { // Figure 8
                    m.translate(s * 0.034f * A, s2 * 0.022f * A, c * 0.008f * A);
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s * 3.5f * A));
                }
                case 4 -> { // Drift: slow floaty arc
                    float sl = (float) Math.sin(ph * 0.5f);
                    m.translate(sl * 0.045f * A, s * 0.016f * A, c * 0.018f * A);
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sl * 4.5f * A));
                    m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sl * 3f * A));
                }
                case 5 -> { // Stomp: sharp drop on every step
                    float hit = (float) Math.pow(Math.max(0f, -s), 3f);
                    m.translate(0f, -hit * 0.045f * A, hit * 0.015f * A);
                    m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(hit * 6f * A));
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s * 1.5f * A));
                }
                default -> { // Smooth
                    m.translate(s * 0.020f * A, -ab * 0.024f * A, 0f);
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s * 2.4f * A));
                    m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(ab * 1.6f * A));
                }
            }
        }
    }

    public static void apply(MatrixStack m, Hand hand, boolean mainArmIsRight, float swing) {
        Animations a = INSTANCE;
        if (!a.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        idle(a, mc, m, hand, mainArmIsRight);
        if ((hand != Hand.MAIN_HAND && !a.swingBoth.get()) || swing <= 0.001f) return;
        boolean isMining = mc.interactionManager != null && mc.interactionManager.isBreakingBlock();
        int idx = (isMining ? a.mining : a.attack).index;
        if (idx == 0) return;
        swing = Math.min(1f, swing * a.speed.f());

        float k = a.intensity.f();
        float side = mainArmIsRight ? 1f : -1f;
        float s = (float) Math.sin(swing * Math.PI);
        float px = 0.56f * side, py = -0.52f, pz = -0.72f;

        m.translate(px, py, pz);
        switch (idx) {
            case 1 -> { // Slash
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-side * 60f * s * k));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(20f * s * k));
            }
            case 2 -> m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(360f * swing * k)); // Spin
            case 3 -> m.translate(0f, 0f, -0.55f * s * k); // Punch
            case 4 -> m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-85f * s * k)); // Smash
            case 5 -> { // Swipe
                m.translate(-side * 0.5f * s * k, 0f, 0f);
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 45f * s * k));
            }
            case 6 -> m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(360f * swing * k)); // Flip
            case 7 -> m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees( // Wobble
                    (float) (28f * Math.sin(swing * Math.PI * 4.0) * (1f - swing) * k)));
            case 8 -> m.translate(0f, 0.3f * s * k, -0.1f * s * k); // Bounce
            case 9 -> { // Pull
                m.translate(0f, 0f, 0.45f * s * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(35f * s * k));
            }
            case 10 -> { // Corkscrew
                m.translate(0f, 0f, -0.3f * s * k);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(120f * s * k));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 40f * s * k));
            }
            case 11 -> { // Whip
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-side * 75f * (float) Math.sin(swing * Math.PI * 1.5) * k));
                m.translate(0f, 0f, -0.25f * s * k);
            }
            case 12 -> { // Chop
                m.translate(0f, 0.25f * (1f - swing) * s * k, -0.2f * s * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-70f * (float) Math.sin(Math.min(1f, swing * 1.4f) * Math.PI) * k));
            }
            case 13 -> m.translate(0f, 0f, -0.75f * (float) Math.pow(s, 3) * k); // Jab
            case 14 -> m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(360f * swing * k)); // Windmill
            case 15 -> { // Sway
                m.translate(side * 0.2f * (float) Math.sin(swing * Math.PI * 2) * k, 0f, 0f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 25f * (float) Math.sin(swing * Math.PI * 2) * k));
            }
            case 16 -> { // Drop
                m.translate(0f, -0.45f * s * k, 0.05f * s * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(25f * s * k));
            }
            case 17 -> { // Yoyo
                m.translate(0f, -0.3f * Math.abs((float) Math.sin(swing * Math.PI * 2)) * k, 0f);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-30f * s * k));
            }
            case 18 -> { // Twirl
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(720f * swing * k * (1f - 0.5f * swing)));
                m.translate(0f, 0.1f * s * k, 0f);
            }
            case 19 -> { // Stab
                m.translate(0f, 0.15f * s * k, -0.5f * s * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-25f * s * k));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 12f * s * k));
            }
            case 20 -> { // Orbit
                double ang = swing * Math.PI * 2;
                m.translate((float) Math.sin(ang) * 0.25f * k, (float) (1 - Math.cos(ang)) * 0.15f * k, 0f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * -40f * s * k));
            }
            case 21 -> { // Shake
                m.translate((float) Math.sin(swing * Math.PI * 10) * 0.04f * (1f - swing) * k, (float) Math.cos(swing * Math.PI * 12) * 0.03f * (1f - swing) * k, -0.1f * s * k);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) Math.sin(swing * Math.PI * 9) * 10f * (1f - swing) * k));
            }
            case 22 -> { // Slam
                float e = swing < 0.3f ? swing / 0.3f : 1f - (swing - 0.3f) / 0.7f;
                m.translate(0f, 0.2f * (swing < 0.3f ? e : 0f) * k - 0.3f * (swing >= 0.3f ? e : 0f) * k, -0.2f * s * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees((swing < 0.3f ? 30f * e : -95f * e) * k));
            }
            case 23 -> { // Spiral
                m.translate(0f, 0f, -0.35f * s * k);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 300f * swing * k));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-40f * s * k));
            }
            default -> {
            }
        }
        m.translate(-px, -py, -pz);
    }
}
