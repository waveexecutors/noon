package dev.noon.module.emotes;
public final class Jumpstyle extends EmoteModule { public static final Jumpstyle INSTANCE=new Jumpstyle(); private Jumpstyle(){super("Jumpstyle","jumpstyle");} }
