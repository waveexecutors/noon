package dev.noon.module.smp;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;

/** Leaves the server when your health drops too low. */
public class AutoLog extends Module {
    public static final AutoLog INSTANCE = new AutoLog();

    public final Setting.Num health = add(new Setting.Num("Health", 1, 19, 6, 1));

    private AutoLog() {
        super("AutoLog", Category.SMP);
    }

    @Override
    public String suffix() {
        return health.i() + " hp";
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || p.networkHandler == null || !p.isAlive()) return;
        if (p.getHealth() + p.getAbsorptionAmount() <= health.get()) {
            setEnabled(false);
            p.networkHandler.getConnection().disconnect(Text.literal("[Poco] AutoLog: health " + Math.round(p.getHealth())));
        }
    }
}
