package dev.noon.module.client;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.util.Anim;
import dev.noon.util.Gfx;
import java.util.WeakHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.PressableWidget;
import net.minecraft.text.Text;

/** Glass, animated pause menu. Buttons are drawn by PressableWidgetMixin through drawButton(). */
public class GlassMenu extends Module {
    public static final GlassMenu INSTANCE = new GlassMenu();

    private static final class State {
        final Anim hover = new Anim();
        final Anim appear = new Anim();
    }

    private static final WeakHashMap<PressableWidget, State> STATES = new WeakHashMap<>();
    private static final Anim PANEL = new Anim();
    private static Screen lastScreen;

    private GlassMenu() {
        super("Glass Menu", Category.CLIENT);
        showInHud = false;
        enabled = true;
        toggle.v = 1f;
    }

    public static boolean active() {
        return INSTANCE.enabled && MinecraftClient.getInstance().currentScreen instanceof GameMenuScreen;
    }

    public static void drawButton(DrawContext ctx, PressableWidget w) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Screen screen = mc.currentScreen;
        if (screen == null) return;
        if (screen != lastScreen) {
            lastScreen = screen;
            PANEL.v = 0f;
        }

        // draw the backing panel once per frame, before the first button
        PressableWidget first = null;
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE;
        for (Element e : screen.children()) {
            if (e instanceof PressableWidget pw) {
                if (first == null) first = pw;
                minX = Math.min(minX, pw.getX());
                minY = Math.min(minY, pw.getY());
                maxX = Math.max(maxX, pw.getX() + pw.getWidth());
                maxY = Math.max(maxY, pw.getY() + pw.getHeight());
            }
        }
        if (first == w) {
            float pa = PANEL.to(1f, 6f);
            int off = (int) ((1f - pa) * 14);
            Gfx.glass(ctx, minX - 18, minY - 10 + off, (maxX - minX) + 36, (maxY - minY) + 28, 18, pa);
        }

        State s = STATES.computeIfAbsent(w, k -> new State());
        float ap = s.appear.to(1f, 6f);
        float hv = s.hover.to(w.isHovered() && w.active ? 1f : 0f, 14f);

        int grow = Math.round(hv * 2f);
        int x = w.getX() - grow;
        int y = w.getY() + Math.round((1f - ap) * 10f) - grow;
        int ww = w.getWidth() + grow * 2;
        int hh = w.getHeight() + grow * 2;

        int base = Gfx.lerp(0x2EFFFFFF, 0x55FFFFFF, hv);
        Gfx.rrect(ctx, x, y, ww, hh, hh / 2, Gfx.alpha(0x40FFFFFF, ap));
        Gfx.rrect(ctx, x + 1, y + 1, ww - 2, hh - 2, Math.max(0, hh / 2 - 1), Gfx.alpha(0x99181822, ap));
        Gfx.rrect(ctx, x + 1, y + 1, ww - 2, hh - 2, Math.max(0, hh / 2 - 1), Gfx.alpha(base, ap));
        if (hv > 0.01f) {
            Gfx.rrect(ctx, x + 1, y + 1, ww - 2, hh - 2, Math.max(0, hh / 2 - 1), Gfx.alpha(Gfx.ACCENT & 0x00FFFFFF | 0x33000000, hv * ap));
        }

        TextRenderer tr = mc.textRenderer;
        Text msg = w.getMessage();
        int color = w.active ? Gfx.alpha(Gfx.WHITE, ap) : Gfx.alpha(0xFF8E8E93, ap);
        ctx.drawText(tr, msg, x + (ww - tr.getWidth(msg)) / 2, y + (hh - 8) / 2, color, false);
    }
}
