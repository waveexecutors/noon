package dev.noon.module.player;

import dev.noon.module.Category;
import dev.noon.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** Switches to the fastest hotbar tool for the block you are mining. */
public class AutoTool extends Module {
    public static final AutoTool INSTANCE = new AutoTool();

    private AutoTool() {
        super("AutoTool", Category.PLAYER);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null || !mc.options.attackKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;

        BlockState state = mc.world.getBlockState(hit.getBlockPos());
        int current = p.getInventory().getSelectedSlot();
        float bestSpeed = p.getInventory().getStack(current).getMiningSpeedMultiplier(state);
        int best = -1;
        for (int i = 0; i < 9; i++) {
            float sp = p.getInventory().getStack(i).getMiningSpeedMultiplier(state);
            if (sp > bestSpeed) {
                bestSpeed = sp;
                best = i;
            }
        }
        if (best >= 0) p.getInventory().setSelectedSlot(best);
    }
}
