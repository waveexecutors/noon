package dev.noon.module.movement;

import dev.noon.module.Category;
import dev.noon.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public class AutoSprint extends Module {
    public static final AutoSprint INSTANCE = new AutoSprint();

    public final dev.noon.module.Setting.Num minHunger = add(new dev.noon.module.Setting.Num("Min Hunger", 0, 20, 6, 1));

    private AutoSprint() {
        super("AutoSprint", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || dev.noon.module.combat.WTap.active()) return;
        if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision
                && p.getHungerManager().getFoodLevel() > minHunger.i()) {
            p.setSprinting(true);
        }
    }
}
