package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Jumps the moment you get hit while on the ground, which cuts the horizontal knockback you take. */
public class JumpReset extends Module {
    public static final JumpReset INSTANCE = new JumpReset();

    private JumpReset() {
        super("JumpReset", Category.COMBAT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p == null || mc().currentScreen != null) return;
        if (p.hurtTime > 0 && p.hurtTime >= p.maxHurtTime - 1 && p.isOnGround()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.42, v.z);
        }
    }
}
