package dev.noon.module.movement;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Creative-style flight (Vanilla) or a slow controlled fall (Glide). Most servers kick for flying - use at your own risk. */
public class Flight extends Module {
    public static final Flight INSTANCE = new Flight();

    public final Setting.Mode mode = add(new Setting.Mode("Mode", 0, "Vanilla", "Glide"));
    public final Setting.Num speed = add(new Setting.Num("Speed", 0.05, 2.0, 0.6, 0.05));
    public final Setting.Num vertical = add(new Setting.Num("Vertical Speed", 0.05, 1.5, 0.4, 0.05));
    public final Setting.Num glideFall = add(new Setting.Num("Glide Fall", 0.0, 0.3, 0.04, 0.01));

    private Flight() {
        super("Flight", Category.MOVEMENT);
    }

    @Override
    public String suffix() {
        return mode.get();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || p.isGliding()) return;
        double[] d = Move.dir(mc, p);
        Vec3d v = p.getVelocity();
        if (mode.is("Glide")) {
            if (!p.isOnGround() && v.y < -glideFall.get()) {
                p.setVelocity(v.x, -glideFall.get(), v.z);
            }
            return;
        }
        double vy = 0;
        if (mc.options.jumpKey.isPressed()) vy += vertical.get();
        if (mc.options.sneakKey.isPressed()) vy -= vertical.get();
        p.setVelocity(d[0] * speed.get(), vy, d[1] * speed.get());
        p.fallDistance = 0;
    }
}
