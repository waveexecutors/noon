package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

/** Fills empty armor slots from your inventory (shift-click), e.g. right after armor breaks. */
public class AutoArmor extends Module {
    public static final AutoArmor INSTANCE = new AutoArmor();

    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 1, 20, 4, 1));
    private int timer;

    private AutoArmor() {
        super("AutoArmor", Category.COMBAT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (--timer > 0) return;
        timer = delay.i();

        for (int s = 0; s < SLOTS.length; s++) {
            EquipmentSlot es = SLOTS[s];
            if (!p.getEquippedStack(es).isEmpty()) continue;
            for (int i = 0; i < 36; i++) {
                ItemStack st = p.getInventory().getStack(i);
                if (st.isEmpty() || p.getPreferredEquipmentSlot(st) != es) continue;
                int slot = i < 9 ? 36 + i : i;
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 0, SlotActionType.QUICK_MOVE, p);
                return;
            }
        }
    }
}
