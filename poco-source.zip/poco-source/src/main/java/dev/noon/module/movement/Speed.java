package dev.noon.module.movement;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Horizontal speed boost. Bhop jumps for you and keeps full air control, Ground only changes speed while grounded. */
public class Speed extends Module {
    public static final Speed INSTANCE = new Speed();

    public final Setting.Mode mode = add(new Setting.Mode("Mode", 0, "Bhop", "Ground", "Strafe"));
    public final Setting.Num speed = add(new Setting.Num("Speed", 0.15, 1.2, 0.34, 0.01));
    public final Setting.Bool sprintOnly = add(new Setting.Bool("Only While Sprinting", false));

    private Speed() {
        super("Speed", Category.MOVEMENT);
    }

    @Override
    public String suffix() {
        return mode.get();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || p.isTouchingWater() || p.isInLava() || p.isClimbing() || p.isGliding()) return;
        if (!Move.moving(mc) || (sprintOnly.get() && !p.isSprinting())) return;
        double[] d = Move.dir(mc, p);
        Vec3d v = p.getVelocity();
        switch (mode.index) {
            case 0 -> { // Bhop
                if (p.isOnGround()) p.jump();
                v = p.getVelocity();
                p.setVelocity(d[0] * speed.get(), v.y, d[1] * speed.get());
            }
            case 1 -> { // Ground
                if (p.isOnGround()) p.setVelocity(d[0] * speed.get(), v.y, d[1] * speed.get());
            }
            default -> { // Strafe: redirect the current speed to where you are steering
                double cur = Math.max(Math.sqrt(v.x * v.x + v.z * v.z), speed.get() * 0.8);
                p.setVelocity(d[0] * cur, v.y, d[1] * cur);
            }
        }
    }
}
