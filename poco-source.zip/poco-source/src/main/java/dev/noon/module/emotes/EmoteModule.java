package dev.noon.module.emotes;
import dev.noon.module.Module;import dev.noon.module.Category;import dev.noon.module.Setting;import dev.noon.emote.*;
public abstract class EmoteModule extends Module {
 public final Setting.Bool loop=add(new Setting.Bool("Loop Emote",true));
 public final Setting.Bool walking=add(new Setting.Bool("Play While Walking",true));
 public final Setting.Bool running=add(new Setting.Bool("Play While Running",true));
 private final String id;
 protected EmoteModule(String title,String id){super(title,Category.EMOTES);this.id=id;}
 @Override public void onEnable(){EmoteAnimation clip=EmoteLoader.loadAll().get(id);if(clip!=null)EmoteController.get().play(clip,loop.get());}
 @Override public void onTick(){
  if(!enabled||EmoteController.get().current()==null||!EmoteController.get().current().name().equals(id))return;
  var player=mc().player;if(player==null){EmoteController.get().stop();return;}
  boolean moving=player.getVelocity().horizontalLengthSquared()>0.001;
  boolean blocked=player.isSprinting()?!running.get():!walking.get();
  EmoteController.get().pause(moving&&blocked);
 }
 @Override public void onDisable(){if(EmoteController.get().current()!=null && EmoteController.get().current().name().equals(id))EmoteController.get().stop();}
}
