package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;

/**
 * Shared crystal PvP logic: finds the best obsidian/bedrock spot next to the target, places a crystal, breaks it.
 * Legit mode behaves like a human: smooth aim, crosshair must actually be on the thing, randomised delays, no switching.
 */
public abstract class CrystalCore extends Module {
    public final Setting.Num targetRange = add(new Setting.Num("Target Range", 3, 15, 10, 1));
    public final Setting.Num placeRange = add(new Setting.Num("Place Range", 2, 6, 4.5, 0.1));
    public final Setting.Num breakRange = add(new Setting.Num("Break Range", 2, 6, 4.5, 0.1));
    public final Setting.Num minDamage = add(new Setting.Num("Min Damage", 1, 20, 5, 0.5));
    public final Setting.Num maxSelf = add(new Setting.Num("Max Self Dmg", 1, 36, 10, 0.5));
    public final Setting.Bool antiSuicide = add(new Setting.Bool("Anti Suicide", true));
    public final Setting.Bool tradeForKill = add(new Setting.Bool("Allow Self Dmg For Kill", true));
    public final Setting.Bool autoObby = add(new Setting.Bool("Auto Obsidian", true));
    public final Setting.Num placeDelay = add(new Setting.Num("Place Delay (ticks)", 0, 10, 1, 1));
    public final Setting.Num breakDelay = add(new Setting.Num("Break Delay (ticks)", 0, 10, 1, 1));
    public final Setting.Bool place = add(new Setting.Bool("Place", true));
    public final Setting.Bool breakC = add(new Setting.Bool("Break", true));
    public final Setting.Bool rotate = add(new Setting.Bool("Rotate", true));
    public final Setting.Num rotSpeed = add(new Setting.Num("Rotation Speed (deg/tick)", 5, 180, 60, 5));
    public final Setting.Bool legit = add(new Setting.Bool("Legit Mode", false));
    public final Setting.Num jitter = add(new Setting.Num("Legit Delay Jitter %", 0, 200, 60, 5));
    public final Setting.Num missChance = add(new Setting.Num("Legit Miss Chance %", 0, 30, 6, 1));
    public final Setting.Bool onlyHolding = add(new Setting.Bool("Only When Holding Crystal", false));
    public final Setting.Bool swing = add(new Setting.Bool("Swing", true));

    protected final boolean silent;
    private int placeT, breakT;
    private float ry, rp;
    private boolean engaged;

    protected CrystalCore(String name, boolean silent) {
        super(name, Category.COMBAT);
        this.silent = silent;
        if (silent) {
            rotSpeed.set(90);
        }
    }

    @Override
    public void onDisable() {
        engaged = false;
    }

    // ---- helpers ------------------------------------------------------------------------------

    /**
     * Estimated crystal damage to e (vanilla formula incl. difficulty, armor, toughness and Resistance; assumes full exposure,
     * so it errs on the safe side for us and slightly optimistic for the target).
     */
    private static double est(LivingEntity e, double cx, double cy, double cz) {
        double dx = e.getX() - cx, dy = e.getY() - cy, dz = e.getZ() - cz;
        double d = Math.sqrt(dx * dx + dy * dy + dz * dz) / 12.0;
        if (d > 1.0) return 0;
        double imp = 1.0 - d;
        double raw = (imp * imp + imp) / 2.0 * 7.0 * 12.0 + 1.0;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (e instanceof PlayerEntity && mc.world != null) {
            Difficulty df = mc.world.getDifficulty();
            if (df == Difficulty.EASY) raw = Math.min(raw / 2.0 + 1.0, raw);
            else if (df == Difficulty.HARD) raw *= 1.5;
        }
        double armor = e.getArmor();
        double tough = e.getAttributeValue(EntityAttributes.ARMOR_TOUGHNESS);
        double red = MathHelper.clamp(armor - raw / (2.0 + tough / 4.0), armor * 0.2, 20.0);
        raw *= 1.0 - red / 25.0;
        StatusEffectInstance res = e.getStatusEffect(StatusEffects.RESISTANCE);
        if (res != null) raw *= Math.max(0, 25 - (res.getAmplifier() + 1) * 5) / 25.0;
        return Math.max(0, raw);
    }

    /** Is a crystal that deals t to the target and s to us worth it? (lethal trades may cost us more health) */
    private boolean worth(double t, double s, double selfHp, double targetHp, double minT) {
        if (t < minT) return false;
        boolean kill = tradeForKill.get() && t >= targetHp;
        if (antiSuicide.get() && s >= selfHp - 1) return false;
        return kill || s <= maxSelf.get();
    }

    private int delay(int base) {
        if (!legit.get()) return base;
        double j = ThreadLocalRandom.current().nextDouble() * jitter.get() / 100.0;
        return Math.max(1, (int) Math.round(base * (1.0 + j)));
    }

    private boolean aim(ClientPlayerEntity p, Vec3d to) {
        if (!rotate.get()) return true;
        Vec3d eye = p.getEyePos();
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        float ty = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float tp = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        boolean real = legit.get() && !silent; // legit + non-silent moves your real camera like a player would
        if (!engaged) {
            ry = p.getYaw();
            rp = p.getPitch();
            engaged = true;
        }
        float sp = legit.get() ? Math.min(rotSpeed.f(), 45f) : rotSpeed.f();
        float dyaw = MathHelper.wrapDegrees(ty - ry), dp = tp - rp;
        ry += MathHelper.clamp(dyaw, -sp, sp);
        rp = MathHelper.clamp(rp + MathHelper.clamp(dp, -sp, sp), -90f, 90f);
        if (real) {
            p.setYaw(ry);
            p.setPitch(rp);
        } else if (silent) {
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(ry, rp, p.isOnGround(), p.horizontalCollision));
        } else {
            p.setYaw(ry);
            p.setPitch(rp);
        }
        float tol = legit.get() ? 4f : 12f;
        return Math.abs(MathHelper.wrapDegrees(ty - ry)) <= tol && Math.abs(tp - rp) <= tol;
    }

    private int crystalSlot(ClientPlayerEntity p) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(Items.END_CRYSTAL)) return i;
        return -1;
    }

    // ---- main loop ----------------------------------------------------------------------------

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (placeT > 0) placeT--;
        if (breakT > 0) breakT--;

        PlayerEntity target = null;
        double best = targetRange.get();
        for (PlayerEntity t : mc.world.getPlayers()) {
            if (t == p || !t.isAlive() || t.isSpectator()) continue;
            double d = p.distanceTo(t);
            if (d <= best) {
                best = d;
                target = t;
            }
        }
        if (target == null) {
            engaged = false;
            return;
        }

        double selfHp = p.getHealth() + p.getAbsorptionAmount();
        double targetHp = target.getHealth() + target.getAbsorptionAmount();
        boolean acted = false;

        // ---- break ----
        if (breakC.get() && breakT <= 0) {
            EndCrystalEntity bc = null;
            double bestScore = -1e9;
            Box area = p.getBoundingBox().expand(breakRange.get() + 1);
            for (EndCrystalEntity c : mc.world.getEntitiesByClass(EndCrystalEntity.class, area, e -> true)) {
                if (p.getEyePos().distanceTo(c.getBoundingBox().getCenter()) > breakRange.get()) continue;
                double t = est(target, c.getX(), c.getY(), c.getZ()), s = est(p, c.getX(), c.getY(), c.getZ());
                if (!worth(t, s, selfHp, targetHp, 1.5)) continue;
                double score = t - s * 0.5 + (t >= targetHp ? 1000 : 0);
                if (score > bestScore) {
                    bestScore = score;
                    bc = c;
                }
            }
            if (bc != null) {
                acted = true;
                boolean aligned = aim(p, bc.getBoundingBox().getCenter());
                boolean gate = !legit.get() || silent || (mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() == bc);
                if (aligned && gate) {
                    if (!(legit.get() && ThreadLocalRandom.current().nextInt(100) < missChance.i())) {
                        Criticals.rawAttack(bc);
                        if (!swing.get()) { /* rawAttack always swings; kept simple */ }
                    }
                    breakT = delay(breakDelay.i());
                }
            }
        }

        // ---- place ----
        if (place.get() && placeT <= 0 && !acted) {
            Hand hand = null;
            int slot = -1;
            if (p.getOffHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.OFF_HAND;
            else if (p.getMainHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.MAIN_HAND;
            else if (!legit.get() && !onlyHolding.get()) {
                slot = crystalSlot(p);
                if (slot >= 0) hand = Hand.MAIN_HAND;
            }
            if (hand == null) {
                if (!acted) engaged = false;
                return;
            }

            BlockPos bp = null;
            double bs = -1e9;
            boolean haveBase = false; // any obsidian / bedrock spot near the target at all (else Auto Obsidian kicks in)
            BlockPos o = p.getBlockPos();
            int r = (int) Math.ceil(placeRange.get());
            for (int x = -r; x <= r; x++) {
                for (int y = -r; y <= r; y++) {
                    for (int z = -r; z <= r; z++) {
                        BlockPos b = o.add(x, y, z);
                        if (!(mc.world.getBlockState(b).isOf(Blocks.OBSIDIAN) || mc.world.getBlockState(b).isOf(Blocks.BEDROCK))) continue;
                        if (!mc.world.getBlockState(b.up()).isAir() || !mc.world.getBlockState(b.up(2)).isAir()) continue;
                        double cx = b.getX() + 0.5, cy = b.getY() + 1.0, cz = b.getZ() + 0.5;
                        if (p.getEyePos().distanceTo(new Vec3d(cx, cy, cz)) > placeRange.get()) continue;
                        double tdx = target.getX() - cx, tdy = target.getY() - cy, tdz = target.getZ() - cz;
                        if (tdx * tdx + tdy * tdy + tdz * tdz <= 25.0) haveBase = true;
                        double t = est(target, cx, cy, cz), s = est(p, cx, cy, cz);
                        if (!worth(t, s, selfHp, targetHp, minDamage.get())) continue;
                        if (!mc.world.getOtherEntities(null, new Box(b.getX(), b.getY() + 1, b.getZ(), b.getX() + 1, b.getY() + 3, b.getZ() + 1)).isEmpty()) continue;
                        double score = t - s * 0.5 + (t >= targetHp ? 1000 : 0);
                        if (score > bs) {
                            bs = score;
                            bp = b;
                        }
                    }
                }
            }
            if (bp == null) {
                if (autoObby.get() && !haveBase) placeObsidian(mc, p, target, selfHp, targetHp);
                else engaged = false;
                return;
            }
            Vec3d top = new Vec3d(bp.getX() + 0.5, bp.getY() + 1.0, bp.getZ() + 0.5);
            boolean aligned = aim(p, top);
            boolean gate = !legit.get() || silent
                    || (mc.crosshairTarget instanceof BlockHitResult bh && bh.getBlockPos().equals(bp));
            if (aligned && gate) {
                if (legit.get() && ThreadLocalRandom.current().nextInt(100) < missChance.i()) {
                    placeT = delay(placeDelay.i());
                    return;
                }
                int prev = p.getInventory().getSelectedSlot();
                if (slot >= 0) p.getInventory().setSelectedSlot(slot);
                mc.interactionManager.interactBlock(p, hand, new BlockHitResult(top, Direction.UP, bp, false));
                if (swing.get()) p.swingHand(hand);
                if (slot >= 0 && silent) p.getInventory().setSelectedSlot(prev); // silent switch: back the same tick
                placeT = delay(placeDelay.i());
            }
        }
    }

    private int obbySlot(ClientPlayerEntity p) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(Items.OBSIDIAN)) return i;
        return -1;
    }

    /**
     * No obsidian / bedrock near the target: put an obsidian block on the ground next to them (best crystal spot by damage), so
     * the normal place / break loop can take over on the next tick. Needs obsidian in the hotbar.
     */
    private void placeObsidian(MinecraftClient mc, ClientPlayerEntity p, PlayerEntity target, double selfHp, double targetHp) {
        Hand hand = null;
        int slot = -1;
        if (p.getOffHandStack().isOf(Items.OBSIDIAN)) hand = Hand.OFF_HAND;
        else if (p.getMainHandStack().isOf(Items.OBSIDIAN)) hand = Hand.MAIN_HAND;
        else if (!legit.get()) {
            slot = obbySlot(p);
            if (slot >= 0) hand = Hand.MAIN_HAND;
        }
        if (hand == null) {
            engaged = false;
            return;
        }
        BlockPos tb = target.getBlockPos();
        BlockPos best = null;
        double bs = -1e9;
        for (int x = -3; x <= 3; x++) {
            for (int z = -3; z <= 3; z++) {
                for (int y = -1; y <= 1; y++) {
                    BlockPos b = tb.add(x, y, z);
                    BlockPos ground = b.down();
                    if (!mc.world.getBlockState(b).isReplaceable() || !mc.world.getBlockState(b.up()).isAir()
                            || !mc.world.getBlockState(b.up(2)).isAir()) continue;
                    if (mc.world.getBlockState(ground).isAir() || !mc.world.getBlockState(ground).isSolidBlock(mc.world, ground)) continue;
                    double cx = b.getX() + 0.5, cy = b.getY() + 1.0, cz = b.getZ() + 0.5;
                    if (p.getEyePos().distanceTo(new Vec3d(cx, b.getY() + 0.5, cz)) > placeRange.get()) continue;
                    if (!mc.world.getOtherEntities(null, new Box(b)).isEmpty()) continue;
                    double t = est(target, cx, cy, cz), s = est(p, cx, cy, cz);
                    if (!worth(t, s, selfHp, targetHp, minDamage.get())) continue;
                    double score = t - s * 0.5 + (t >= targetHp ? 1000 : 0);
                    if (score > bs) {
                        bs = score;
                        best = b;
                    }
                }
            }
        }
        if (best == null) {
            engaged = false;
            return;
        }
        BlockPos ground = best.down();
        Vec3d top = new Vec3d(best.getX() + 0.5, best.getY(), best.getZ() + 0.5);
        boolean aligned = aim(p, top);
        boolean gate = !legit.get() || silent
                || (mc.crosshairTarget instanceof BlockHitResult bh && bh.getBlockPos().equals(ground));
        if (aligned && gate) {
            int prev = p.getInventory().getSelectedSlot();
            if (slot >= 0) p.getInventory().setSelectedSlot(slot);
            mc.interactionManager.interactBlock(p, hand, new BlockHitResult(top, Direction.UP, ground, false));
            if (swing.get()) p.swingHand(hand);
            if (slot >= 0 && silent) p.getInventory().setSelectedSlot(prev);
            placeT = Math.max(2, delay(placeDelay.i()));
        }
    }
}
