package dev.noon.module.combat;

/** Crystal aura: auto place + break. Turn on "Legit Mode" to make it play like a real CPvP player. */
public class CrystalAura extends CrystalCore {
    public static final CrystalAura INSTANCE = new CrystalAura();

    private CrystalAura() {
        super("CrystalAura", false);
    }
}
