package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;

/** Swaps to an axe when the player under your crosshair is blocking with a shield (and optionally hits them). */
public class ShieldBreaker extends Module {
    public static final ShieldBreaker INSTANCE = new ShieldBreaker();

    public final Setting.Bool attack = add(new Setting.Bool("Auto Hit", true));
    public final Setting.Bool swapBack = add(new Setting.Bool("Swap Back", true));

    private int prevSlot = -1;

    private ShieldBreaker() {
        super("ShieldBreaker", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        prevSlot = -1;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        PlayerEntity target = mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() instanceof PlayerEntity pe ? pe : null;
        if (target != null && target.isBlocking() && target.isAlive()) {
            int axe = -1;
            for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isIn(ItemTags.AXES)) { axe = i; break; }
            if (axe < 0) return;
            if (prevSlot < 0) prevSlot = p.getInventory().getSelectedSlot();
            p.getInventory().setSelectedSlot(axe);
            if (attack.get() && p.getAttackCooldownProgress(0.5f) >= 0.95f) Criticals.attack(target);
        } else if (prevSlot >= 0) {
            if (swapBack.get()) p.getInventory().setSelectedSlot(prevSlot);
            prevSlot = -1;
        }
    }
}
