package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;

/** Ignores knockback velocity packets sent for your player. See ClientPlayNetworkHandlerMixin. */
public class Velocity extends Module {
    public static final Velocity INSTANCE = new Velocity();

    public final dev.noon.module.Setting.Num chance = add(new dev.noon.module.Setting.Num("Chance %", 0, 100, 100, 5));

    private Velocity() {
        super("Velocity", Category.COMBAT);
    }
}
