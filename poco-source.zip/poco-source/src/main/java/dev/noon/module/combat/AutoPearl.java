package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Escape: when you are low and an enemy is close, throws an ender pearl in the opposite direction. */
public class AutoPearl extends Module {
    public static final AutoPearl INSTANCE = new AutoPearl();

    public final Setting.Num health = add(new Setting.Num("Health", 2, 14, 6, 1));
    public final Setting.Num enemyRange = add(new Setting.Num("Enemy Range", 2, 12, 6, 0.5));
    public final Setting.Num pitch = add(new Setting.Num("Throw Pitch", -60, 0, -35, 1));

    private int cd;

    private AutoPearl() {
        super("AutoPearl", Category.COMBAT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (cd > 0) {
            cd--;
            return;
        }
        if (p.getHealth() > health.get() || p.getItemCooldownManager().isCoolingDown(Items.ENDER_PEARL.getDefaultStack())) return;
        PlayerEntity enemy = null;
        double bd = enemyRange.get();
        for (PlayerEntity t : mc.world.getPlayers()) {
            if (t == p || !t.isAlive() || t.isSpectator()) continue;
            double d = p.distanceTo(t);
            if (d < bd) {
                bd = d;
                enemy = t;
            }
        }
        if (enemy == null) return;
        int slot = -1;
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(Items.ENDER_PEARL)) { slot = i; break; }
        if (slot < 0) return;
        double dx = enemy.getX() - p.getX(), dz = enemy.getZ() - p.getZ();
        float away = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0) + 180f;
        int prev = p.getInventory().getSelectedSlot();
        float oy = p.getYaw(), op = p.getPitch();
        p.getInventory().setSelectedSlot(slot);
        p.setYaw(away);
        p.setPitch(pitch.f());
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.setYaw(oy);
        p.setPitch(op);
        p.getInventory().setSelectedSlot(prev);
        cd = 100;
    }
}
