package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

/** Size / position / rotation of the item in each hand (first person). See HeldItemRendererMixin. */
public class HandCustomization extends Module {
    public static final HandCustomization INSTANCE = new HandCustomization();

    public final Setting.Num lScale = add(new Setting.Num("Left Size", 0.1, 3.0, 1.0, 0.05));
    public final Setting.Num lX = add(new Setting.Num("Left X", -1.0, 1.0, 0.0, 0.01));
    public final Setting.Num lY = add(new Setting.Num("Left Y", -1.0, 1.0, 0.0, 0.01));
    public final Setting.Num lZ = add(new Setting.Num("Left Z", -1.0, 1.0, 0.0, 0.01));
    public final Setting.Num lRot = add(new Setting.Num("Left Rotate", -180, 180, 0, 5));

    public final Setting.Num rScale = add(new Setting.Num("Right Size", 0.1, 3.0, 1.0, 0.05));
    public final Setting.Num rX = add(new Setting.Num("Right X", -1.0, 1.0, 0.0, 0.01));
    public final Setting.Num rY = add(new Setting.Num("Right Y", -1.0, 1.0, 0.0, 0.01));
    public final Setting.Num rZ = add(new Setting.Num("Right Z", -1.0, 1.0, 0.0, 0.01));
    public final Setting.Num rRot = add(new Setting.Num("Right Rotate", -180, 180, 0, 5));

    private HandCustomization() {
        super("Hand Customization", Category.RENDER);
        showInHud = false;
    }

    public static void apply(MatrixStack m, Hand hand, boolean mainArmIsRight) {
        HandCustomization h = INSTANCE;
        if (!h.enabled) return;
        boolean right = (hand == Hand.MAIN_HAND) == mainArmIsRight;
        float sc = (right ? h.rScale : h.lScale).f();
        float ox = (right ? h.rX : h.lX).f();
        float oy = (right ? h.rY : h.lY).f();
        float oz = (right ? h.rZ : h.lZ).f();
        float rot = (right ? h.rRot : h.lRot).f();

        // approximate pivot of the held item in view space, so scaling happens around the item
        float px = right ? 0.56f : -0.56f, py = -0.52f, pz = -0.72f;
        m.translate(px + ox, py + oy, pz + oz);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rot));
        m.scale(sc, sc, sc);
        m.translate(-px, -py, -pz);
    }
}
