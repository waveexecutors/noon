package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/** Delays only movement packets. Queue is bounded and is always flushed on disable/disconnect. */
public final class FakeLag extends Module {
 public static final FakeLag INSTANCE=new FakeLag();
 public final Setting.Num delay=add(new Setting.Num("Delay (ms)",25,1000,250,25));
 public final Setting.Num jitter=add(new Setting.Num("Jitter (ms)",0,500,0,10));
 private static final ScheduledExecutorService TIMER=Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r,"poco-fakelag-timer");t.setDaemon(true);return t;});
 private static final ConcurrentLinkedQueue<Entry> QUEUE=new ConcurrentLinkedQueue<>();
 private static final AtomicLong COUNT=new AtomicLong();
 private static final int MAX_QUEUE=256;
 private static final ThreadLocal<Boolean> BYPASS=ThreadLocal.withInitial(()->false);
 private FakeLag(){super("FakeLag",Category.COMBAT);}
 public static boolean intercept(ClientConnection connection, Packet<?> packet, PacketCallbacks callbacks){
  if(BYPASS.get()||!INSTANCE.enabled||!(packet instanceof PlayerMoveC2SPacket))return false;
  if(QUEUE.size()>=MAX_QUEUE) flushAll();
  long seq=COUNT.incrementAndGet();
  long extra=INSTANCE.jitter.i()==0?0:ThreadLocalRandom.current().nextLong(INSTANCE.jitter.i()+1L);
  QUEUE.add(new Entry(seq,connection,packet,callbacks));
  TIMER.schedule(()->MinecraftClient.getInstance().execute(()->flush(seq)),Math.max(0,INSTANCE.delay.i()+extra),TimeUnit.MILLISECONDS);
  return true;
 }
 private static void flush(long seq){Entry e;while((e=QUEUE.peek())!=null&&e.sequence<=seq){QUEUE.poll();send(e);}}
 public static void flushAll(){Entry e;while((e=QUEUE.poll())!=null)send(e);}
 private static void send(Entry e){try{BYPASS.set(true);e.connection.send(e.packet,e.callbacks);}catch(Throwable ignored){}finally{BYPASS.set(false);}}
 @Override public void onDisable(){MinecraftClient mc=MinecraftClient.getInstance();if(mc!=null)mc.execute(FakeLag::flushAll);else flushAll();}
 @Override public String suffix(){return delay.i()+"ms";}
 private record Entry(long sequence,ClientConnection connection,Packet<?> packet,PacketCallbacks callbacks){}
}
