package dev.noon.module.movement;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** Jumps for you right at the edge of a block while running, so gaps are cleared with perfect timing. */
public class Parkour extends Module {
    public static final Parkour INSTANCE = new Parkour();

    public final Setting.Num edge = add(new Setting.Num("Edge Distance", 0.1, 0.8, 0.3, 0.05));

    private Parkour() {
        super("Parkour", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null || !p.isOnGround() || p.isSneaking()) return;
        if (!Move.moving(mc) || !p.isSprinting()) return;
        if (Move.edgeAhead(mc, p, edge.get())) p.jump();
    }
}
