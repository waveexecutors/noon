package dev.noon.module.combat;

/** Same logic, but rotations are sent as packets only (your camera never moves) and hotbar switching is invisible. */
public class SilentCrystalAura extends CrystalCore {
    public static final SilentCrystalAura INSTANCE = new SilentCrystalAura();

    private SilentCrystalAura() {
        super("SilentCrystalAura", true);
    }
}
