package dev.noon.module.client;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.util.Anim;

/** All HUD customisation lives here. Toggle this module off to hide the whole Poco HUD. */
public class HudModule extends Module {
    public static final HudModule INSTANCE = new HudModule();

    // colours
    public final Setting.Mode colorMode = add(new Setting.Mode("Color Mode", 0, "Accent", "Rainbow", "White", "Custom"));
    public final Setting.Num cr = add(new Setting.Num("Custom Red", 0, 255, 10, 1));
    public final Setting.Num cg = add(new Setting.Num("Custom Green", 0, 255, 132, 1));
    public final Setting.Num cb = add(new Setting.Num("Custom Blue", 0, 255, 255, 1));
    public final Setting.Num rainbowSpeed = add(new Setting.Num("Rainbow Speed", 0.2, 5, 1, 0.1));

    public final Setting.Bool notifications = add(new Setting.Bool("Module Notifications", true));
    public final Setting.Bool notifySound = add(new Setting.Bool("Notification Sound", true));

    // watermark
    public final Setting.Bool watermark = add(new Setting.Bool("Watermark", true));
    public final Setting.Mode wmText = add(new Setting.Mode("Watermark Text", 0, "Poco", "Poco Client", "Player Name", "Custom (config/noon_hud.txt)"));
    public final Setting.Mode wmStyle = add(new Setting.Mode("Watermark Style", 0, "Flat Box", "No Background", "Underline"));
    public final Setting.Mode wmPos = add(new Setting.Mode("Watermark Position", 0, "Top Left", "Top Right", "Bottom Left", "Bottom Right"));
    public final Setting.Bool wmFps = add(new Setting.Bool("Show FPS", true));
    public final Setting.Bool wmPing = add(new Setting.Bool("Show Ping", false));
    public final Setting.Bool wmTime = add(new Setting.Bool("Show Time", false));
    public final Setting.Num wmX = add(new Setting.Num("Watermark X Offset", 0, 200, 0, 1));
    public final Setting.Num wmY = add(new Setting.Num("Watermark Y Offset", 0, 200, 0, 1));

    // coordinates
    public final Setting.Bool coords = add(new Setting.Bool("Coordinates", true));
    public final Setting.Mode coordPos = add(new Setting.Mode("Coordinates Position", 2, "Top Left", "Top Right", "Bottom Left", "Bottom Right"));

    // module list
    public final Setting.Bool list = add(new Setting.Bool("Module List", true));
    public final Setting.Bool listBg = add(new Setting.Bool("List Background", false));
    public final Setting.Bool listBar = add(new Setting.Bool("List Side Bar", true));
    public final Setting.Bool listShadow = add(new Setting.Bool("List Text Shadow", true));
    public final Setting.Bool listSuffix = add(new Setting.Bool("List Suffix", true));
    public final Setting.Bool listColored = add(new Setting.Bool("List Colored Text", false));
    public final Setting.Mode listSide = add(new Setting.Mode("List Side", 1, "Left", "Right"));
    public final Setting.Mode listVert = add(new Setting.Mode("List Vertical", 0, "Top", "Bottom"));
    public final Setting.Mode listSort = add(new Setting.Mode("List Sort", 0, "Longest First", "Shortest First", "Alphabetical"));
    public final Setting.Num listX = add(new Setting.Num("List X Offset", 0, 200, 0, 1));
    public final Setting.Num listY = add(new Setting.Num("List Y Offset", 0, 200, 0, 1));
    public final Setting.Num listSpacing = add(new Setting.Num("List Spacing", 9, 20, 11, 1));

    public final Anim master = new Anim();

    private HudModule() {
        super("HUD", Category.CLIENT);
        showInHud = false;
        enabled = true;
        toggle.v = 1f;
        master.v = 1f;
    }
}
