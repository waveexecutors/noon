package dev.noon.module.movement;

import dev.noon.module.Category;
import dev.noon.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/** Tells the server you are on the ground while falling so you take no fall damage. */
public class NoFall extends Module {
    public static final NoFall INSTANCE = new NoFall();

    public final dev.noon.module.Setting.Num minFall = add(new dev.noon.module.Setting.Num("Min Fall", 1.5, 10, 2.5, 0.5));

    private NoFall() {
        super("NoFall", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p == null || p.getAbilities().flying || p.isGliding()) return;
        if (!p.isOnGround() && p.fallDistance > minFall.get()) {
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
        }
    }
}
