package dev.noon.module.emotes;
public final class CaramellDansen extends EmoteModule { public static final CaramellDansen INSTANCE=new CaramellDansen(); private CaramellDansen(){super("CaramellDansen","caramell_dansen");} }
