package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Legit mode: opens your inventory, swaps a totem into the offhand, then closes it again,
 * with small randomised delays so it looks like a human did it. Instant mode swaps without a screen.
 */
public class AutoTotem extends Module {
    public static final AutoTotem INSTANCE = new AutoTotem();

    public final Setting.Mode mode = add(new Setting.Mode("Mode", 0, "Legit", "Instant"));
    public final Setting.Num openDelay = add(new Setting.Num("Open Delay", 0, 10, 2, 1));
    public final Setting.Num swapDelay = add(new Setting.Num("Swap Delay", 0, 10, 2, 1));
    public final Setting.Num closeDelay = add(new Setting.Num("Close Delay", 0, 10, 2, 1));

    private int state; // 0 idle, 1 waiting to open, 2 waiting to swap, 3 waiting to close
    private int timer;

    private AutoTotem() {
        super("AutoTotem", Category.COMBAT);
    }

    @Override
    public String suffix() {
        return mode.get();
    }

    @Override
    public void onDisable() {
        state = 0;
    }

    private int jitter(Setting.Num base) {
        return base.i() + ThreadLocalRandom.current().nextInt(0, 2);
    }

    private static boolean offhandHasTotem(ClientPlayerEntity p) {
        return p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
    }

    /** Slot id inside the player screen handler, or -1. */
    private static int findTotemSlot(ClientPlayerEntity p) {
        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                return i < 9 ? 36 + i : i;
            }
        }
        return -1;
    }

    private void swap(MinecraftClient mc, int slot) {
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, mc.player);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) {
            state = 0;
            return;
        }

        if (state == 0) {
            if (mc.currentScreen != null) return;
            if (offhandHasTotem(p) || findTotemSlot(p) < 0) return;
            if (mode.is("Instant")) {
                swap(mc, findTotemSlot(p));
                return;
            }
            state = 1;
            timer = jitter(openDelay);
        } else if (state == 1) {
            if (--timer > 0) return;
            if (mc.currentScreen != null) {
                state = 0;
                return;
            }
            mc.setScreen(new InventoryScreen(p));
            state = 2;
            timer = jitter(swapDelay);
        } else if (state == 2) {
            if (--timer > 0) return;
            if (!(mc.currentScreen instanceof InventoryScreen)) {
                state = 0;
                return;
            }
            int slot = findTotemSlot(p);
            if (slot >= 0 && !offhandHasTotem(p)) swap(mc, slot);
            state = 3;
            timer = jitter(closeDelay);
        } else if (state == 3) {
            if (--timer > 0) return;
            if (mc.currentScreen instanceof InventoryScreen) mc.currentScreen.close();
            state = 0;
        }
    }
}
