package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.render.Esp;
import dev.noon.util.Gfx;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * Christmas in the WORLD: real snow particles around you plus decorations (trees, light strings, gifts, candy canes, floating stars)
 * that are anchored to fixed world positions, projected with true perspective, and hidden when a wall is in the way.
 */
public class Christmas extends Module {
    public static final Christmas INSTANCE = new Christmas();

    public final Setting.Bool snow = add(new Setting.Bool("Snow Particles", true));
    public final Setting.Bool trees = add(new Setting.Bool("Trees", true));
    public final Setting.Bool lights = add(new Setting.Bool("Light Strings", true));
    public final Setting.Bool gifts = add(new Setting.Bool("Gifts", true));
    public final Setting.Bool canes = add(new Setting.Bool("Candy Canes", true));
    public final Setting.Bool stars = add(new Setting.Bool("Golden Stars", true));
    public final Setting.Bool sparkles = add(new Setting.Bool("Sparkles", true));
    public final Setting.Bool needSight = add(new Setting.Bool("Hide Behind Walls", true));
    public final Setting.Num density = add(new Setting.Num("Snow Density", 10, 120, 40, 5));
    public final Setting.Num speed = add(new Setting.Num("Fall Speed", 0.2, 3.0, 1.0, 0.1));
    public final Setting.Num radius = add(new Setting.Num("Decor Radius", 8, 40, 24, 1));
    public final Setting.Num amount = add(new Setting.Num("Decor Amount", 10, 100, 50, 5));
    public final Setting.Num intensity = add(new Setting.Num("Effect Intensity", 10, 100, 85, 5));

    private static final int CELL = 6;
    private static final int[] BULB = {0xFFFF4444, 0xFF44FF44, 0xFF4488FF, 0xFFFFFF44, 0xFFFF88FF};

    private static final class Item {
        int type, color;
        double x, y, z, size;
        boolean visible = true;
        int seed;
    }

    private final Map<Long, List<Item>> cells = new HashMap<>();
    private final Random rng = new Random();
    private long lastSpawn;
    private int frame;

    private Christmas() {
        super("Christmas", Category.RENDER);
        showInHud = false;
    }

    @Override
    public void setEnabled(boolean on) {
        super.setEnabled(on);
        cells.clear();
    }

    public void render(MinecraftClient mc, DrawContext ctx) {
        if (!enabled || mc.options.hudHidden || mc.player == null || mc.world == null) return;
        long now = System.currentTimeMillis();
        if (snow.get() && now - lastSpawn > 50) {
            lastSpawn = now;
            spawnSnow(mc);
        }
        if (!Esp.ready()) return;
        frame++;
        float a = intensity.f() / 100f;
        int r = radius.i();
        int pcx = Math.floorDiv((int) Math.floor(mc.player.getX()), CELL), pcz = Math.floorDiv((int) Math.floor(mc.player.getZ()), CELL);
        int cr = r / CELL + 1;
        Vec3d eye = mc.player.getCameraPosVec(Esp.tickDelta);
        float[] p = new float[2], q = new float[2];
        for (int dx = -cr; dx <= cr; dx++)
            for (int dz = -cr; dz <= cr; dz++) {
                long key = ((long) (pcx + dx) << 32) ^ ((pcz + dz) & 0xFFFFFFFFL);
                List<Item> list = cells.get(key);
                if (list == null) {
                    list = build(mc, pcx + dx, pcz + dz);
                    cells.put(key, list);
                }
                for (Item it : list) {
                    double ddx = it.x - eye.x, ddz = it.z - eye.z;
                    if (ddx * ddx + ddz * ddz > (double) r * r) continue;
                    if (needSight.get() && (frame + it.seed) % 8 == 0) it.visible = sees(mc, eye, it);
                    if (needSight.get() && !it.visible) continue;
                    draw(ctx, it, a, now, p, q);
                }
            }
        if (cells.size() > 900) cells.clear();
        if (sparkles.get()) sparkle(ctx, eye, a, now, p);
    }

    private boolean sees(MinecraftClient mc, Vec3d eye, Item it) {
        Vec3d to = new Vec3d(it.x, it.y + Math.min(1.5, it.size * 0.5), it.z);
        var hit = mc.world.raycast(new RaycastContext(eye, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        return hit.getType() == HitResult.Type.MISS;
    }

    /** Deterministic decorations for one world cell (same cell -> same items every time). */
    private List<Item> build(MinecraftClient mc, int cx, int cz) {
        List<Item> out = new ArrayList<>();
        Random r = new Random(cx * 341873128712L + cz * 132897987541L + 7);
        if (r.nextInt(100) >= amount.i()) return out;
        double x = cx * CELL + 0.5 + r.nextDouble() * (CELL - 1), z = cz * CELL + 0.5 + r.nextDouble() * (CELL - 1);
        double y = ground(mc, x, z);
        if (Double.isNaN(y)) return out;
        List<Integer> types = new ArrayList<>();
        if (trees.get()) types.add(0);
        if (gifts.get()) types.add(1);
        if (canes.get()) types.add(2);
        if (lights.get()) types.add(3);
        if (stars.get()) types.add(4);
        if (types.isEmpty()) return out;
        Item it = new Item();
        it.type = types.get(r.nextInt(types.size()));
        it.x = x;
        it.y = y;
        it.z = z;
        it.seed = r.nextInt(1000);
        it.color = BULB[r.nextInt(BULB.length)];
        it.size = it.type == 0 ? 3.4 + r.nextDouble() * 1.4 : it.type == 1 ? 0.6 + r.nextDouble() * 0.4 : it.type == 2 ? 1.6 : it.type == 3 ? CELL : 0.9;
        if (it.type == 4) it.y = y + 6 + r.nextDouble() * 4;
        out.add(it);
        return out;
    }

    private double ground(MinecraftClient mc, double x, double z) {
        int py = (int) Math.floor(mc.player.getY());
        int bx = (int) Math.floor(x), bz = (int) Math.floor(z);
        for (int y = py + 4; y > py - 10; y--) {
            BlockPos here = new BlockPos(bx, y, bz);
            if (mc.world.getBlockState(here).isAir() && !mc.world.getBlockState(here.down()).isAir()
                    && mc.world.getBlockState(here.down()).getFluidState().isEmpty()) return y;
        }
        return Double.NaN;
    }

    private void draw(DrawContext ctx, Item it, float a, long now, float[] p, float[] q) {
        switch (it.type) {
            case 0 -> tree(ctx, it, a, now, p, q);
            case 1 -> gift(ctx, it, a);
            case 2 -> cane(ctx, it, a, p, q);
            case 3 -> strand(ctx, it, a, now, p);
            default -> star(ctx, it, a, now, p, q);
        }
    }

    /** Pixels per world block at a point (perspective). */
    private float scaleAt(double x, double y, double z, float[] p, float[] q) {
        if (!Esp.project(x, y, z, p) || !Esp.project(x, y + 1, z, q)) return -1f;
        return Math.abs(p[1] - q[1]);
    }

    private void tree(DrawContext ctx, Item it, float a, long now, float[] p, float[] q) {
        float s = scaleAt(it.x, it.y, it.z, p, q);
        if (s <= 0.8f || p[0] < -200 || p[0] > Esp.sw + 200) return;
        int trunk = Gfx.alpha(0xFF6D4C41, a);
        ctx.fill((int) (p[0] - s * 0.12f), (int) (p[1] - s * 0.7f), (int) (p[0] + s * 0.12f), (int) p[1], trunk);
        int tiers = 4;
        for (int k = 0; k < tiers; k++) {
            double y0 = it.y + 0.6 + k * (it.size - 0.9) / tiers;
            double y1 = y0 + (it.size - 0.9) / tiers * 1.7;
            float[] b = new float[2], t = new float[2];
            if (!Esp.project(it.x, y0, it.z, b) || !Esp.project(it.x, y1, it.z, t)) return;
            float halfW = s * (1.2f - k * 0.25f);
            int rows = Math.max(1, (int) (b[1] - t[1]));
            int c = Gfx.alpha(Gfx.lerp(0xFF1B5E20, 0xFF43A047, k / (float) tiers), a);
            for (int y = 0; y < rows; y += 2) {
                float f = y / (float) rows;
                float w = halfW * f;
                ctx.fill((int) (b[0] - w), (int) (t[1] + y), (int) (b[0] + w) + 1, (int) (t[1] + y) + 2, c);
            }
        }
        float[] top = new float[2];
        if (Esp.project(it.x, it.y + it.size, it.z, top)) {
            int sz = Math.max(2, (int) (s * 0.22f));
            float tw = 0.6f + 0.4f * (float) Math.sin(now / 250.0 + it.seed);
            int c = Gfx.alpha(0xFFFFD54F, a * tw);
            ctx.fill((int) top[0] - sz, (int) top[1] - sz / 3, (int) top[0] + sz, (int) top[1] + sz / 3 + 1, c);
            ctx.fill((int) top[0] - sz / 3, (int) top[1] - sz, (int) top[0] + sz / 3 + 1, (int) top[1] + sz, c);
        }
        // ornaments
        for (int i = 0; i < 10; i++) {
            double ang = i * 2.4 + it.seed, hh = 0.9 + i * (it.size - 1.5) / 10.0, rr = (1.0 - (hh - 0.6) / it.size) * 1.0;
            float[] bp = new float[2];
            if (!Esp.project(it.x + Math.cos(ang) * rr, it.y + hh, it.z + Math.sin(ang) * rr, bp)) continue;
            float tw = 0.5f + 0.5f * (float) Math.sin(now / 300.0 + i * 1.7 + it.seed);
            int sz = Math.max(1, (int) (s * 0.07f));
            int c = Gfx.alpha(BULB[(i + it.seed) % BULB.length], a * (0.5f + 0.5f * tw));
            ctx.fill((int) bp[0], (int) bp[1], (int) bp[0] + sz, (int) bp[1] + sz, c);
        }
    }

    private void gift(DrawContext ctx, Item it, float a) {
        double h = it.size / 2;
        Box b = new Box(it.x - h, it.y, it.z - h, it.x + h, it.y + it.size, it.z + h);
        float[] r = new float[4];
        if (!Esp.rect(b, r)) return;
        int c = Gfx.alpha(it.color, a * 0.55f);
        ctx.fill((int) r[0], (int) r[1], (int) r[2], (int) r[3], c);
        Esp.box3d(ctx, b, Gfx.alpha(it.color, a));
        int rib = Gfx.alpha(0xFFFFFFFF, a);
        int mx = (int) ((r[0] + r[2]) / 2), my = (int) ((r[1] + r[3]) / 2);
        ctx.fill(mx, (int) r[1], mx + 2, (int) r[3], rib);
        ctx.fill((int) r[0], my, (int) r[2], my + 2, rib);
    }

    private void cane(DrawContext ctx, Item it, float a, float[] p, float[] q) {
        int seg = 12;
        double h = it.size;
        for (int i = 0; i < seg; i++) {
            double y0 = it.y + h * i / seg, y1 = it.y + h * (i + 1) / seg;
            if (!Esp.project(it.x, y0, it.z, p) || !Esp.project(it.x, y1, it.z, q)) return;
            int c = Gfx.alpha(i % 2 == 0 ? 0xFFE53935 : 0xFFFFFFFF, a);
            Esp.line(ctx, p[0], p[1], q[0], q[1], c);
            Esp.line(ctx, p[0] + 1, p[1], q[0] + 1, q[1], c);
        }
        // hook
        double hx = it.x;
        for (int i = 1; i <= 5; i++) {
            double ang = Math.PI * i / 5.0;
            double x0 = it.x + 0.3 - Math.cos(ang) * 0.3, y0 = it.y + h + Math.sin(ang) * 0.3;
            if (!Esp.project(hx, it.y + h, it.z, p) || !Esp.project(x0, y0, it.z, q)) return;
            Esp.line(ctx, p[0], p[1], q[0], q[1], Gfx.alpha(i % 2 == 0 ? 0xFFE53935 : 0xFFFFFFFF, a));
            hx = x0;
        }
    }

    private void strand(DrawContext ctx, Item it, float a, long now, float[] p) {
        int n = 14;
        double y = it.y + 2.8;
        for (int i = 0; i <= n; i++) {
            double f = i / (double) n;
            double x = it.x + f * CELL, sag = Math.sin(f * Math.PI) * 0.5;
            if (!Esp.project(x, y - sag, it.z, p)) continue;
            float s = scaleAt(x, y - sag, it.z, p, new float[2]);
            int sz = Math.max(1, (int) (s * 0.11f));
            float tw = 0.35f + 0.65f * (0.5f + 0.5f * (float) Math.sin(now / 350.0 + i * 1.3 + it.seed));
            ctx.fill((int) p[0], (int) p[1], (int) p[0] + sz, (int) p[1] + sz, Gfx.alpha(BULB[(i + it.seed) % BULB.length], a * tw));
        }
    }

    private void star(DrawContext ctx, Item it, float a, long now, float[] p, float[] q) {
        float s = scaleAt(it.x, it.y, it.z, p, q);
        if (s <= 0f) return;
        float tw = 0.5f + 0.5f * (0.5f + 0.5f * (float) Math.sin(now / 400.0 + it.seed));
        int sz = Math.max(2, (int) (s * 0.5f));
        int c = Gfx.alpha(0xFFFFD700, a * tw);
        int x = (int) p[0], y = (int) p[1];
        ctx.fill(x - sz, y - 1, x + sz, y + 1, c);
        ctx.fill(x - 1, y - sz, x + 1, y + sz, c);
        ctx.fill(x - sz / 2, y - sz / 2, x + sz / 2, y + sz / 2, Gfx.alpha(0xFFFFF59D, a * tw));
    }

    private void sparkle(DrawContext ctx, Vec3d eye, float a, long now, float[] p) {
        Random r = new Random(now / 400);
        for (int i = 0; i < 24; i++) {
            double x = eye.x + (r.nextDouble() - 0.5) * 22, y = eye.y + (r.nextDouble() - 0.4) * 8, z = eye.z + (r.nextDouble() - 0.5) * 22;
            if (!Esp.project(x, y, z, p)) continue;
            float f = (float) ((now % 400) / 400.0);
            ctx.fill((int) p[0], (int) p[1], (int) p[0] + 2, (int) p[1] + 2, Gfx.alpha(0xFFFFFFFF, a * (1f - f)));
        }
    }

    /** Real 3D snow particles around the player. */
    private void spawnSnow(MinecraftClient mc) {
        int n = Math.max(1, density.i() / 6);
        double px = mc.player.getX(), py = mc.player.getY() + 7.0, pz = mc.player.getZ();
        float sp = (float) speed.get();
        for (int i = 0; i < n; i++) {
            mc.world.addParticleClient(ParticleTypes.SNOWFLAKE,
                    px + (rng.nextDouble() - 0.5) * 26.0, py + rng.nextDouble() * 6.0, pz + (rng.nextDouble() - 0.5) * 26.0,
                    (rng.nextDouble() - 0.5) * 0.06 * sp, -0.06 - rng.nextDouble() * 0.1 * sp, (rng.nextDouble() - 0.5) * 0.06 * sp);
        }
    }
}
