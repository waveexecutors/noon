package dev.noon.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/**
 * Uses the vanilla Minecraft font for everything.
 */
public final class Fonts {
    private Fonts() {}

    public static Text text(String s, String font) {
        return Text.literal(s);
    }

    public static int width(String s, String font) {
        return MinecraftClient.getInstance().textRenderer.getWidth(s);
    }

    public static void draw(DrawContext c, String font, String s, int x, int y, int color) {
        if ((color >>> 24) < 5 || s.isEmpty()) return;
        c.drawText(MinecraftClient.getInstance().textRenderer, s, x, y, color, false);
    }
}
