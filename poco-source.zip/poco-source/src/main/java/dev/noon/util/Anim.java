package dev.noon.util;

/** Frame-rate independent smoothing (to) and spring physics with overshoot (spring). Use ONE of them per instance. */
public final class Anim {
    public float v;
    public float vel;
    private long last = System.nanoTime();

    private float dt() {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1_000_000_000f);
        last = now;
        return dt;
    }

    public float to(float target, float speed) {
        float dt = dt();
        v += (target - v) * (1f - (float) Math.exp(-speed * dt));
        if (Math.abs(target - v) < 0.002f) v = target;
        return v;
    }

    /** iOS-like spring. stiffness ~ 120-260, damping ~ 12-24 (lower damping = more bounce). */
    public float spring(float target, float stiffness, float damping) {
        float dt = dt();
        int steps = Math.max(1, (int) Math.ceil(dt / 0.005f));
        float h = dt / steps;
        for (int i = 0; i < steps; i++) {
            float a = (target - v) * stiffness - vel * damping;
            vel += a * h;
            v += vel * h;
        }
        if (Math.abs(target - v) < 0.0015f && Math.abs(vel) < 0.02f) {
            v = target;
            vel = 0f;
        }
        return v;
    }

    public void set(float x) {
        v = x;
        vel = 0f;
    }

    public static float clamp01(float t) {
        return t < 0f ? 0f : (t > 1f ? 1f : t);
    }

    public static float easeOutCubic(float t) {
        t = clamp01(t);
        float u = 1f - t;
        return 1f - u * u * u;
    }
}
