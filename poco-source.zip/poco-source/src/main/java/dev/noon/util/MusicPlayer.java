package dev.noon.util;

import java.awt.Desktop;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.client.MinecraftClient;

/**
 * Local music player for ClickGUI Music tab.
 * Creates a folder inside the Minecraft game directory (runDirectory/poco-music)
 * and lists .mp3 / .ogg / .wav files. Play opens the file with the system default
 * player. Reload rescans the folder.
 */
public final class MusicPlayer {
    private MusicPlayer() {}

    public static final class Station {
        public final String name;
        public final String url;   // for local: absolute path
        public final String tags;
        public final File file;

        public Station(String name, String url, String tags) {
            this(name, url, tags, null);
        }

        public Station(String name, String url, String tags, File file) {
            this.name = name;
            this.url = url;
            this.tags = tags == null ? "" : tags;
            this.file = file;
        }
    }

    private static volatile List<Station> stations = new ArrayList<>();
    private static volatile Station current;
    private static final AtomicBoolean loading = new AtomicBoolean(false);
    private static volatile String status = "Drop MP3s into poco-music folder";
    private static volatile Path musicDir;
    private static volatile String filter = "";

    public static List<Station> getStations() {
        if (stations.isEmpty() && !loading.get()) reload();
        if (filter == null || filter.isBlank()) return stations;
        String f = filter.toLowerCase(Locale.ROOT);
        List<Station> out = new ArrayList<>();
        for (Station s : stations) {
            if (s.name.toLowerCase(Locale.ROOT).contains(f)) out.add(s);
        }
        return out;
    }

    public static Station current() { return current; }
    public static String status() { return status; }
    public static boolean isLoading() { return loading.get(); }
    public static String lastQuery() { return filter; }
    public static Path musicFolder() { ensureDir(); return musicDir; }

    public static void setFilter(String q) {
        filter = q == null ? "" : q.trim();
    }

    /** Create poco-music next to the game run directory (or inside versions if possible). */
    private static void ensureDir() {
        if (musicDir != null) return;
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            Path base = mc != null && mc.runDirectory != null
                    ? mc.runDirectory.toPath()
                    : Path.of(".").toAbsolutePath();
            String ver = mc != null ? mc.getGameVersion() : null;
            Path versions = base.resolve("versions");
            if (ver != null && Files.isDirectory(versions.resolve(ver))) {
                musicDir = versions.resolve(ver).resolve("poco-music");
            }
            if (musicDir == null) {
                musicDir = base.resolve("poco-music");
            }
            Files.createDirectories(musicDir);
            status = "Folder: " + musicDir.getFileName();
        } catch (Exception e) {
            musicDir = Path.of("poco-music").toAbsolutePath();
            try { Files.createDirectories(musicDir); } catch (Exception ignored) {}
            status = "Folder: poco-music";
        }
    }

    public static void reload() {
        if (!loading.compareAndSet(false, true)) return;
        status = "Scanning…";
        try {
            ensureDir();
            List<Station> list = new ArrayList<>();
            File dir = musicDir.toFile();
            File[] files = dir.listFiles((d, name) -> {
                String lower = name.toLowerCase(Locale.ROOT);
                return lower.endsWith(".mp3") || lower.endsWith(".ogg") || lower.endsWith(".wav") || lower.endsWith(".flac");
            });
            if (files != null) {
                for (File f : files) {
                    if (!f.isFile()) continue;
                    String name = f.getName();
                    int dot = name.lastIndexOf('.');
                    String title = dot > 0 ? name.substring(0, dot) : name;
                    list.add(new Station(title, f.getAbsolutePath(), "local", f));
                }
            }
            list.sort(Comparator.comparing(s -> s.name.toLowerCase(Locale.ROOT)));
            stations = list;
            if (list.isEmpty()) {
                status = "No MP3s – put files in " + musicDir.getFileName();
            } else {
                status = list.size() + " track" + (list.size() == 1 ? "" : "s");
            }
        } catch (Exception e) {
            stations = new ArrayList<>();
            status = "Reload failed";
        } finally {
            loading.set(false);
        }
    }

    public static void search(String query) {
        setFilter(query);
        if (stations.isEmpty()) reload();
    }

    public static void refresh() {
        reload();
    }

    public static void cycleDefaultQuery() {
        setFilter("");
        reload();
    }

    private static volatile javazoom.jl.player.advanced.AdvancedPlayer player;
    private static volatile javax.sound.sampled.Clip clip;
    private static volatile int playToken;

    private static void halt() {
        playToken++;
        try { if (player != null) player.close(); } catch (Throwable ignored) {}
        try { if (clip != null) { clip.stop(); clip.close(); } } catch (Throwable ignored) {}
        player = null;
        clip = null;
    }

    /** Plays inside the game (mp3 via JLayer, wav via javax.sound); other formats open in the system player. */
    public static boolean play(Station s) {
        if (s == null) return false;
        File f = s.file != null ? s.file : (s.url != null ? new File(s.url) : null);
        if (f == null || !f.isFile()) { status = "File missing - press Reload"; return false; }
        halt();
        final int token = playToken;
        current = s;
        String lower = f.getName().toLowerCase(Locale.ROOT);
        status = "Playing: " + truncate(s.name, 32);
        if (lower.endsWith(".mp3")) {
            Thread t = new Thread(() -> {
                try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(f))) {
                    javazoom.jl.player.advanced.AdvancedPlayer p = new javazoom.jl.player.advanced.AdvancedPlayer(in);
                    player = p;
                    p.play();
                    if (token == playToken) { next(); }
                } catch (Throwable e) {
                    if (token == playToken) status = "Could not play (bad mp3?)";
                }
            }, "poco-music");
            t.setDaemon(true);
            t.start();
            return true;
        }
        if (lower.endsWith(".wav")) {
            try {
                javax.sound.sampled.Clip c = javax.sound.sampled.AudioSystem.getClip();
                c.open(javax.sound.sampled.AudioSystem.getAudioInputStream(f));
                clip = c;
                c.start();
                return true;
            } catch (Throwable e) {
                status = "Could not play wav";
                return false;
            }
        }
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                Desktop.getDesktop().open(f);
                status = "Opened in system player: " + truncate(s.name, 24);
                return true;
            }
        } catch (Throwable ignored) {}
        status = "Unsupported format (use mp3/wav)";
        return false;
    }

    /** Auto-advance to the next track in the (filtered) list. */
    public static void next() {
        List<Station> l = getStations();
        if (l.isEmpty()) return;
        int i = current == null ? -1 : l.indexOf(current);
        play(l.get((i + 1) % l.size()));
    }

    public static void stop() {
        halt();
        current = null;
        status = "Stopped";
        Sounds.click();
    }

    private static String truncate(String s, int n) {
        if (s == null) return "";
        return s.length() <= n ? s : s.substring(0, n - 1) + "…";
    }
}
