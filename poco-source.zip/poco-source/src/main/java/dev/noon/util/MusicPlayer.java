package dev.noon.util;

import java.awt.Desktop;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.client.MinecraftClient;

/**
 * Local music player for ClickGUI Music tab.
 * Creates a folder inside the Minecraft game directory (runDirectory/poco-music)
 * and lists .mp3 / .ogg / .wav files. Play opens the file with the system default
 * player. Reload rescans the folder.
 */
public final class MusicPlayer {
    private MusicPlayer() {}

    public static final class Station {
        public final String name;
        public final String url;   // for local: absolute path
        public final String tags;
        public final File file;

        public Station(String name, String url, String tags) {
            this(name, url, tags, null);
        }

        public Station(String name, String url, String tags, File file) {
            this.name = name;
            this.url = url;
            this.tags = tags == null ? "" : tags;
            this.file = file;
        }
    }

    private static volatile List<Station> stations = new ArrayList<>();
    private static volatile Station current;
    private static final AtomicBoolean loading = new AtomicBoolean(false);
    private static volatile String status = "Drop MP3s into poco-music folder";
    private static volatile Path musicDir;
    private static volatile String filter = "";

    public static List<Station> getStations() {
        if (stations.isEmpty() && !loading.get()) reload();
        if (filter == null || filter.isBlank()) return stations;
        String f = filter.toLowerCase(Locale.ROOT);
        List<Station> out = new ArrayList<>();
        for (Station s : stations) {
            if (s.name.toLowerCase(Locale.ROOT).contains(f)) out.add(s);
        }
        return out;
    }

    public static Station current() { return current; }
    public static String status() { return status; }
    public static boolean isLoading() { return loading.get(); }
    public static String lastQuery() { return filter; }
    public static Path musicFolder() { ensureDir(); return musicDir; }

    public static void setFilter(String q) {
        filter = q == null ? "" : q.trim();
    }

    /** Create poco-music next to the game run directory (or inside versions if possible). */
    private static void ensureDir() {
        if (musicDir != null) return;
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            Path base = mc != null && mc.runDirectory != null
                    ? mc.runDirectory.toPath()
                    : Path.of(".").toAbsolutePath();
            // Prefer a folder inside the current version folder when it exists
            Path versions = base.resolve("versions");
            if (Files.isDirectory(versions)) {
                // pick newest version dir that looks like a MC version
                try (var stream = Files.list(versions)) {
                    Path best = stream
                            .filter(Files::isDirectory)
                            .filter(p -> {
                                String n = p.getFileName().toString();
                                return n.contains(".") && !n.startsWith(".");
                            })
                            .max(Comparator.comparingLong(p -> {
                                try { return Files.getLastModifiedTime(p).toMillis(); }
                                catch (Exception e) { return 0L; }
                            }))
                            .orElse(null);
                    if (best != null) {
                        musicDir = best.resolve("poco-music");
                    }
                }
            }
            if (musicDir == null) {
                musicDir = base.resolve("poco-music");
            }
            Files.createDirectories(musicDir);
            status = "Folder: " + musicDir.getFileName();
        } catch (Exception e) {
            musicDir = Path.of("poco-music").toAbsolutePath();
            try { Files.createDirectories(musicDir); } catch (Exception ignored) {}
            status = "Folder: poco-music";
        }
    }

    public static void reload() {
        if (!loading.compareAndSet(false, true)) return;
        status = "Scanning…";
        try {
            ensureDir();
            List<Station> list = new ArrayList<>();
            File dir = musicDir.toFile();
            File[] files = dir.listFiles((d, name) -> {
                String lower = name.toLowerCase(Locale.ROOT);
                return lower.endsWith(".mp3") || lower.endsWith(".ogg") || lower.endsWith(".wav") || lower.endsWith(".flac");
            });
            if (files != null) {
                for (File f : files) {
                    if (!f.isFile()) continue;
                    String name = f.getName();
                    int dot = name.lastIndexOf('.');
                    String title = dot > 0 ? name.substring(0, dot) : name;
                    list.add(new Station(title, f.getAbsolutePath(), "local", f));
                }
            }
            list.sort(Comparator.comparing(s -> s.name.toLowerCase(Locale.ROOT)));
            stations = list;
            if (list.isEmpty()) {
                status = "No MP3s – put files in " + musicDir.getFileName();
            } else {
                status = list.size() + " track" + (list.size() == 1 ? "" : "s");
            }
        } catch (Exception e) {
            stations = new ArrayList<>();
            status = "Reload failed";
        } finally {
            loading.set(false);
        }
    }

    public static void search(String query) {
        setFilter(query);
        if (stations.isEmpty()) reload();
    }

    public static void refresh() {
        reload();
    }

    public static void cycleDefaultQuery() {
        setFilter("");
        reload();
    }

    public static boolean play(Station s) {
        if (s == null) return false;
        try {
            File f = s.file != null ? s.file : (s.url != null ? new File(s.url) : null);
            if (f != null && f.isFile()) {
                if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                    Desktop.getDesktop().open(f);
                    current = s;
                    status = "Playing: " + truncate(s.name, 32);
                    Sounds.click();
                    return true;
                }
            }
            // fallback: try browse if it was a URL
            if (s.url != null && (s.url.startsWith("http://") || s.url.startsWith("https://"))) {
                if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                    Desktop.getDesktop().browse(java.net.URI.create(s.url));
                    current = s;
                    status = "Opened: " + truncate(s.name, 28);
                    Sounds.click();
                    return true;
                }
            }
            status = "Could not open track";
        } catch (Exception e) {
            status = "Play failed";
        }
        return false;
    }

    public static void stop() {
        current = null;
        status = "Stopped";
        Sounds.click();
    }

    private static String truncate(String s, int n) {
        if (s == null) return "";
        return s.length() <= n ? s : s.substring(0, n - 1) + "…";
    }
}
