package dev.noon.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Pure math (no Minecraft classes) used by Hand Glow: rebuilds the vanilla first-person hand / item transform, projects the
 * real arm (or item) box to the screen and gives row spans of the silhouette dilated by a radius, so a uniform-width outline
 * can be filled row by row. Matrices are row-major double[16].
 */
public final class HandMath {
    private HandMath() {}

    // ---- tiny 4x4 matrix helpers (row-major) --------------------------------------------------

    /** JOML / OpenGL float[16] (column-major) -> row-major double[16]. */
    public static double[] fromColumnMajor(float[] a) {
        double[] m = new double[16];
        for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) m[r * 4 + c] = a[c * 4 + r];
        return m;
    }

    public static double[] mul(double[] a, double[] b) {
        double[] o = new double[16];
        for (int r = 0; r < 4; r++)
            for (int c = 0; c < 4; c++) {
                double s = 0;
                for (int k = 0; k < 4; k++) s += a[r * 4 + k] * b[k * 4 + c];
                o[r * 4 + c] = s;
            }
        return o;
    }

    public static double[] id() {
        return new double[]{1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
    }

    public static double[] translate(double[] m, double x, double y, double z) {
        double[] t = id();
        t[3] = x;
        t[7] = y;
        t[11] = z;
        return mul(m, t);
    }

    public static double[] scale(double[] m, double x, double y, double z) {
        double[] t = id();
        t[0] = x;
        t[5] = y;
        t[10] = z;
        return mul(m, t);
    }

    public static double[] rotX(double[] m, double deg) {
        double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
        double[] t = id();
        t[5] = c;
        t[6] = -s;
        t[9] = s;
        t[10] = c;
        return mul(m, t);
    }

    public static double[] rotY(double[] m, double deg) {
        double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
        double[] t = id();
        t[0] = c;
        t[2] = s;
        t[8] = -s;
        t[10] = c;
        return mul(m, t);
    }

    public static double[] rotZ(double[] m, double deg) {
        double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
        double[] t = id();
        t[0] = c;
        t[1] = -s;
        t[4] = s;
        t[5] = c;
        return mul(m, t);
    }

    private static double[] apply(double[] m, double x, double y, double z) {
        return new double[]{
                m[0] * x + m[1] * y + m[2] * z + m[3],
                m[4] * x + m[5] * y + m[6] * z + m[7],
                m[8] * x + m[9] * y + m[10] * z + m[11]};
    }

    /** The 8 corners of an axis aligned box, transformed by m. */
    private static double[][] box(double[] m, double x0, double y0, double z0, double x1, double y1, double z1) {
        double[][] o = new double[8][];
        int i = 0;
        for (int a = 0; a < 2; a++)
            for (int b = 0; b < 2; b++)
                for (int c = 0; c < 2; c++) o[i++] = apply(m, a == 0 ? x0 : x1, b == 0 ? y0 : y1, c == 0 ? z0 : z1);
        return o;
    }

    // ---- vanilla first-person transforms ------------------------------------------------------

    /**
     * Corners (view space) of the bare arm vanilla draws for an EMPTY main hand (HeldItemRenderer.renderArmHoldingItem
     * + the arm model cuboid incl. the sleeve layer).
     */
    public static double[][] arm(double[] base, boolean right, boolean slim, float swing, float equip) {
        double o = right ? 1 : -1;
        double g = Math.sqrt(swing);
        double h = -0.3 * Math.sin(g * Math.PI);
        double i = 0.4 * Math.sin(g * Math.PI * 2);
        double j = -0.4 * Math.sin(swing * Math.PI);
        double[] m = translate(base, o * (h + 0.64000005), i - 0.6 + equip * -0.6, j - 0.71999997);
        m = rotY(m, o * 45);
        double k = Math.sin(swing * swing * Math.PI);
        double l = Math.sin(g * Math.PI);
        m = rotY(m, o * l * 70);
        m = rotZ(m, o * k * -20);
        m = translate(m, o * -1.0, 3.6, 3.5);
        m = rotZ(m, o * 120);
        m = rotX(m, 200);
        m = rotY(m, o * -135);
        m = translate(m, o * 5.6, 0, 0);

        // arm model part: pivot, idle roll, cuboid (pixels / 16); +0.25 = sleeve layer
        double px = right ? -5 : 5, py = slim ? 2.5 : 2.0;
        m = translate(m, px / 16.0, py / 16.0, 0);
        m = rotZ(m, right ? 5.73 : -5.73);
        double w = slim ? 3 : 4;
        double x0 = right ? (slim ? -2 : -3) : -1;
        double e = 0.25;
        return box(m, (x0 - e) / 16.0, (-2 - e) / 16.0, (-2 - e) / 16.0, (x0 + w + e) / 16.0, (10 + e) / 16.0, (2 + e) / 16.0);
    }

    /** View-space sample points of a held item. Blocks use a cube; sprites use a dense grid on the item plane so the hull follows the item silhouette instead of a single flat box. */
    public static double[][] item(double[] base, boolean right, boolean block, float swing, float equip, double fit) {
        double o = right ? 1 : -1;
        double n = -0.4 * Math.sin(Math.sqrt(swing) * Math.PI);
        double mm = 0.2 * Math.sin(Math.sqrt(swing) * Math.PI * 2);
        double f = -0.2 * Math.sin(swing * Math.PI);
        double[] m = translate(base, o * n, mm, f);
        m = translate(m, o * 0.56, -0.52 + equip * -0.6, -0.72);
        double s2 = Math.sin(swing * swing * Math.PI);
        m = rotY(m, o * (45 + s2 * -20));
        double gg = Math.sin(Math.sqrt(swing) * Math.PI);
        m = rotZ(m, o * gg * -20);
        m = rotX(m, gg * -80);
        m = rotY(m, o * -45);
        if (block) {
            m = rotY(m, o * 45);
            m = scale(m, 0.4, 0.4, 0.4);
            m = translate(m, -0.5, -0.5, -0.5);
            double lo = (1 - fit) / 2, hi = 1 - lo;
            // denser samples on cube faces for cleaner hull
            return sampleBox(m, lo, lo, lo, hi, hi, hi, 3);
        }
        m = translate(m, o * 1.13 / 16.0, 3.2 / 16.0, 1.13 / 16.0);
        m = rotY(m, o * -90);
        m = rotZ(m, o * 25);
        m = scale(m, 0.68, 0.68, 0.68);
        m = translate(m, -0.5, -0.5, -0.5);
        // denser grid on the sprite plane so the hull hugs item silhouette more tightly
        double lo = (1 - fit) / 2, hi = 1 - lo;
        double z0 = 7.25 / 16.0, z1 = 8.75 / 16.0;
        return sampleSprite(m, lo, hi, z0, z1, 10);
    }

    /** Grid samples on a thin sprite plane (front + back). */
    private static double[][] sampleSprite(double[] m, double lo, double hi, double z0, double z1, int n) {
        java.util.ArrayList<double[]> pts = new java.util.ArrayList<>();
        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <= n; j++) {
                double u = lo + (hi - lo) * i / (double) n;
                double v = lo + (hi - lo) * j / (double) n;
                // bias toward edges so hull hugs the outline
                boolean edge = i == 0 || i == n || j == 0 || j == n;
                if (!edge && (i + j) % 2 == 0) continue;
                pts.add(apply(m, u, v, z0));
                pts.add(apply(m, u, v, z1));
            }
        }
        // also add mid-edge midpoints for sharper silhouette
        double mid = (lo + hi) / 2;
        pts.add(apply(m, mid, lo, z0));
        pts.add(apply(m, mid, hi, z0));
        pts.add(apply(m, lo, mid, z0));
        pts.add(apply(m, hi, mid, z0));
        return pts.toArray(new double[0][]);
    }

    /** Grid samples throughout a box volume. */
    private static double[][] sampleBox(double[] m, double x0, double y0, double z0, double x1, double y1, double z1, int n) {
        java.util.ArrayList<double[]> pts = new java.util.ArrayList<>();
        for (int i = 0; i <= n; i++)
            for (int j = 0; j <= n; j++)
                for (int k = 0; k <= n; k++) {
                    if (i != 0 && i != n && j != 0 && j != n && k != 0 && k != n) continue; // surface only
                    double x = x0 + (x1 - x0) * i / (double) n;
                    double y = y0 + (y1 - y0) * j / (double) n;
                    double z = z0 + (z1 - z0) * k / (double) n;
                    pts.add(apply(m, x, y, z));
                }
        return pts.toArray(new double[0][]);
    }

    // ---- projection ---------------------------------------------------------------------------

    /**
     * Projects box corners (view space, camera looks down -Z) to GUI coordinates. The 12 box edges are clipped against the near
     * plane first so parts of the arm that are right next to the camera do not blow up.
     */
    public static List<double[]> project(double[][] c, double tanHalf, double aspect, double sw, double sh) {
        final double near = 0.05;
        List<double[]> view = new ArrayList<>();
        for (double[] p : c) if (-p[2] >= near) view.add(p);
        // only clip classic 8-corner box edges; denser item samples are projected as-is
        if (c.length == 8) {
            int[][] edges = {{0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
            for (int[] e : edges) {
                double[] a = c[e[0]], b = c[e[1]];
                boolean ia = -a[2] >= near, ib = -b[2] >= near;
                if (ia != ib) {
                    double t = (-near - a[2]) / (b[2] - a[2]);
                    view.add(new double[]{a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, -near});
                }
            }
        }
        List<double[]> out = new ArrayList<>();
        for (double[] p : view) {
            double d = -p[2];
            out.add(new double[]{
                    sw / 2.0 + (p[0] / d) / (tanHalf * aspect) * (sw / 2.0),
                    sh / 2.0 - (p[1] / d) / tanHalf * (sh / 2.0)});
        }
        return out;
    }

    /** Convex hull (Andrew's monotone chain). Returns the polygon in math-CCW order. */
    public static double[][] hull(List<double[]> pts) {
        double[][] p = pts.toArray(new double[0][]);
        if (p.length < 3) return new double[0][];
        Arrays.sort(p, (a, b) -> a[0] != b[0] ? Double.compare(a[0], b[0]) : Double.compare(a[1], b[1]));
        double[][] h = new double[p.length * 2][];
        int k = 0;
        for (int i = 0; i < p.length; i++) {
            while (k >= 2 && cross(h[k - 2], h[k - 1], p[i]) <= 0) k--;
            h[k++] = p[i];
        }
        for (int i = p.length - 2, t = k + 1; i >= 0; i--) {
            while (k >= t && cross(h[k - 2], h[k - 1], p[i]) <= 0) k--;
            h[k++] = p[i];
        }
        return Arrays.copyOf(h, Math.max(0, k - 1));
    }

    private static double cross(double[] o, double[] a, double[] b) {
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
    }

    /**
     * Horizontal extent of (convex polygon dilated by r) on the row centred at yc. Writes {left, right} to out and returns false
     * when the row does not touch it. The polygon must be in the order returned by {@link #hull}.
     */
    public static boolean span(double[][] poly, double r, double yc, double[] out) {
        double lo = Double.POSITIVE_INFINITY, hi = Double.NEGATIVE_INFINITY;
        int n = poly.length;
        for (int i = 0; i < n; i++) {
            double[] a = poly[i], b = poly[(i + 1) % n];
            if (r > 0) {
                double dy = yc - a[1];
                if (Math.abs(dy) <= r) {
                    double w = Math.sqrt(r * r - dy * dy);
                    lo = Math.min(lo, a[0] - w);
                    hi = Math.max(hi, a[0] + w);
                }
            }
            double ex = b[0] - a[0], ey = b[1] - a[1], len = Math.hypot(ex, ey);
            if (len < 1e-9) continue;
            // outward normal of a CCW polygon edge
            double nx = ey / len * r, ny = -ex / len * r;
            double ay = a[1] + ny, by = b[1] + ny;
            if (Math.abs(by - ay) < 1e-9) {
                if (Math.abs(yc - ay) < 0.5) {
                    lo = Math.min(lo, Math.min(a[0], b[0]) + nx);
                    hi = Math.max(hi, Math.max(a[0], b[0]) + nx);
                }
                continue;
            }
            double t = (yc - ay) / (by - ay);
            if (t >= 0 && t <= 1) {
                double x = a[0] + nx + ex * t;
                lo = Math.min(lo, x);
                hi = Math.max(hi, x);
            }
        }
        if (lo > hi) return false;
        out[0] = lo;
        out[1] = hi;
        return true;
    }
}
