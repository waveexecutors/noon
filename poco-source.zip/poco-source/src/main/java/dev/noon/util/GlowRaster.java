package dev.noon.util;

import java.util.Arrays;

/** Tiny CPU rasteriser for Hand Glow: fills convex polygons into a coverage grid and builds a distance field around it. */
public final class GlowRaster {
    private GlowRaster() {}

    /** Fill a convex polygon (grid coordinates) into cov (W*H). Pixels touched by the polygon are included. */
    public static void fillConvex(boolean[] cov, int W, int H, double[][] poly) {
        double minY = Double.POSITIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY;
        for (double[] p : poly) {
            minY = Math.min(minY, p[1]);
            maxY = Math.max(maxY, p[1]);
        }
        int y0 = Math.max(0, (int) Math.floor(minY)), y1 = Math.min(H - 1, (int) Math.floor(maxY));
        int n = poly.length;
        for (int y = y0; y <= y1; y++) {
            double yc = y + 0.5;
            double lo = Double.POSITIVE_INFINITY, hi = Double.NEGATIVE_INFINITY;
            for (int i = 0; i < n; i++) {
                double[] a = poly[i], b = poly[(i + 1) % n];
                double ay = a[1], by = b[1];
                if ((ay <= yc && by > yc) || (by <= yc && ay > yc)) {
                    double x = a[0] + (b[0] - a[0]) * (yc - ay) / (by - ay);
                    lo = Math.min(lo, x);
                    hi = Math.max(hi, x);
                }
            }
            if (lo > hi) {
                // thin sliver: fall back to vertex extent near this row
                for (double[] p : poly) if (Math.abs(p[1] - yc) < 0.75) {
                    lo = Math.min(lo, p[0]);
                    hi = Math.max(hi, p[0]);
                }
                if (lo > hi) continue;
            }
            int xa = Math.max(0, (int) Math.floor(lo)), xb = Math.min(W - 1, (int) Math.floor(hi));
            for (int x = xa; x <= xb; x++) cov[y * W + x] = true;
        }
    }

    /** Distance (in grid pixels) to the nearest covered pixel; 0 inside. Two-pass chamfer, accurate to a few percent. */
    public static float[] distance(boolean[] cov, int W, int H) {
        float inf = 1e9f, d1 = 1f, d2 = 1.4142f;
        float[] d = new float[W * H];
        Arrays.fill(d, inf);
        for (int i = 0; i < d.length; i++) if (cov[i]) d[i] = 0f;
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                int i = y * W + x;
                float v = d[i];
                if (x > 0) v = Math.min(v, d[i - 1] + d1);
                if (y > 0) {
                    v = Math.min(v, d[i - W] + d1);
                    if (x > 0) v = Math.min(v, d[i - W - 1] + d2);
                    if (x < W - 1) v = Math.min(v, d[i - W + 1] + d2);
                }
                d[i] = v;
            }
        for (int y = H - 1; y >= 0; y--)
            for (int x = W - 1; x >= 0; x--) {
                int i = y * W + x;
                float v = d[i];
                if (x < W - 1) v = Math.min(v, d[i + 1] + d1);
                if (y < H - 1) {
                    v = Math.min(v, d[i + W] + d1);
                    if (x < W - 1) v = Math.min(v, d[i + W + 1] + d2);
                    if (x > 0) v = Math.min(v, d[i + W - 1] + d2);
                }
                d[i] = v;
            }
        return d;
    }
}
