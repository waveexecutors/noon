package dev.noon.render;

import dev.noon.util.Gfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * World -> screen projection + 2D drawing primitives for all ESP modules.
 * Everything is drawn on the HUD layer (no world-render API needed), so it is cheap and version-tolerant.
 */
public final class Esp {
    private Esp() {}

    public static int sw, sh;
    private static double cx, cy, cz, fx, fy, fz, rx, rz, ux, uy, uz;
    private static double tanHalf;
    private static boolean ready;
    public static float tickDelta;

    public static void begin(MinecraftClient mc, DrawContext ctx, float td) {
        ClientPlayerEntity p = mc.player;
        ready = false;
        if (p == null) return;
        tickDelta = td;
        sw = ctx.getScaledWindowWidth();
        sh = ctx.getScaledWindowHeight();
        Vec3d cam = p.getCameraPosVec(td);
        cx = cam.x;
        cy = cam.y;
        cz = cam.z;
        double yaw = Math.toRadians(p.getYaw(td)), pitch = Math.toRadians(p.getPitch(td));
        double cp = Math.cos(pitch);
        fx = -Math.sin(yaw) * cp;
        fy = -Math.sin(pitch);
        fz = Math.cos(yaw) * cp;
        rx = -Math.cos(yaw);
        rz = -Math.sin(yaw);
        // up = right x forward
        ux = -rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy;
        tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        ready = true;
    }

    public static boolean ready() {
        return ready;
    }

    /** Projects into out[0..1]; returns false when the point is behind the camera (out is then still a flipped guess). */
    public static boolean project(double x, double y, double z, float[] out) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        double zc = dx * fx + dy * fy + dz * fz;
        double xc = dx * rx + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        boolean front = zc > 0.05;
        if (!front) {
            xc = -xc;
            yc = -yc;
            zc = Math.max(0.05, -zc);
        }
        double aspect = (double) sw / sh;
        out[0] = (float) (sw / 2.0 + (xc / zc) / (tanHalf * aspect) * (sw / 2.0));
        out[1] = (float) (sh / 2.0 - (yc / zc) / tanHalf * (sh / 2.0));
        return front;
    }

    public static Box lerped(Entity e) {
        double dx = MathHelper.lerp(tickDelta, e.lastRenderX, e.getX()) - e.getX();
        double dy = MathHelper.lerp(tickDelta, e.lastRenderY, e.getY()) - e.getY();
        double dz = MathHelper.lerp(tickDelta, e.lastRenderZ, e.getZ()) - e.getZ();
        return e.getBoundingBox().offset(dx, dy, dz);
    }

    /** Screen rectangle of a box in r = {minX, minY, maxX, maxY}; false if any corner is behind the camera. */
    public static boolean rect(Box b, float[] r) {
        float[] o = new float[2];
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? b.minX : b.maxX;
            double y = (i & 2) == 0 ? b.minY : b.maxY;
            double z = (i & 4) == 0 ? b.minZ : b.maxZ;
            if (!project(x, y, z, o)) return false;
            minX = Math.min(minX, o[0]);
            maxX = Math.max(maxX, o[0]);
            minY = Math.min(minY, o[1]);
            maxY = Math.max(maxY, o[1]);
        }
        r[0] = minX;
        r[1] = minY;
        r[2] = maxX;
        r[3] = maxY;
        return maxX > 0 && maxY > 0 && minX < sw && minY < sh && (maxX - minX) < sw * 4;
    }

    // ---- primitives -----------------------------------------------------------------------------

    /** 1px line, clipped to the screen and drawn as merged runs (cheap even for long lines). */
    public static void line(DrawContext c, float x0, float y0, float x1, float y1, int color) {
        // Liang-Barsky clip
        float t0 = 0f, t1 = 1f, dx = x1 - x0, dy = y1 - y0;
        float[] p = {-dx, dx, -dy, dy};
        float[] q = {x0, sw - x0, y0, sh - y0};
        for (int i = 0; i < 4; i++) {
            if (p[i] == 0) {
                if (q[i] < 0) return;
            } else {
                float t = q[i] / p[i];
                if (p[i] < 0) {
                    if (t > t1) return;
                    if (t > t0) t0 = t;
                } else {
                    if (t < t0) return;
                    if (t < t1) t1 = t;
                }
            }
        }
        float ax = x0 + dx * t0, ay = y0 + dy * t0, bx = x0 + dx * t1, by = y0 + dy * t1;
        int ix0 = Math.round(ax), iy0 = Math.round(ay), ix1 = Math.round(bx), iy1 = Math.round(by);
        int adx = Math.abs(ix1 - ix0), ady = Math.abs(iy1 - iy0);
        if (adx == 0 && ady == 0) {
            c.fill(ix0, iy0, ix0 + 1, iy0 + 1, color);
            return;
        }
        if (adx >= ady) {
            int n = ady + 1;
            for (int k = 0; k < n; k++) {
                float ta = ady == 0 ? 0f : (k - 0.5f) / ady, tb = ady == 0 ? 1f : (k + 0.5f) / ady;
                ta = Math.max(0f, ta);
                tb = Math.min(1f, tb);
                int xa = Math.round(ax + (bx - ax) * ta), xb = Math.round(ax + (bx - ax) * tb);
                int y = ady == 0 ? iy0 : Math.round(ay + (by - ay) * ((float) k / ady));
                c.fill(Math.min(xa, xb), y, Math.max(xa, xb) + 1, y + 1, color);
            }
        } else {
            int n = adx + 1;
            for (int k = 0; k < n; k++) {
                float ta = (k - 0.5f) / adx, tb = (k + 0.5f) / adx;
                ta = Math.max(0f, ta);
                tb = Math.min(1f, tb);
                int ya = Math.round(ay + (by - ay) * ta), yb = Math.round(ay + (by - ay) * tb);
                int x = Math.round(ax + (bx - ax) * ((float) k / adx));
                c.fill(x, Math.min(ya, yb), x + 1, Math.max(ya, yb) + 1, color);
            }
        }
    }

    public static void box3d(DrawContext c, Box b, int color) {
        float[][] pt = new float[8][2];
        float[] o = new float[2];
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? b.minX : b.maxX;
            double y = (i & 2) == 0 ? b.minY : b.maxY;
            double z = (i & 4) == 0 ? b.minZ : b.maxZ;
            if (!project(x, y, z, o)) return;
            pt[i][0] = o[0];
            pt[i][1] = o[1];
        }
        int[][] edges = {{0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
        for (int[] e : edges) line(c, pt[e[0]][0], pt[e[0]][1], pt[e[1]][0], pt[e[1]][1], color);
    }

    public static void box2d(DrawContext c, int x1, int y1, int x2, int y2, int color, boolean fill) {
        if (fill) c.fill(x1, y1, x2, y2, Gfx.alpha(color, 0.12f));
        // dark outline for contrast, then colour
        int dk = 0xB0000000;
        c.fill(x1 - 1, y1 - 1, x2 + 1, y1 + 1, dk);
        c.fill(x1 - 1, y2 - 1, x2 + 1, y2 + 1, dk);
        c.fill(x1 - 1, y1, x1 + 1, y2, dk);
        c.fill(x2 - 1, y1, x2 + 1, y2, dk);
        c.fill(x1, y1, x2, y1 + 1, color);
        c.fill(x1, y2 - 1, x2, y2, color);
        c.fill(x1, y1, x1 + 1, y2, color);
        c.fill(x2 - 1, y1, x2, y2, color);
    }

    /** CS2-style corner brackets. */
    public static void corners(DrawContext c, int x1, int y1, int x2, int y2, int color, boolean fill) {
        if (fill) c.fill(x1, y1, x2, y2, Gfx.alpha(color, 0.10f));
        int len = Math.max(3, Math.min((x2 - x1), (y2 - y1)) / 4);
        int dk = 0xB0000000;
        // top-left, top-right, bottom-left, bottom-right
        for (int pass = 0; pass < 2; pass++) {
            int col = pass == 0 ? dk : color;
            int o = pass == 0 ? 1 : 0;
            c.fill(x1 - o, y1 - o, x1 + len + o, y1 + 1 + o, col);
            c.fill(x1 - o, y1 - o, x1 + 1 + o, y1 + len + o, col);
            c.fill(x2 - len - o, y1 - o, x2 + o, y1 + 1 + o, col);
            c.fill(x2 - 1 - o, y1 - o, x2 + o, y1 + len + o, col);
            c.fill(x1 - o, y2 - 1 - o, x1 + len + o, y2 + o, col);
            c.fill(x1 - o, y2 - len - o, x1 + 1 + o, y2 + o, col);
            c.fill(x2 - len - o, y2 - 1 - o, x2 + o, y2 + o, col);
            c.fill(x2 - 1 - o, y2 - len - o, x2 + o, y2 + o, col);
        }
    }

    /** Vertical health bar on the left of a box (CS2 style): green->red with the HP number. */
    public static void healthBar(DrawContext c, int x1, int y1, int y2, float hp, float max, float absorb, boolean number) {
        float frac = MathHelper.clamp(hp / Math.max(1f, max), 0f, 1f);
        int h = y2 - y1;
        int bx = x1 - 6;
        c.fill(bx - 1, y1 - 1, bx + 3, y2 + 1, 0xB0000000);
        int fillH = Math.max(1, Math.round(h * frac));
        int col = Gfx.lerp(0xFFFF3B30, 0xFF30D158, frac);
        c.fillGradient(bx, y2 - fillH, bx + 2, y2, col, Gfx.lerp(col, 0xFF000000, 0.25f));
        if (absorb > 0f) {
            int ah = Math.min(h, Math.round(h * MathHelper.clamp(absorb / Math.max(1f, max), 0f, 1f)));
            c.fill(bx + 2, y2 - ah, bx + 3, y2, 0xFFFFD60A);
        }
        if (number && frac < 1f) {
            String s = Integer.toString(Math.round(hp));
            int ty = Math.max(y1, y2 - fillH - 4);
            Gfx.textShadow(c, s, bx - Gfx.width(s) - 2, ty, 0xFFFFFFFF);
        }
    }

    public static void label(DrawContext c, String s, int cxm, int y, int color) {
        Gfx.textShadow(c, s, cxm - Gfx.width(s) / 2, y, color);
    }

    // ---- colours --------------------------------------------------------------------------------

    public static final String[] COLORS = {"Red", "Accent", "Green", "White", "Rainbow", "Distance"};

    public static int color(int mode, double dist, double maxDist, int idx) {
        switch (mode) {
            case 0: return 0xFFFF453A;
            case 1: return Gfx.ACCENT;
            case 2: return Gfx.GREEN;
            case 3: return 0xFFFFFFFF;
            case 4: return 0xFF000000 | java.awt.Color.HSBtoRGB(((System.currentTimeMillis() % 4000L) / 4000f + idx * 0.06f) % 1f, 0.65f, 1f);
            default: return Gfx.lerp(0xFFFF453A, 0xFF30D158, (float) Math.min(1.0, dist / Math.max(1.0, maxDist)));
        }
    }
}
