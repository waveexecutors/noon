package dev.noon.render;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Box;

/** Shared entity ESP drawing for PlayerESP / MobESP. */
public final class EntityDraw {
    private EntityDraw() {}

    public static final String[] STYLES = {"CS2 Corners", "2D Box", "3D Box"};
    private static final float[] R = new float[4];

    public static void draw(DrawContext c, LivingEntity e, int style, int color, boolean fill,
                            boolean health, boolean name, boolean dist, boolean weapon, double d) {
        Box b = Esp.lerped(e);
        if (!Esp.rect(b, R)) return;
        int x1 = Math.round(R[0]), y1 = Math.round(R[1]), x2 = Math.round(R[2]), y2 = Math.round(R[3]);
        if (x2 - x1 < 2 || y2 - y1 < 2) return;

        if (style == 2) {
            Esp.box3d(c, b, color);
        } else if (style == 1) {
            Esp.box2d(c, x1, y1, x2, y2, color, fill);
        } else {
            Esp.corners(c, x1, y1, x2, y2, color, fill);
        }

        int mid = (x1 + x2) / 2;
        if (health) Esp.healthBar(c, x1, y1, y2, e.getHealth(), e.getMaxHealth(), e.getAbsorptionAmount(), true);
        if (name) Esp.label(c, e.getName().getString(), mid, y1 - 11, 0xFFFFFFFF);
        int by = y2 + 3;
        if (weapon) {
            ItemStack st = e.getMainHandStack();
            if (!st.isEmpty()) {
                Esp.label(c, st.getName().getString(), mid, by, 0xFFE5E5EA);
                by += 10;
            }
        }
        if (dist) Esp.label(c, Math.round(d) + "m", mid, by, 0xFFAEAEB2);
    }
}
