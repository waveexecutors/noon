package dev.noon.emote;

/** Single active clip playback clock with pause/resume and thread-safe pose sampling. */
public final class EmoteController {
 private static final EmoteController INSTANCE=new EmoteController();
 private EmoteAnimation active; private long started,pausedAt; private boolean loop=true,paused; private double speed=1;
 public static EmoteController get(){return INSTANCE;}
 public synchronized void play(EmoteAnimation clip,boolean looping){active=clip;loop=looping;started=System.nanoTime();paused=false;}
 public synchronized void stop(){active=null;paused=false;}
 public synchronized boolean playing(){return active!=null;}
 public synchronized EmoteAnimation current(){return active;}
 public synchronized void speed(double value){speed=Math.max(.1,Math.min(3,value));}
 public synchronized void pause(boolean value){if(active==null||paused==value)return;if(value){pausedAt=System.nanoTime();paused=true;}else{started+=System.nanoTime()-pausedAt;paused=false;}}
 public synchronized double tick(){if(active==null)return 0;long now=paused?pausedAt:System.nanoTime();double t=(now-started)/50_000_000.0*speed;int end=Math.max(1,active.endTick());if(loop)return t%end;if(t>=end){active=null;return end;}return t;}
 public synchronized EmoteAnimation.Transform sample(String bone){return active==null?EmoteAnimation.Transform.ZERO:active.sample(bone,tick());}
}
