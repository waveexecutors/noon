package dev.noon.emote;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Loads native .anim clips from config/poco/emotes and bundled assets. */
public final class EmoteLoader {
 private EmoteLoader(){}
 public static Path folder(){Path p=FabricLoader.getInstance().getConfigDir().resolve("poco/emotes");try{Files.createDirectories(p);copyBundled(p);}catch(IOException ignored){}return p;}
 private static void copyBundled(Path p)throws IOException{try(var stream=EmoteLoader.class.getResourceAsStream("/assets/noon/animations/")){/* classpath directory enumeration is not portable; shipped clips are loaded below */}}
 public static Map<String,EmoteAnimation> loadAll(){Map<String,EmoteAnimation> out=new LinkedHashMap<>();String[] ids={"bloody_pop","caramell_dansen","jumpstyle","miku_live","phit_hon","sad_cat_1","sad_cat_2"};for(String id:ids){try(InputStream in=EmoteLoader.class.getResourceAsStream("/assets/noon/animations/"+id+".anim")){if(in!=null)out.put(id,parse(in));}catch(Exception ignored){}}
 Path dir=folder();try(var files=Files.list(dir)){files.filter(f->f.toString().endsWith(".anim")).forEach(f->{try(InputStream in=Files.newInputStream(f)){out.put(strip(f.getFileName().toString()),parse(in));}catch(Exception ignored){}});}catch(IOException ignored){}return Collections.unmodifiableMap(out);}
 private static String strip(String s){return s.substring(0,s.length()-5);}
 public static EmoteAnimation parse(InputStream in)throws IOException{JsonObject root=JsonParser.parseReader(new InputStreamReader(in,StandardCharsets.UTF_8)).getAsJsonObject();if(!"poco-anim".equals(root.get("format").getAsString()))throw new IOException("Unsupported animation format");List<EmoteAnimation.Keyframe> frames=new ArrayList<>();for(JsonElement el:root.getAsJsonArray("keyframes")){JsonObject k=el.getAsJsonObject();Map<String,EmoteAnimation.Transform> bones=new HashMap<>();for(String bone:List.of("head","body","rightArm","leftArm","rightLeg","leftLeg")){if(!k.has(bone))continue;JsonObject v=k.getAsJsonObject(bone);bones.put(bone,new EmoteAnimation.Transform(num(v,"x"),num(v,"y"),num(v,"z"),num(v,"pitch"),num(v,"yaw"),num(v,"roll")));}frames.add(new EmoteAnimation.Keyframe(k.get("tick").getAsDouble(),k.has("easing")?k.get("easing").getAsString():"linear",Map.copyOf(bones)));}frames.sort(Comparator.comparingDouble(EmoteAnimation.Keyframe::tick));return new EmoteAnimation(root.get("name").getAsString(),root.get("endTick").getAsInt(),root.get("loop").getAsBoolean(),root.get("degrees").getAsBoolean(),List.copyOf(frames));}
 private static double num(JsonObject o,String k){return o.has(k)?o.get(k).getAsDouble():0;}
}
