package dev.noon.emote;

import java.util.*;

/** Immutable native Poco animation clip. All rotations are radians unless degrees=true. */
public record EmoteAnimation(String name, int endTick, boolean loop, boolean degrees, List<Keyframe> keyframes) {
    public record Transform(double x,double y,double z,double pitch,double yaw,double roll) {
        public static final Transform ZERO = new Transform(0,0,0,0,0,0);
        public Transform lerp(Transform b,double t) { return new Transform(m(x,b.x,t),m(y,b.y,t),m(z,b.z,t),m(pitch,b.pitch,t),m(yaw,b.yaw,t),m(roll,b.roll,t)); }
        private static double m(double a,double b,double t){return a+(b-a)*t;}
    }
    public record Keyframe(double tick,String easing,Map<String,Transform> bones) {}
    public Transform sample(String bone,double tick) {
        if(keyframes.isEmpty()) return Transform.ZERO;
        Keyframe a=null,b=null;
        for(Keyframe k:keyframes){if(k.tick()<=tick)a=k;if(k.tick()>=tick){b=k;break;}}
        if(a==null)a=keyframes.getFirst(); if(b==null)b=keyframes.getLast();
        Transform av=a.bones().getOrDefault(bone,Transform.ZERO), bv=b.bones().getOrDefault(bone,av);
        if(a==b)return av;
        double t=Math.max(0,Math.min(1,(tick-a.tick())/(b.tick()-a.tick())));
        t=ease(b.easing(),t);
        if(degrees)t=Math.max(0,Math.min(1,t));
        return av.lerp(bv,t);
    }
    private static double ease(String e,double t){if(e==null)return t;return switch(e.toLowerCase(Locale.ROOT)){case "linear"->t;case "outquart"->1-Math.pow(1-t,4);case "inoutquad"->t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2;case "outcubic"->1-Math.pow(1-t,3);case "incubic"->t*t*t;case "inoutcubic"->t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;default->t;};}
}
