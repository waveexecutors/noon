package dev.noon.hud;

import dev.noon.module.Module;
import dev.noon.module.ModuleManager;
import dev.noon.module.client.HudModule;
import dev.noon.util.Gfx;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

/** Customisable flat HUD: watermark, coordinates, module list (all driven by the HUD module's settings). */
public final class Hud {
    private Hud() {}

    private static String customText = "Poco";
    private static long customRead;

    private static String custom() {
        long now = System.currentTimeMillis();
        if (now - customRead > 2000) {
            customRead = now;
            try {
                Path f = FabricLoader.getInstance().getConfigDir().resolve("noon_hud.txt");
                if (Files.exists(f)) {
                    String l = Files.readAllLines(f, StandardCharsets.UTF_8).stream().findFirst().orElse("").trim();
                    if (!l.isEmpty()) customText = l;
                }
            } catch (Exception ignored) {
            }
        }
        return customText;
    }

    public static int color(float t) {
        HudModule h = HudModule.INSTANCE;
        switch (h.colorMode.index) {
            case 1:
                return 0xFF000000 | java.awt.Color.HSBtoRGB((float) ((System.currentTimeMillis() / 1000.0 * h.rainbowSpeed.get() * 0.2 + t) % 1.0), 0.65f, 1f);
            case 2:
                return 0xFFFFFFFF;
            case 3:
                return 0xFF000000 | (h.cr.i() << 16) | (h.cg.i() << 8) | h.cb.i();
            default:
                return Gfx.ACCENT;
        }
    }

    private static int[] place(int corner, int w, int h, int sw, int sh, int ox, int oy) {
        boolean right = corner == 1 || corner == 3, bottom = corner >= 2;
        int x = right ? sw - 6 - w - ox : 6 + ox;
        int y = bottom ? sh - 6 - h - oy : 6 + oy;
        return new int[]{x, y};
    }

    private static int labelWidth(Module m, HudModule h) {
        String suf = h.listSuffix.get() ? m.suffix() : "";
        return Gfx.width(m.name) + (suf.isEmpty() ? 0 : Gfx.width(suf) + 5) + 12;
    }

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        HudModule h = HudModule.INSTANCE;
        float master = h.master.to(h.enabled ? 1f : 0f, 10f);
        if (master < 0.01f) return;

        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();

        // ---- watermark ----
        if (h.watermark.get()) {
            String name;
            switch (h.wmText.index) {
                case 1: name = "Poco Client"; break;
                case 2: name = mc.getSession().getUsername(); break;
                case 3: name = custom(); break;
                default: name = "Poco";
            }
            StringBuilder rest = new StringBuilder();
            if (h.wmFps.get()) rest.append("  |  ").append(mc.getCurrentFps()).append(" fps");
            if (h.wmPing.get()) {
                PlayerListEntry e = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                rest.append("  |  ").append(e == null ? 0 : e.getLatency()).append(" ms");
            }
            if (h.wmTime.get()) rest.append("  |  ").append(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
            int w = Gfx.width(name) + Gfx.width(rest.toString()) + 14;
            int[] pos = place(h.wmPos.index, w, 16, sw, sh, h.wmX.i(), h.wmY.i());
            int x = pos[0] - Math.round((1f - master) * 24f), y = pos[1];
            if (h.wmStyle.index == 0) Gfx.rrect(ctx, x, y, w, 16, 6, Gfx.alpha(0xB0101014, master));
            int col = color(0f);
            Gfx.textShadow(ctx, name, x + 7, y + 4, Gfx.alpha(col, master));
            Gfx.textShadow(ctx, rest.toString(), x + 7 + Gfx.width(name), y + 4, Gfx.alpha(Gfx.WHITE, master));
            if (h.wmStyle.index == 2) ctx.fill(x + 7, y + 14, x + w - 7, y + 15, Gfx.alpha(col, master));
        }

        // ---- coordinates ----
        if (h.coords.get()) {
            String c = mc.player.getBlockX() + ", " + mc.player.getBlockY() + ", " + mc.player.getBlockZ();
            int w = Gfx.width(c) + 14;
            int[] pos = place(h.coordPos.index, w, 16, sw, sh, 0, 0);
            Gfx.rrect(ctx, pos[0], pos[1], w, 16, 6, Gfx.alpha(0xB0101014, master));
            Gfx.textShadow(ctx, c, pos[0] + 7, pos[1] + 4, Gfx.alpha(Gfx.WHITE, master));
        }

        // ---- module list ----
        if (h.list.get()) {
            List<Module> visible = new ArrayList<>();
            for (Module m : ModuleManager.all()) {
                float a = m.hud.to(m.enabled && m.showInHud ? 1f : 0f, 10f);
                if (m.showInHud && a > 0.01f) visible.add(m);
            }
            switch (h.listSort.index) {
                case 1: visible.sort(Comparator.comparingInt((Module m) -> labelWidth(m, h))); break;
                case 2: visible.sort(Comparator.comparing((Module m) -> m.name)); break;
                default: visible.sort(Comparator.comparingInt((Module m) -> -labelWidth(m, h)));
            }
            boolean right = h.listSide.index == 1, bottom = h.listVert.index == 1;
            int spacing = h.listSpacing.i();
            int y = bottom ? sh - 6 - h.listY.i() - spacing : 6 + h.listY.i() + (h.watermark.get() && h.wmPos.index == (right ? 1 : 0) ? 20 : 0);
            int idx = 0;
            for (Module m : visible) {
                float a = m.hud.v;
                float alpha = a * master;
                int w = labelWidth(m, h);
                int slide = Math.round((1f - a) * (w + 12));
                int x = right ? sw - 6 - h.listX.i() - w + slide : 6 + h.listX.i() - slide;
                int col = h.listColored.get() ? color(idx * 0.06f) : Gfx.WHITE;
                if (h.listBg.get()) Gfx.rrect(ctx, x, y - 1, w, spacing - 1, 4, Gfx.alpha(0x99101014, alpha));
                if (h.listBar.get()) ctx.fill(right ? x + w - 2 : x, y - 1, right ? x + w : x + 2, y + spacing - 2, Gfx.alpha(color(idx * 0.06f), alpha));
                int tx = right ? x + 4 : x + 6;
                if (h.listShadow.get()) Gfx.textShadow(ctx, m.name, tx, y + (spacing - 9) / 2, Gfx.alpha(col, alpha));
                else Gfx.text(ctx, m.name, tx, y + (spacing - 9) / 2, Gfx.alpha(col, alpha));
                String suf = h.listSuffix.get() ? m.suffix() : "";
                if (!suf.isEmpty()) {
                    Gfx.text(ctx, suf, tx + Gfx.width(m.name) + 5, y + (spacing - 9) / 2, Gfx.alpha(Gfx.GREY, alpha));
                }
                int step = Math.round(spacing * a);
                y += bottom ? -step : step;
                idx++;
            }
        }
    }
}
