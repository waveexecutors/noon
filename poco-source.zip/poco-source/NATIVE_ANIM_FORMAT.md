# Poco `.anim` format (version 1)

A `.anim` file is UTF-8 JSON. Required root properties: `format` (`poco-anim`), `version` (1), `name`, `endTick`, `loop`, `degrees`, and `keyframes`. `keyframes` is an ordered array of objects with numeric `tick`, optional `easing`, and any of `head`, `body`, `rightArm`, `leftArm`, `rightLeg`, `leftLeg`. A bone object may contain `x`, `y`, `z`, `pitch`, `yaw`, and `roll`; omitted values default to zero. Supported easing names currently include Linear, OutQuart, InOutQuad, OutCubic, InCubic, and InOutCubic; unknown easing names fall back to linear. Rotations are radians unless `degrees` is true.

Import additional files by placing `*.anim` in `<game config>/poco/emotes`. Bundled clips are loaded automatically.
