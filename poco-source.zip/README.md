# Poco (Fabric 1.21.11)

Utility client. Right Shift opens the ClickGUI.

Build locally: `gradle build` (Gradle 9.2+, Java 21) -> `build/libs/noon-1.0.0.jar`.
Config is saved to `config/noon.properties`.

ClickGUI: left click = toggle, right click (or the arrow) = expand settings, mouse wheel / Up / Down = scroll.
Turn the "HUD" module off to hide the whole HUD.

## New in this version
- **ClickGUI**: iOS-26 liquid-glass look, spring animations, staggered card entrance, culled off-screen cards, cached rounded-rect tables (no more lag).
- **Render**: Player ESP (CS2 corners / 2D / 3D box, health bar + HP number, name, held item, distance), Mob ESP (+items), Storage ESP, Tracers.
- **SMP**: BaseFinder (chunk scoring -> markers + list + chat ping), AutoEat, ChestStealer, AutoRespawn (+death coords), AutoLog, PlayerAlert, FastPlace.
- **Combat**: AutoClicker, AimAssist, HitBox, WTap, JumpReset.
- **Fix**: hand animations - vanilla swing is now zeroed while a custom swing is selected, and the mixin matches by argument type.
  Turn the "Animations" module ON, then pick Attack / Mining anim in its settings.
- **Alt Manager**: button top-left of the title screen. Offline/cracked accounts only (config/noon_alts.txt). Criticals 'Legit' mode no longer touches velocity or delays clicks.

## v6
- ClickGUI: flat modern style, no vanilla blur (lag fix), no nested scissor (right-click / expand crash fix).
- Hand Glow module (RGB / custom / fade / pulse), Configs tab (presets + 3 save slots), more settings on KillAura, TriggerBot, Velocity, Animations, NoFall, AutoSprint, FastBreak.
- Presets are conservative, NOT guaranteed undetectable.

## v7 fixes
- **Hand Glow**: now outlines the real hand. The first-person arm box is rebuilt from the vanilla hand transform (swing, equip, bobbing, Animations, Hand Customization) and projected to the screen, then a solid thick outline + fading glow is filled around its silhouette. Settings: Outline Thickness, Glow Spread/Intensity/Layers, Hand FOV (70 = vanilla), Slim Arms. Vanilla only draws a hand when the main hand is empty; "Item Box (approx)" outlines held items' bounding box.
- **CrystalAura / SilentCrystalAura**: damage estimate now includes armor, toughness, Resistance and difficulty (before it ignored armor, so with Max Self Damage 6 every spot was rejected and nothing happened). New: Allow Self Dmg For Kill, Auto Obsidian (puts obsidian next to the target if there is none, needs obsidian in hotbar), delays default 1 tick.

## v8
- **Hand Glow**: held items are glowed by default (tight-fit box, `Item Fit`), plus `Align X / Y / Scale` sliders to nudge the glow onto your hand if your setup shifts it.
- **Animations**: 13 more swing styles (24 total), Idle Sway, Walk Bob, Animate Off Hand.
- **Combat**: AutoWeapon, ShieldBreaker, AutoPot, AutoPearl, BowAimbot, BowRelease, AutoShield.
- **SMP**: StaffRadar (loud siren + staff name and head on screen when vanished / spectating / invisible / ranked players are near;
  optional names in `config/noon_staff.txt`), AutoFish, AntiAFK, AutoReplenish, LogoutSpots, ChatAlert (`config/noon_keywords.txt`), DurabilityAlert.
- **ClickGUI**: new flat layout - tabs, search (click the box and type), per-module descriptions in the footer, inline settings.

## v8.1
- **StaffRadar**: vanished players are never sent to your client as entities (vanilla drops a player spawn that has no tab entry), so it now also uses packets:
  hidden-spawn detection, unseen footsteps / player sounds, and "left the tab list while near you" (fake quit) for staff-looking players.
  Stationary tab-less NPCs/bots are ignored by default.
- **Hand Glow**: camera-rotation fix (Camera Fix: Auto/Off/Force) and a hard cap on fill calls (the lag).
- **Animations**: Walk Bob styles (Smooth, Swagger, Bounce, Figure 8, Drift, Stomp), amount, sprint scaling, Look Sway.

## v9 (Poco)
- Renamed to Poco (display name, HUD, chat prefix). Jar / mod id / config file names stay `noon` so nothing breaks.
- Main menu replaced with the Poco menu (HyperOS -> POCO boot splash on first launch, golden corner discs, glowing panel). Click / Space skips the splash.
- Custom sounds from assets/noon/sounds (key clicks, notification, charging = boot sound).
- Module toggle notifications (HUD > Module Notifications / Notification Sound).
- Smooth fonts: Inter + Poppins Bold (OFL licensed) via assets/noon/font.
- New Movement tab: Speed, Flight, Jesus, SafeWalk, AutoJump, Spider, Parkour (+ AutoSprint, Step, NoFall moved here).
- ClickGUI restyled to the Poco look, no footer text.
