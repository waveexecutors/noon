# Poco source patch v7

- Fixed the literal `\\n` accidentally embedded between the HandGlow constants; they are now separate Java declarations.
- Poco menu text now always uses Minecraft's built-in text renderer; custom font providers are no longer requested by this UI helper.
- Improved the ambient background discs with fractional edge coverage to reduce the visible stair-step effect.

## Animation frame rate
The menu animation is evaluated on every Minecraft render frame and uses elapsed time, so it animates smoothly at the game's current render rate. It does not force the game to render at 60 FPS: forcing a separate 60 FPS loop from a screen render hook is not supported and would waste battery or cause uneven pacing on Android. Set Minecraft's frame-rate limit to 60 in Video settings if you want a 60 FPS cap; the menu will then update at up to that rate.

## Not verified
This archive has not been compiled or launched in Minecraft. The original Inter OTF resource files remain in the assets but are not selected by PocoMenu's font helper anymore. Other code elsewhere could still request them.
