# Fixes applied to this source snapshot

- Removed `PlayerEntityModelMixin` from the active `noon.mixins.json` list. This prevents the stale `@Shadow ModelPart` field binding from crashing startup. Player emote pose transforms are temporarily disabled until the correct 1.21.11 model fields are verified.
- `Fonts.java` now applies the requested `noon:<font>` resource identifier to text and measures/draws the styled Text. Previously the `font` argument was ignored and all UI text used Minecraft's default font.
- Hand Glow now downsamples its CPU raster mask to a maximum of 160x160 per hand, independent of Android GUI scale, while drawing it over the same GUI-space bounds. This reduces distance-field and pixel-write work substantially.

## Font limitation still requiring a proper asset
The included `inter-medium.otf` and `inter-semibold.otf` are CFF/OpenType fonts, but the Minecraft `ttf` font provider requires TrueType outlines. The source JSON still references those assets, so Minecraft may reject them. I have deliberately not replaced them with a different typeface and claimed that Inter was fixed. They need genuine Inter TTF assets (Medium and SemiBold) before the font work is complete.
