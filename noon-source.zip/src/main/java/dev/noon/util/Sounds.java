package dev.noon.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public final class Sounds {
    private Sounds() {}

    private static SoundEvent ev(Object o) {
        if (o instanceof RegistryEntry<?> e) return (SoundEvent) e.value();
        return (SoundEvent) o;
    }

    private static void play(Object sound, float pitch, float volume) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.getSoundManager() == null) return;
        mc.getSoundManager().play(PositionedSoundInstance.master(ev(sound), pitch, volume));
    }

    /** Whoosh used when the ClickGUI slides in/out. */
    public static void slide(boolean open) {
        play(SoundEvents.ENTITY_BAT_TAKEOFF, open ? 1.9f : 1.5f, 0.45f);
    }

    public static void click() {
        play(SoundEvents.UI_BUTTON_CLICK, 1.3f, 0.5f);
    }

    /** Loud two-tone siren step. Several stacked layers make it much louder than a single sound. */
    public static void alarmTone(int step, int layers) {
        boolean hi = (step & 1) == 0;
        for (int i = 0; i < Math.max(1, layers); i++) {
            play(SoundEvents.BLOCK_NOTE_BLOCK_PLING, hi ? 2.0f : 1.35f, 1.0f);
            play(SoundEvents.BLOCK_NOTE_BLOCK_BELL, hi ? 1.9f : 1.2f, 1.0f);
        }
        if (step == 0) {
            for (int i = 0; i < Math.max(1, layers); i++) {
                play(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 1.4f, 1.0f);
                play(SoundEvents.BLOCK_BELL_USE, 0.8f, 1.0f);
            }
        }
    }

    public static void ping() {
        play(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 0.9f);
    }

    public static void warn() {
        play(SoundEvents.BLOCK_NOTE_BLOCK_PLING, 0.7f, 1.0f);
    }
}
