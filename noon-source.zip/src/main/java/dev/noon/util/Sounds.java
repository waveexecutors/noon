package dev.noon.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public final class Sounds {
    private Sounds() {}

    private static SoundEvent ev(Object o) {
        if (o instanceof RegistryEntry<?> e) return (SoundEvent) e.value();
        return (SoundEvent) o;
    }

    private static void play(Object sound, float pitch, float volume) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.getSoundManager() == null) return;
        mc.getSoundManager().play(PositionedSoundInstance.master(ev(sound), pitch, volume));
    }

    /** Whoosh used when the ClickGUI slides in/out. */
    public static void slide(boolean open) {
        play(SoundEvents.ENTITY_BAT_TAKEOFF, open ? 1.9f : 1.5f, 0.45f);
    }

    public static void click() {
        play(SoundEvents.UI_BUTTON_CLICK, 1.3f, 0.5f);
    }
}
