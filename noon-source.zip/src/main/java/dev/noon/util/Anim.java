package dev.noon.util;

/** Frame-rate independent smoothing value. Call to() once per frame. */
public final class Anim {
    public float v;
    private long last = System.nanoTime();

    public float to(float target, float speed) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1_000_000_000f);
        last = now;
        v += (target - v) * (1f - (float) Math.exp(-speed * dt));
        if (Math.abs(target - v) < 0.002f) v = target;
        return v;
    }
}
