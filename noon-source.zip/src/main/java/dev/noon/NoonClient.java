package dev.noon;

import dev.noon.gui.ClickGuiScreen;
import dev.noon.hud.Hud;
import dev.noon.module.ModuleManager;
import dev.noon.module.combat.Criticals;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class NoonClient implements ClientModInitializer {
    private boolean prevKey;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ModuleManager.load();

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> ModuleManager.save());
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> Hud.render(ctx));

        // manual attacks go through Criticals (it may delay them until the hop peaks)
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (player == MinecraftClient.getInstance().player && !Criticals.internal && Criticals.handle(entity)) {
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
    }

    private void tick(MinecraftClient mc) {
        if (mc.getWindow() == null) return;

        // Right Shift opens / closes the ClickGUI
        boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (down && !prevKey) {
            if (mc.currentScreen instanceof ClickGuiScreen gui) {
                if (!gui.isBinding()) gui.requestClose();
            } else if (mc.currentScreen == null && mc.player != null) {
                mc.setScreen(new ClickGuiScreen());
            }
        }
        prevKey = down;

        if (mc.player != null && mc.world != null) {
            ModuleManager.tick();
        }
    }
}
