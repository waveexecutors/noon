package dev.noon.alt;

import dev.noon.util.Anim;
import dev.noon.util.Gfx;
import dev.noon.util.Sounds;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Glass alt manager: type a name -> "Add & Use", click an account to switch, x to delete. */
public class AltScreen extends Screen {
    private static final int W = 300, ROW = 24;

    private final Screen parent;
    private TextFieldWidget field;
    private final Anim open = new Anim();
    private float scroll, scrollTarget;
    private boolean prevL;
    private String status = "";
    private int statusColor = Gfx.GREY;

    public AltScreen(Screen parent) {
        super(Text.literal("Accounts"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int x = (this.width - W) / 2, top = Math.max(20, (this.height - 270) / 2);
        field = new TextFieldWidget(this.textRenderer, x + 16, top + 44, W - 32 - 96, 20, Text.literal("Username"));
        field.setMaxLength(16);
        field.setPlaceholder(Text.literal("Username (3-16: a-z 0-9 _)"));
        addDrawableChild(field);
        addDrawableChild(ButtonWidget.builder(Text.literal("Add & Use"), b -> addAndUse(field.getText()))
                .dimensions(x + W - 16 - 92, top + 44, 92, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Random"), b -> addAndUse(AltManager.random()))
                .dimensions(x + 16, top + 70, 80, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> this.client.setScreen(parent))
                .dimensions(x + W - 16 - 80, top + 70, 80, 20).build());
        setInitialFocus(field);
    }

    private void addAndUse(String name) {
        name = name == null ? "" : name.trim();
        if (!AltManager.valid(name)) {
            status = "Invalid name (3-16 chars: letters, numbers, _)";
            statusColor = Gfx.RED;
            return;
        }
        AltManager.add(name);
        use(name);
        field.setText("");
    }

    private void use(String name) {
        if (AltManager.use(name)) {
            status = "Now playing as " + name;
            statusColor = Gfx.GREEN;
            Sounds.click();
        } else {
            status = "Could not switch session (see log)";
            statusColor = Gfx.RED;
        }
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    // vanilla mouse wheel (no @Override on purpose, same approach as the ClickGUI)
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollTarget -= (float) verticalAmount * ROW;
        return true;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        float o = open.to(1f, 12f);
        int x = (this.width - W) / 2, top = Math.max(20, (this.height - 270) / 2);
        int h = Math.min(270, this.height - 40);

        Gfx.shadow(ctx, x, top, W, h, 20, o);
        Gfx.glass(ctx, x, top, W, h, 20, o);
        Gfx.textShadow(ctx, "Accounts", x + 18, top + 16, Gfx.alpha(Gfx.WHITE, o));
        String cur = "Playing as " + AltManager.current();
        Gfx.text(ctx, cur, x + W - 18 - Gfx.width(cur), top + 16, Gfx.alpha(Gfx.GREY, o));

        int listTop = top + 98, listBottom = top + h - 28;
        int viewH = listBottom - listTop;
        int total = AltManager.ALTS.size() * ROW;
        scrollTarget = Math.max(0, Math.min(scrollTarget, Math.max(0, total - viewH)));
        scroll += (scrollTarget - scroll) * 0.25f;

        long handle = this.client.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean click = l && !prevL;
        prevL = l;

        ctx.enableScissor(x + 10, listTop, x + W - 10, listBottom);
        int y = listTop - Math.round(scroll);
        String toRemove = null, toUse = null;
        for (String name : AltManager.ALTS) {
            if (y + ROW > listTop && y < listBottom) {
                boolean inList = my >= listTop && my < listBottom;
                boolean hov = inList && mx >= x + 14 && mx < x + W - 14 && my >= y && my < y + ROW - 2;
                boolean active = name.equals(AltManager.current());
                Gfx.card(ctx, x + 14, y, W - 28, ROW - 3, 9, o, hov ? 1f : 0f);
                if (active) Gfx.rrect(ctx, x + 14, y, W - 28, ROW - 3, 9, Gfx.alpha(0x330A84FF, o));
                Gfx.text(ctx, name, x + 26, y + (ROW - 3 - 8) / 2, Gfx.alpha(Gfx.WHITE, o));
                int xx = x + W - 14 - 20;
                boolean xHov = hov && mx >= xx;
                Gfx.text(ctx, "x", xx + 7, y + (ROW - 3 - 8) / 2, Gfx.alpha(xHov ? Gfx.RED : Gfx.GREY, o));
                if (active) Gfx.text(ctx, "active", xx - 8 - Gfx.width("active"), y + (ROW - 3 - 8) / 2, Gfx.alpha(Gfx.GREEN, o));
                if (hov && click) {
                    if (xHov) toRemove = name;
                    else toUse = name;
                }
            }
            y += ROW;
        }
        ctx.disableScissor();
        if (AltManager.ALTS.isEmpty()) Gfx.text(ctx, "No accounts yet - type a name above.", x + 26, listTop + 8, Gfx.alpha(Gfx.GREY, o));
        if (toRemove != null) AltManager.remove(toRemove);
        if (toUse != null) use(toUse);

        if (!status.isEmpty()) Gfx.text(ctx, status, x + 18, top + h - 18, Gfx.alpha(statusColor, o));
    }
}
