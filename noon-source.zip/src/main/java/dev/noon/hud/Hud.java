package dev.noon.hud;

import dev.noon.module.Module;
import dev.noon.module.ModuleManager;
import dev.noon.module.client.HudModule;
import dev.noon.util.Gfx;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Modern glass HUD: watermark top-left, active module list top-right. Toggle the "HUD" module to hide it all. */
public final class Hud {
    private Hud() {}

    private static int labelWidth(Module m) {
        String suf = m.suffix();
        return Gfx.width(m.name) + (suf.isEmpty() ? 0 : Gfx.width(suf) + 5) + 18;
    }

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        HudModule h = HudModule.INSTANCE;
        float master = h.master.to(h.enabled ? 1f : 0f, 10f);
        if (master < 0.01f) return;

        int sw = ctx.getScaledWindowWidth();

        if (h.watermark.get()) {
            String rest = "  |  " + mc.getCurrentFps() + " fps";
            int w = Gfx.width("Noon") + Gfx.width(rest) + 18;
            int x = 6 - Math.round((1f - master) * 24f);
            Gfx.glass(ctx, x, 6, w, 18, 9, master);
            Gfx.text(ctx, "Noon", x + 9, 11, Gfx.alpha(0xFF64B5FF, master));
            Gfx.text(ctx, rest, x + 9 + Gfx.width("Noon"), 11, Gfx.alpha(Gfx.WHITE, master));
        }

        if (h.list.get()) {
            List<Module> visible = new ArrayList<>();
            for (Module m : ModuleManager.all()) {
                float a = m.hud.to(m.enabled && m.showInHud ? 1f : 0f, 10f);
                if (m.showInHud && a > 0.01f) visible.add(m);
            }
            visible.sort(Comparator.comparingInt((Module m) -> -labelWidth(m)));

            int y = 6;
            for (Module m : visible) {
                float a = m.hud.v;
                float alpha = a * master;
                int w = labelWidth(m);
                int x = sw - 6 - w + Math.round((1f - a) * (w + 12));
                Gfx.glass(ctx, x, y, w, 16, 6, alpha);
                Gfx.rrect(ctx, x + 5, y + 4, 2, 8, 1, Gfx.alpha(Gfx.ACCENT, alpha));
                Gfx.text(ctx, m.name, x + 11, y + 4, Gfx.alpha(Gfx.WHITE, alpha));
                String suf = m.suffix();
                if (!suf.isEmpty()) {
                    Gfx.text(ctx, suf, x + 11 + Gfx.width(m.name) + 5, y + 4, Gfx.alpha(Gfx.GREY, alpha));
                }
                y += Math.round(19f * a);
            }
        }
    }
}
