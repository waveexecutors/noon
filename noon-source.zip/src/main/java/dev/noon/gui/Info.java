package dev.noon.gui;

import java.util.HashMap;
import java.util.Map;

/** One-line descriptions shown in the ClickGUI footer. */
final class Info {
    private Info() {}

    private static final Map<String, String> D = new HashMap<>();

    private static void d(String n, String t) {
        D.put(n, t);
    }

    static {
        // combat
        d("Criticals", "Times attacks so they land as critical hits.");
        d("KillAura", "Attacks entities in range automatically.");
        d("TriggerBot", "Attacks when your crosshair is on a target.");
        d("AutoTotem", "Keeps a totem of undying in your offhand.");
        d("Velocity", "Reduces knockback from hits.");
        d("Reach", "Extends your attack distance.");
        d("AutoArmor", "Equips the best armor from your inventory.");
        d("AutoClicker", "Clicks at a randomised CPS while you hold attack.");
        d("AimAssist", "Smoothly pulls your aim toward nearby players.");
        d("CrystalAura", "Places and breaks end crystals around targets.");
        d("SilentCrystalAura", "Crystal aura that swaps slots silently.");
        d("HitBox", "Enlarges player hitboxes on your client.");
        d("WTap", "Resets sprint after hits for extra knockback.");
        d("JumpReset", "Jumps at the right moment to cut knockback.");
        d("AutoWeapon", "Switches to your best sword or axe when you attack.");
        d("ShieldBreaker", "Swaps to an axe and hits when the target is blocking.");
        d("AutoPot", "Throws a healing splash potion when health is low.");
        d("AutoPearl", "Throws an ender pearl away from enemies when low.");
        d("BowAimbot", "Leads and drops-compensates shots while a bow is drawn.");
        d("BowRelease", "Releases the bow automatically at full draw.");
        d("AutoShield", "Raises your shield when an armed player faces you.");
        // player
        d("FastBreak", "Removes the block breaking delay.");
        d("AutoSprint", "Sprints whenever you move forward.");
        d("NoFall", "Cancels fall damage.");
        d("Step", "Walk up blocks without jumping.");
        d("AutoTool", "Picks the fastest hotbar tool for the block.");
        // render
        d("Player ESP", "Boxes, health and names for players.");
        d("Mob ESP", "Boxes for hostile and passive mobs.");
        d("Storage ESP", "Highlights chests, barrels and other containers.");
        d("Tracers", "Lines from your screen to nearby entities.");
        d("Hand Customization", "Size, position and rotation of held items.");
        d("Animations", "Swing, idle and walking hand animations.");
        d("Hand Glow", "Outline and glow around your first-person hands.");
        // fps
        d("X-Ray", "Shows ores and hides stone.");
        d("Fullbright", "Maximum brightness everywhere.");
        d("NoHurtCam", "Removes the camera shake when damaged.");
        // smp
        d("BaseFinder", "Scores chunks to locate player bases.");
        d("AutoEat", "Eats when your hunger drops.");
        d("ChestStealer", "Moves items out of opened chests.");
        d("AutoRespawn", "Respawns instantly and prints death coordinates.");
        d("AutoLog", "Disconnects when health is critical.");
        d("PlayerAlert", "Notifies when a player enters render distance.");
        d("FastPlace", "Removes the block placing delay.");
        d("StaffRadar", "Loud alarm + name and head when vanished or hidden staff are near.");
        d("AutoFish", "Reels in bites and recasts for you.");
        d("AntiAFK", "Random small actions to avoid idle kicks.");
        d("AutoReplenish", "Refills hotbar stacks from your inventory.");
        d("LogoutSpots", "Marks where players logged out near you.");
        d("ChatAlert", "Sound when chat mentions your name or keywords.");
        d("DurabilityAlert", "Warns when armor or tools are about to break.");
        // client
        d("HUD", "Watermark, coordinates and module list.");
        d("Glass Menu", "Restyled pause menu.");
        d("Configs", "Presets and save slots.");
    }

    static String of(String module) {
        return D.getOrDefault(module, "");
    }
}
