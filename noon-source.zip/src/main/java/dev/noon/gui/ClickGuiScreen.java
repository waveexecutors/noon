package dev.noon.gui;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.ModuleManager;
import dev.noon.module.Setting;
import dev.noon.util.Anim;
import dev.noon.util.Gfx;
import dev.noon.util.Keys;
import dev.noon.util.Sounds;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Noon ClickGUI. Flat, neutral and dense: tab column on the left, module list with inline settings on the right,
 * search on top, description line in the footer. Input is polled straight from GLFW (no Screen input signatures).
 * Left click toggles, right click (or the chevron) expands settings, scroll wheel / Up / Down scrolls.
 */
public class ClickGuiScreen extends Screen {
    // palette
    private static final int BG = 0xFF111215, SIDE = 0xFF0D0E10, BORDER = 0xFF26282E, ROW_HOVER = 0xFF181A1E, EXPAND_BG = 0xFF0E0F12;
    private static final int TEXT = 0xFFE4E5E8, DIM = 0xFF868993, FAINT = 0xFF4B4E57, ACC = 0xFFD9A441, ACC_DIM = 0xFF3A2F18;

    private static final int W = 620, H = 390, TOP = 36, FOOT = 24, TAB_W = 124, TAB_H = 28, ROW_H = 28, SET_H = 24, CHIP_H = 16, CHIP_GAP = 4;

    private final Anim open = new Anim();
    private final Anim scrollAnim = new Anim();
    private final Anim tabBar = new Anim();
    private final Anim[] tabHover = new Anim[Category.values().length];

    private boolean closing;
    private Category selected = Category.COMBAT;
    private long switchTime = System.nanoTime();
    private float scrollTarget;
    private int maxScroll;
    private boolean prevL, prevR;
    private Setting.Num dragging;
    private int dragX, dragW;
    private Module binding;
    private Setting.Mode hoverMode;
    private final boolean[] prevKeys = new boolean[GLFW.GLFW_KEY_LAST + 1];

    private boolean searching;
    private final StringBuilder query = new StringBuilder();
    private String hint = "";

    public boolean isBinding() {
        return binding != null || searching;
    }

    public ClickGuiScreen() {
        super(Text.literal("Noon"));
        for (int i = 0; i < tabHover.length; i++) tabHover[i] = new Anim();
        tabBar.v = selected.ordinal() * TAB_H;
        Sounds.slide(true);
    }

    public void requestClose() {
        if (!closing) {
            closing = true;
            Sounds.slide(false);
        }
    }

    @Override
    public void close() {
        if (binding != null) {
            binding = null;
            return;
        }
        if (searching) {
            searching = false;
            return;
        }
        requestClose();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // vanilla mouse wheel (no @Override on purpose: arrow keys also scroll if the signature ever changes)
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (hoverMode != null) {
            if (verticalAmount > 0) hoverMode.prev();
            else hoverMode.next();
            Sounds.click();
            return true;
        }
        scrollTarget -= (float) verticalAmount * 34f;
        return true;
    }

    // ---- small drawing helpers ----------------------------------------------------------------

    private static void frame(DrawContext c, int x, int y, int w, int h, int fill, int border) {
        c.fill(x, y, x + w, y + h, border);
        c.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
    }

    private static void check(DrawContext c, int x, int y, int s, float t, float a) {
        frame(c, x, y, s, s, Gfx.alpha(Gfx.lerp(0xFF16181C, ACC_DIM, t), a), Gfx.alpha(Gfx.lerp(0xFF3A3D45, ACC, t), a));
        if (t > 0.02f) {
            int p = Math.max(2, Math.round((s - 4) * t));
            int o = (s - p) / 2;
            c.fill(x + o, y + o, x + o + p, y + o + p, Gfx.alpha(ACC, a));
        }
    }

    private static String fmt(Setting.Num n) {
        if (n.step >= 1) return Integer.toString(n.i());
        return String.format(Locale.ROOT, "%.2f", n.get());
    }

    private static boolean chips(Setting s) {
        return s instanceof Setting.Mode md && md.modes.length > 3;
    }

    private static int chipRows(Setting.Mode md, int availW) {
        int rows = 1, x = 0;
        for (String n : md.modes) {
            int w = Gfx.width(n) + 14;
            if (x > 0 && x + w > availW) {
                rows++;
                x = 0;
            }
            x += w + CHIP_GAP;
        }
        return rows;
    }

    private static int rowHeight(Setting s, int cw) {
        if (chips(s)) return 20 + chipRows((Setting.Mode) s, cw - 56) * (CHIP_H + CHIP_GAP) + 2;
        return SET_H;
    }

    private static int settingsHeight(Module m, int cw) {
        int h = SET_H + 8;
        for (Setting s : m.settings) h += rowHeight(s, cw);
        return h;
    }

    private List<Module> visible() {
        if (query.length() == 0) return ModuleManager.byCategory(selected);
        String q = query.toString().toLowerCase(Locale.ROOT);
        List<Module> out = new ArrayList<>();
        for (Module m : ModuleManager.all()) {
            if (m.name.toLowerCase(Locale.ROOT).contains(q) || Info.of(m.name).toLowerCase(Locale.ROOT).contains(q)) out.add(m);
        }
        return out;
    }

    private void typeKeys(long handle) {
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            boolean d = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
            boolean edge = d && !prevKeys[k];
            prevKeys[k] = d;
            if (!edge) continue;
            if (k == GLFW.GLFW_KEY_BACKSPACE) {
                if (query.length() > 0) query.setLength(query.length() - 1);
            } else if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE) {
                searching = false;
            } else if ((k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z) && query.length() < 24) {
                query.append((char) ('a' + (k - GLFW.GLFW_KEY_A)));
                scrollTarget = 0;
            } else if ((k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9) && query.length() < 24) {
                query.append((char) ('0' + (k - GLFW.GLFW_KEY_0)));
            } else if (k == GLFW.GLFW_KEY_SPACE && query.length() < 24) {
                query.append(' ');
            }
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        float openRaw = open.to(closing ? 0f : 1f, closing ? 16f : 14f);
        float o = Anim.clamp01(openRaw);
        if (closing && openRaw <= 0.03f) {
            ModuleManager.save();
            this.client.setScreen(null);
            return;
        }
        boolean ready = !closing && openRaw > 0.8f;

        // ---- input (polled) ----
        long handle = this.client.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean clickL = l && !prevL && ready, clickR = r && !prevR && ready;
        prevL = l;
        prevR = r;
        if (!l || !ready) dragging = null;
        if (!searching) {
            if (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_DOWN) == GLFW.GLFW_PRESS) scrollTarget += 7f;
            if (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_UP) == GLFW.GLFW_PRESS) scrollTarget -= 7f;
        }

        if (binding != null) {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                boolean d = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
                if (d && !prevKeys[k] && k != GLFW.GLFW_KEY_ESCAPE) {
                    binding.key = (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) ? -1 : k;
                    binding = null;
                    Sounds.click();
                }
                prevKeys[k] = d;
                if (binding == null) break;
            }
        } else if (searching) {
            typeKeys(handle);
        } else {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) prevKeys[k] = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
        }

        // ---- window ----
        int ww = Math.min(W, this.width - 16);
        int hh = Math.min(H, this.height - 16);
        int x = (this.width - ww) / 2;
        int y = (this.height - hh) / 2 + Math.round((1f - o) * 10f);

        ctx.fill(0, 0, this.width, this.height, Gfx.alpha(0x99000000, o));
        frame(ctx, x - 1, y - 1, ww + 2, hh + 2, Gfx.alpha(BG, o), Gfx.alpha(BORDER, o));
        ctx.fill(x, y, x + TAB_W, y + hh, Gfx.alpha(SIDE, o));
        ctx.fill(x + TAB_W, y, x + TAB_W + 1, y + hh, Gfx.alpha(BORDER, o));
        ctx.fill(x + TAB_W + 1, y + TOP, x + ww, y + TOP + 1, Gfx.alpha(BORDER, o));
        ctx.fill(x, y + hh - FOOT, x + ww, y + hh - FOOT + 1, Gfx.alpha(BORDER, o));

        // ---- header ----
        Gfx.text(ctx, "NOON", x + 16, y + 14, Gfx.alpha(TEXT, o));
        ctx.fill(x + 16, y + 25, x + 16 + Gfx.width("NOON"), y + 26, Gfx.alpha(ACC, o));
        Gfx.text(ctx, "v1.1", x + 16 + Gfx.width("NOON") + 6, y + 14, Gfx.alpha(FAINT, o));

        int sbW = 168, sbH = 20, sbX = x + ww - sbW - 12, sbY = y + (TOP - sbH) / 2;
        boolean sbHov = ready && mx >= sbX && mx < sbX + sbW && my >= sbY && my < sbY + sbH;
        frame(ctx, sbX, sbY, sbW, sbH, Gfx.alpha(0xFF0D0E10, o), Gfx.alpha(searching ? ACC : (sbHov ? 0xFF3A3D45 : BORDER), o));
        String shown = query.length() == 0 && !searching ? "Search modules" : query.toString() + (searching && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        Gfx.text(ctx, shown, sbX + 8, sbY + 6, Gfx.alpha(query.length() == 0 && !searching ? FAINT : TEXT, o));
        if (clickL && sbHov) {
            searching = true;
            binding = null;
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) prevKeys[k] = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
        } else if (clickL && searching && !sbHov) {
            searching = false;
        }

        // ---- tabs ----
        Category[] cats = Category.values();
        int tabTop = y + TOP + 8;
        int on = 0;
        float bar = tabBar.to(selected.ordinal() * TAB_H, 18f);
        if (query.length() == 0) ctx.fill(x, tabTop + Math.round(bar), x + 2, tabTop + Math.round(bar) + TAB_H, Gfx.alpha(ACC, o));
        for (int i = 0; i < cats.length; i++) {
            Category c = cats[i];
            int ry = tabTop + i * TAB_H;
            boolean hov = ready && mx >= x && mx < x + TAB_W && my >= ry && my < ry + TAB_H;
            float hv = tabHover[i].to(hov ? 1f : 0f, 16f);
            boolean sel = selected == c && query.length() == 0;
            if (sel) ctx.fill(x + 2, ry, x + TAB_W, ry + TAB_H, Gfx.alpha(0xFF15171B, o));
            else if (hv > 0.01f) ctx.fill(x + 2, ry, x + TAB_W, ry + TAB_H, Gfx.alpha(0xFF121316, o * hv));
            int col = sel ? TEXT : Gfx.lerp(DIM, TEXT, hv);
            Gfx.text(ctx, c.label, x + 16, ry + (TAB_H - 8) / 2, Gfx.alpha(col, o));
            int cnt = 0;
            for (Module m : ModuleManager.byCategory(c)) if (m.enabled) cnt++;
            on += cnt;
            if (cnt > 0) {
                String cs = Integer.toString(cnt);
                Gfx.text(ctx, cs, x + TAB_W - 12 - Gfx.width(cs), ry + (TAB_H - 8) / 2, Gfx.alpha(ACC, o * 0.9f));
            }
            if (clickL && hov && (selected != c || query.length() > 0)) {
                selected = c;
                query.setLength(0);
                searching = false;
                scrollTarget = 0;
                scrollAnim.set(0);
                switchTime = System.nanoTime();
                Sounds.click();
            }
        }
        Gfx.text(ctx, on + " modules enabled", x + 16, y + hh - FOOT - 18, Gfx.alpha(FAINT, o));

        // ---- content ----
        int cx = x + TAB_W + 1, cw = ww - TAB_W - 1;
        int viewTop = y + TOP + 1, viewBottom = y + hh - FOOT, viewH = viewBottom - viewTop;
        List<Module> mods = visible();

        scrollTarget = Math.max(0f, Math.min(scrollTarget, maxScroll));
        float scroll = scrollAnim.to(scrollTarget, 20f);
        boolean mouseInView = my >= viewTop && my < viewBottom && mx >= cx && mx < cx + cw;
        float sinceSwitch = (System.nanoTime() - switchTime) / 1_000_000_000f;

        ctx.enableScissor(cx, viewTop, cx + cw, viewBottom);
        hoverMode = null;
        hint = "";
        int yy = viewTop - Math.round(scroll);
        int startY = yy;
        int sbarW = 6;
        int rw = cw - sbarW;

        if (mods.isEmpty()) {
            Gfx.text(ctx, "No modules match \"" + query + "\"", cx + 16, viewTop + 16, Gfx.alpha(DIM, o));
        }

        for (int mi = 0; mi < mods.size(); mi++) {
            Module m = mods.get(mi);
            float ex = Math.max(0f, m.expand.to(m.expanded ? 1f : 0f, 16f));
            int setH = settingsHeight(m, rw);
            int cardH = ROW_H + Math.round(setH * ex);
            float ap = Anim.easeOutCubic(sinceSwitch * 5f - mi * 0.04f);
            float co = o * ap;

            if (yy > viewBottom || yy + cardH < viewTop) {
                yy += cardH;
                continue;
            }

            boolean hov = mouseInView && my >= yy && my < yy + ROW_H;
            float hv = m.hover.to(hov ? 1f : 0f, 18f);
            float tg = m.toggle.to(m.enabled ? 1f : 0f, 18f);
            if (hov) hint = Info.of(m.name);

            if (hv > 0.01f) ctx.fill(cx, yy, cx + rw, yy + ROW_H, Gfx.alpha(ROW_HOVER, co * hv));
            if (tg > 0.01f) ctx.fill(cx, yy + 4, cx + 2, yy + ROW_H - 4, Gfx.alpha(ACC, co * tg));
            int ty = yy + (ROW_H - 8) / 2;
            Gfx.text(ctx, m.name, cx + 16, ty, Gfx.alpha(Gfx.lerp(0xFFB6B8BF, TEXT, Math.max(tg, hv)), co));
            if (m.key >= 0) Gfx.text(ctx, Keys.name(m.key), cx + 16 + Gfx.width(m.name) + 8, ty, Gfx.alpha(FAINT, co));

            int cb = 12, cbX = cx + rw - cb - 14, cbY = yy + (ROW_H - cb) / 2;
            check(ctx, cbX, cbY, cb, tg, co);
            if (!m.settings.isEmpty()) {
                Gfx.text(ctx, m.expanded ? "-" : "+", cbX - 18, ty, Gfx.alpha(Gfx.lerp(FAINT, TEXT, hv), co));
            }

            if (hov && clickL) {
                if (mx >= cbX - 26 && mx < cbX - 6 && !m.settings.isEmpty()) m.expanded = !m.expanded;
                else m.toggle();
                Sounds.click();
            } else if (hov && clickR) {
                m.expanded = !m.expanded;
                Sounds.click();
            }

            if (ex > 0.02f) {
                int top = yy + ROW_H;
                ctx.fill(cx, top, cx + rw, yy + cardH, Gfx.alpha(EXPAND_BG, co));
                ctx.fill(cx + 16, top + 2, cx + 17, yy + cardH - 4, Gfx.alpha(BORDER, co));
                int sy = top + 4;
                boolean interactive = ex > 0.9f && mouseInView;
                float sa = co * Math.min(1f, ex * 1.4f);
                int lx = cx + 28, rx = cx + rw - 14;

                if (sy + SET_H <= yy + cardH) {
                    boolean kHov = interactive && my >= sy && my < sy + SET_H;
                    Gfx.text(ctx, "Keybind", lx, sy + (SET_H - 8) / 2, Gfx.alpha(DIM, sa));
                    String kn = binding == m ? "press a key" : Keys.name(m.key);
                    int kw = Gfx.width(kn) + 14;
                    int kx = rx - kw;
                    frame(ctx, kx, sy + 3, kw, SET_H - 6, Gfx.alpha(0xFF14151A, sa), Gfx.alpha(binding == m ? ACC : BORDER, sa));
                    Gfx.text(ctx, kn, kx + 7, sy + (SET_H - 8) / 2, Gfx.alpha(binding == m ? ACC : TEXT, sa));
                    if (kHov && clickL && mx >= kx - 4) {
                        binding = binding == m ? null : m;
                        searching = false;
                        if (binding != null) {
                            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) prevKeys[k] = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
                        }
                        Sounds.click();
                    }
                    sy += SET_H;
                }

                for (Setting s : m.settings) {
                    int rh = rowHeight(s, rw);
                    if (sy + rh > yy + cardH) break;
                    boolean rowHov = interactive && my >= sy && my < sy + rh;
                    Gfx.text(ctx, s.name, lx, sy + (SET_H - 8) / 2, Gfx.alpha(rowHov ? TEXT : DIM, sa));

                    if (s instanceof Setting.Bool b) {
                        int bs = 12;
                        check(ctx, rx - bs, sy + (SET_H - bs) / 2, bs, b.anim.to(b.value ? 1f : 0f, 18f), sa);
                        if (rowHov && clickL) {
                            b.value = !b.value;
                            Sounds.click();
                        }
                    } else if (s instanceof Setting.Num n) {
                        String val = fmt(n);
                        int vw = Math.max(34, Gfx.width(val));
                        int tw = Math.min(150, rw / 3);
                        int tx = rx - vw - 10 - tw;
                        int ty2 = sy + SET_H / 2;
                        double range = n.max - n.min;
                        double frac = range > 0 ? (n.get() - n.min) / range : 0.0;
                        float fa = n.anim.to((float) frac, 24f);
                        int fillW = Math.round(tw * fa);
                        ctx.fill(tx, ty2 - 1, tx + tw, ty2 + 1, Gfx.alpha(0xFF2A2C33, sa));
                        ctx.fill(tx, ty2 - 1, tx + fillW, ty2 + 1, Gfx.alpha(ACC, sa));
                        boolean active = dragging == n;
                        ctx.fill(tx + fillW - 2, ty2 - (active ? 6 : 5), tx + fillW + 2, ty2 + (active ? 6 : 5), Gfx.alpha(TEXT, sa));
                        Gfx.text(ctx, val, rx - Gfx.width(val), sy + (SET_H - 8) / 2, Gfx.alpha(TEXT, sa));
                        if (interactive && clickL && mx >= tx - 6 && mx < tx + tw + 6 && my >= sy && my < sy + SET_H) {
                            dragging = n;
                            dragX = tx;
                            dragW = tw;
                        }
                    } else if (s instanceof Setting.Mode md && chips(md)) {
                        int chx = lx, chy = sy + 20, availW = rw - 56;
                        for (int ci = 0; ci < md.modes.length; ci++) {
                            int chw = Gfx.width(md.modes[ci]) + 14;
                            if (chx > lx && chx + chw > lx + availW) {
                                chx = lx;
                                chy += CHIP_H + CHIP_GAP;
                            }
                            boolean sel = md.index == ci;
                            boolean chipHov = interactive && mx >= chx && mx < chx + chw && my >= chy && my < chy + CHIP_H;
                            frame(ctx, chx, chy, chw, CHIP_H, Gfx.alpha(sel ? ACC_DIM : (chipHov ? 0xFF1C1E23 : 0xFF14151A), sa),
                                    Gfx.alpha(sel ? ACC : BORDER, sa));
                            Gfx.text(ctx, md.modes[ci], chx + 7, chy + 4, Gfx.alpha(sel ? ACC : (chipHov ? TEXT : DIM), sa));
                            if (chipHov && clickL && !sel) {
                                md.index = ci;
                                Sounds.click();
                            }
                            chx += chw + CHIP_GAP;
                        }
                    } else if (s instanceof Setting.Mode md) {
                        String val = md.get();
                        int pw = Gfx.width(val) + 30;
                        int px = rx - pw;
                        frame(ctx, px, sy + 3, pw, SET_H - 6, Gfx.alpha(rowHov ? 0xFF1C1E23 : 0xFF14151A, sa), Gfx.alpha(BORDER, sa));
                        Gfx.text(ctx, "<", px + 6, sy + (SET_H - 8) / 2, Gfx.alpha(FAINT, sa));
                        Gfx.text(ctx, ">", px + pw - 6 - Gfx.width(">"), sy + (SET_H - 8) / 2, Gfx.alpha(FAINT, sa));
                        Gfx.text(ctx, val, px + (pw - Gfx.width(val)) / 2, sy + (SET_H - 8) / 2, Gfx.alpha(TEXT, sa));
                        if (rowHov) hoverMode = md;
                        if (rowHov && clickL) {
                            md.next();
                            Sounds.click();
                        } else if (rowHov && clickR) {
                            md.prev();
                            Sounds.click();
                        }
                    }
                    sy += rh;
                }
            }
            ctx.fill(cx, yy + cardH - 1, cx + rw, yy + cardH, Gfx.alpha(0xFF17181C, co));
            yy += cardH;
        }
        ctx.disableScissor();

        maxScroll = Math.max(0, (yy - startY) - viewH);

        // scrollbar
        if (maxScroll > 0) {
            int trackH = viewH - 8;
            int thumbH = Math.max(18, Math.round(trackH * (viewH / (float) (viewH + maxScroll))));
            int thumbY = viewTop + 4 + Math.round((trackH - thumbH) * (scroll / maxScroll));
            ctx.fill(cx + cw - 4, thumbY, cx + cw - 2, thumbY + thumbH, Gfx.alpha(0xFF3A3D45, o));
        }

        // ---- footer ----
        String fl = !hint.isEmpty() ? hint : (binding != null ? "Press a key to bind, Backspace clears, Esc cancels." : "");
        Gfx.text(ctx, fl, x + 16, y + hh - FOOT + 8, Gfx.alpha(DIM, o));
        String fr = "RShift close   |   Right-click expand";
        Gfx.text(ctx, fr, x + ww - 14 - Gfx.width(fr), y + hh - FOOT + 8, Gfx.alpha(FAINT, o));

        if (dragging != null && l) {
            double f = (mx - dragX) / (double) dragW;
            f = Math.max(0.0, Math.min(1.0, f));
            dragging.set(dragging.min + f * (dragging.max - dragging.min));
        }
    }
}
