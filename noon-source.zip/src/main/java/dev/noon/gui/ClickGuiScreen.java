package dev.noon.gui;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.ModuleManager;
import dev.noon.module.Setting;
import dev.noon.util.Anim;
import dev.noon.util.Gfx;
import dev.noon.util.Keys;
import dev.noon.util.Sounds;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Noon ClickGUI - iOS-style frosted glass settings window.
 * Input is polled straight from GLFW so it does not depend on Screen input signatures.
 * Left click: toggle / change. Right click (or the arrow): expand settings.
 */
public class ClickGuiScreen extends Screen {
    private static final int W = 440, H = 290;
    private static final int MOD_H = 30, SET_H = 22;

    private final Anim open = new Anim();
    private final Anim scrollAnim = new Anim();
    private final Map<Category, Anim> catAnim = new EnumMap<>(Category.class);

    private boolean closing;
    private Category selected = Category.COMBAT;
    private float scrollTarget;
    private int maxScroll;
    private boolean prevL, prevR;
    private Setting.Num dragging;
    private int dragX, dragW;
    private Module binding;
    private final boolean[] prevKeys = new boolean[GLFW.GLFW_KEY_LAST + 1];

    public boolean isBinding() {
        return binding != null;
    }

    public ClickGuiScreen() {
        super(Text.literal("Noon"));
        for (Category c : Category.values()) catAnim.put(c, new Anim());
        Sounds.slide(true);
    }

    public void requestClose() {
        if (!closing) {
            closing = true;
            Sounds.slide(false);
        }
    }

    @Override
    public void close() {
        if (binding != null) {
            binding = null; // Esc cancels binding
            return;
        }
        requestClose();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // vanilla mouse wheel (no @Override on purpose: arrow keys also scroll if the signature ever changes)
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollTarget -= (float) verticalAmount * 28f;
        return true;
    }

    private static void drawSwitch(DrawContext ctx, int x, int y, int w, int h, float t, float o) {
        int track = Gfx.lerp(0x5978788A, Gfx.GREEN, t);
        Gfx.rrect(ctx, x, y, w, h, h / 2, Gfx.alpha(track, o));
        int k = h - 4;
        int kx = x + 2 + Math.round((w - k - 4) * t);
        Gfx.rrect(ctx, kx, y + 2, k, k, k / 2, Gfx.alpha(0xFFFFFFFF, o));
    }

    private static String fmt(Setting.Num n) {
        if (n.step >= 1) return Integer.toString(n.i());
        return String.format(Locale.ROOT, "%.2f", n.get());
    }

    private static int settingsHeight(Module m) {
        return (m.settings.size() + 1) * SET_H + 8;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta); // vanilla background blur + dim

        float o = open.to(closing ? 0f : 1f, 9f);
        if (closing && o <= 0.02f) {
            ModuleManager.save();
            this.client.setScreen(null);
            return;
        }

        // ---- input (polled) ----
        long handle = this.client.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean clickL = l && !prevL, clickR = r && !prevR;
        prevL = l;
        prevR = r;
        if (!l) dragging = null;
        if (closing) {
            clickL = false;
            clickR = false;
            dragging = null;
        }
        if (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_DOWN) == GLFW.GLFW_PRESS) scrollTarget += 6f;
        if (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_UP) == GLFW.GLFW_PRESS) scrollTarget -= 6f;

        if (binding != null) {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                boolean d = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
                if (d && !prevKeys[k] && k != GLFW.GLFW_KEY_ESCAPE) {
                    binding.key = (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) ? -1 : k;
                    binding = null;
                    Sounds.click();
                }
                prevKeys[k] = d;
                if (binding == null) break;
            }
        }

        // ---- window ----
        int ww = Math.min(W, this.width - 16);
        int hh = Math.min(H, this.height - 16);
        int x = (this.width - ww) / 2;
        int y = (this.height - hh) / 2 + Math.round((1f - o) * 80f); // slide

        ctx.fill(0, 0, this.width, this.height, Gfx.alpha(0x55000000, o * 0.6f));
        Gfx.glass(ctx, x, y, ww, hh, 18, o);

        // ---- sidebar ----
        Gfx.text(ctx, "Noon", x + 20, y + 18, Gfx.alpha(Gfx.WHITE, o));
        Gfx.text(ctx, "utility client", x + 20, y + 30, Gfx.alpha(Gfx.GREY, o));
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            Category c = cats[i];
            int rx = x + 12, ry = y + 56 + i * 26, rw = 98, rh = 22;
            boolean hov = mx >= rx && mx < rx + rw && my >= ry && my < ry + rh;
            float a = catAnim.get(c).to(selected == c ? 1f : 0f, 14f);
            if (hov && a < 0.5f) Gfx.rrect(ctx, rx, ry, rw, rh, 8, Gfx.alpha(0x1AFFFFFF, o));
            Gfx.rrect(ctx, rx, ry, rw, rh, 8, Gfx.alpha(0x730A84FF, a * o));
            Gfx.text(ctx, c.label, rx + 12, ry + 7, Gfx.alpha(Gfx.lerp(0xFFD1D1D6, Gfx.WHITE, a), o));
            if (clickL && hov && selected != c) {
                selected = c;
                scrollTarget = 0;
                scrollAnim.v = 0;
                Sounds.click();
            }
        }
        Gfx.text(ctx, "RShift to close", x + 20, y + hh - 20, Gfx.alpha(0xFF8E8E93, o));

        // ---- content ----
        int cx = x + 124, cy = y + 14, cw = ww - 124 - 14, ch = hh - 28;
        Gfx.text(ctx, selected.label, cx + 4, cy + 4, Gfx.alpha(Gfx.WHITE, o));
        int viewTop = cy + 22, viewBottom = cy + ch, viewH = viewBottom - viewTop;

        scrollTarget = Math.max(0f, Math.min(scrollTarget, maxScroll));
        float scroll = scrollAnim.to(scrollTarget, 16f);
        boolean mouseInView = my >= viewTop && my < viewBottom;

        ctx.enableScissor(cx - 2, viewTop, cx + cw + 2, viewBottom);
        int yy = viewTop - Math.round(scroll);
        int startY = yy;

        for (Module m : ModuleManager.byCategory(selected)) {
            float ex = m.expand.to(m.expanded ? 1f : 0f, 12f);
            int setH = settingsHeight(m);
            int cardH = MOD_H + Math.round(setH * ex);

            Gfx.rrect(ctx, cx, yy, cw, cardH, 12, Gfx.alpha(0x26FFFFFF, o));

            boolean hov = mouseInView && mx >= cx && mx < cx + cw && my >= yy && my < yy + MOD_H;
            if (hov) Gfx.rrect(ctx, cx, yy, cw, MOD_H, 12, Gfx.alpha(0x14FFFFFF, o));

            Gfx.text(ctx, m.name, cx + 14, yy + (MOD_H - 8) / 2, Gfx.alpha(Gfx.WHITE, o));

            if (m.key >= 0) {
                Gfx.text(ctx, "[" + Keys.name(m.key) + "]", cx + 14 + Gfx.width(m.name) + 6, yy + (MOD_H - 8) / 2, Gfx.alpha(Gfx.GREY, o));
            }
            int swW = 36, swH = 20, swX = cx + cw - swW - 12, swY = yy + (MOD_H - swH) / 2;
            drawSwitch(ctx, swX, swY, swW, swH, m.toggle.to(m.enabled ? 1f : 0f, 16f), o);

            boolean hasSettings = true;
            if (hasSettings) {
                String chev = m.expanded ? "v" : ">";
                Gfx.text(ctx, chev, swX - 16, yy + (MOD_H - 8) / 2, Gfx.alpha(Gfx.GREY, o));
            }

            if (hov && clickL) {
                if (hasSettings && mx >= swX - 28 && mx < swX - 6) {
                    m.expanded = !m.expanded;
                } else {
                    m.toggle();
                }
                Sounds.click();
            } else if (hov && clickR && hasSettings) {
                m.expanded = !m.expanded;
                Sounds.click();
            }

            if (ex > 0.02f && hasSettings) {
                ctx.enableScissor(cx, yy + MOD_H, cx + cw, yy + cardH);
                int sy = yy + MOD_H + 2;
                boolean interactive = ex > 0.9f && mouseInView;
                {
                    float ka = o * ex;
                    boolean kHov = interactive && mx >= cx && mx < cx + cw && my >= sy && my < sy + SET_H;
                    Gfx.text(ctx, "Keybind", cx + 14, sy + (SET_H - 8) / 2, Gfx.alpha(0xFFD1D1D6, ka));
                    String kn = binding == m ? "press a key..." : Keys.name(m.key);
                    int kw = Gfx.width(kn) + 18;
                    int kx = cx + cw - 12 - kw;
                    Gfx.rrect(ctx, kx, sy + 2, kw, SET_H - 4, (SET_H - 4) / 2, Gfx.alpha(binding == m ? 0xB3FF9F0A : 0x59787880, ka));
                    Gfx.text(ctx, kn, kx + 9, sy + (SET_H - 8) / 2, Gfx.alpha(Gfx.WHITE, ka));
                    if (kHov && clickL && mx >= kx - 4) {
                        binding = binding == m ? null : m;
                        if (binding != null) {
                            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                                prevKeys[k] = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
                            }
                        }
                        Sounds.click();
                    }
                    sy += SET_H;
                }
                for (Setting s : m.settings) {
                    float sa = o * ex;
                    boolean rowHov = interactive && mx >= cx && mx < cx + cw && my >= sy && my < sy + SET_H;
                    Gfx.text(ctx, s.name, cx + 14, sy + (SET_H - 8) / 2, Gfx.alpha(0xFFD1D1D6, sa));

                    if (s instanceof Setting.Bool b) {
                        int bw = 28, bh = 16, bx = cx + cw - bw - 12, by = sy + (SET_H - bh) / 2;
                        drawSwitch(ctx, bx, by, bw, bh, b.anim.to(b.value ? 1f : 0f, 16f), sa);
                        if (rowHov && clickL) {
                            b.value = !b.value;
                            Sounds.click();
                        }
                    } else if (s instanceof Setting.Num n) {
                        String val = fmt(n);
                        int vw = Gfx.width(val);
                        int tw = Math.min(110, cw / 3);
                        int tx = cx + cw - 12 - vw - 8 - tw;
                        int ty = sy + SET_H / 2 - 2;
                        double frac = (n.get() - n.min) / (n.max - n.min);
                        int fillW = (int) Math.round(tw * frac);
                        Gfx.rrect(ctx, tx, ty, tw, 4, 2, Gfx.alpha(0x59787880, sa));
                        Gfx.rrect(ctx, tx, ty, Math.max(4, fillW), 4, 2, Gfx.alpha(Gfx.ACCENT, sa));
                        Gfx.rrect(ctx, tx + fillW - 5, ty - 3, 10, 10, 5, Gfx.alpha(0xFFFFFFFF, sa));
                        Gfx.text(ctx, val, cx + cw - 12 - vw, sy + (SET_H - 8) / 2, Gfx.alpha(Gfx.WHITE, sa));
                        if (interactive && clickL && mx >= tx - 6 && mx < tx + tw + 6 && my >= sy && my < sy + SET_H) {
                            dragging = n;
                            dragX = tx;
                            dragW = tw;
                        }
                    } else if (s instanceof Setting.Mode md) {
                        String val = md.get();
                        int pw = Gfx.width(val) + 18;
                        int px = cx + cw - 12 - pw, py = sy + 2;
                        Gfx.rrect(ctx, px, py, pw, SET_H - 4, (SET_H - 4) / 2, Gfx.alpha(0x730A84FF, sa));
                        Gfx.text(ctx, val, px + 9, sy + (SET_H - 8) / 2, Gfx.alpha(Gfx.WHITE, sa));
                        if (rowHov && clickL && mx >= px - 4) {
                            md.next();
                            Sounds.click();
                        } else if (rowHov && clickR && mx >= px - 4) {
                            md.prev();
                            Sounds.click();
                        }
                    }
                    sy += SET_H;
                }
                ctx.disableScissor();
            }
            yy += cardH + 6;
        }
        ctx.disableScissor();

        maxScroll = Math.max(0, (yy - startY) - viewH);

        if (dragging != null && l) {
            double f = (mx - dragX) / (double) dragW;
            f = Math.max(0.0, Math.min(1.0, f));
            dragging.set(dragging.min + f * (dragging.max - dragging.min));
        }
    }
}
