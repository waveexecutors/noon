package dev.noon.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import dev.noon.module.render.Animations;
import dev.noon.module.render.HandCustomization;
import dev.noon.module.render.HandGlow;
import net.minecraft.item.ItemStack;
import org.joml.Vector3f;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Written against argument TYPES (via @Local / ordinals) instead of the full descriptor, so it keeps matching even if the
 * render-queue parameter type changes between 1.21.x versions.
 */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    /** Custom swing replaces vanilla's: zero the vanilla swingProgress (3rd float arg) while an animation is selected. */
    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, ordinal = 2)
    private float noon$noVanillaSwing(float swing) {
        return swing > 0f && Animations.overridesSwing() ? 0f : swing;
    }

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void noon$handBegin(CallbackInfo ci,
                                @Local(argsOnly = true) AbstractClientPlayerEntity player,
                                @Local(argsOnly = true) Hand hand,
                                @Local(argsOnly = true) MatrixStack matrices,
                                @Local(argsOnly = true) ItemStack item,
                                @Local(argsOnly = true, ordinal = 0) float tickProgress) {
        matrices.push();
        boolean right = player.getMainArm() == Arm.RIGHT;
        HandCustomization.apply(matrices, hand, right);
        Animations.apply(matrices, hand, right, player.getHandSwingProgress(tickProgress));
        if (HandGlow.INSTANCE.enabled) {
            boolean handRight = (hand == Hand.MAIN_HAND) == right;
            Vector3f v = new Vector3f(handRight ? 0.56f : -0.56f, -0.52f, -0.72f);
            matrices.peek().getPositionMatrix().transformPosition(v);
            HandGlow.capture(hand == Hand.MAIN_HAND, v.x, v.y, v.z, !item.isEmpty());
        }
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
    private void noon$handEnd(CallbackInfo ci, @Local(argsOnly = true) MatrixStack matrices) {
        matrices.pop();
    }
}
