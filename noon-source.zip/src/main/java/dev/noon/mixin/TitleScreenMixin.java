package dev.noon.mixin;

import dev.noon.gui.AltScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
    protected TitleScreenMixin(Text title) {
        super(title);
    }

    @Inject(method = "init", at = @At("RETURN"))
    private void noon$altButton(CallbackInfo ci) {
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Alt Manager"),
                b -> this.client.setScreen(new AltScreen((Screen) (Object) this))).dimensions(6, 6, 100, 20).build());
    }
}
