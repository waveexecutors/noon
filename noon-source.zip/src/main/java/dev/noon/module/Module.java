package dev.noon.module;

import dev.noon.util.Anim;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public final String name;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();
    public volatile boolean enabled;
    public boolean showInHud = true;
    public boolean expanded;
    /** GLFW key code that toggles this module, -1 = unbound. */
    public int key = -1;
    public boolean keyDown;

    // animation state used by the ClickGUI and HUD
    public final Anim toggle = new Anim();
    public final Anim expand = new Anim();
    public final Anim hud = new Anim();
    public final Anim hover = new Anim();
    public final Anim appear = new Anim();

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }

    protected <T extends Setting> T add(T s) {
        settings.add(s);
        return s;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean e) {
        if (e == enabled) return;
        enabled = e;
        if (e) onEnable();
        else onDisable();
    }

    public void onEnable() {}

    public void onDisable() {}

    public void onTick() {}

    /** Small grey text shown next to the name in the HUD list. */
    public String suffix() {
        return "";
    }
}
