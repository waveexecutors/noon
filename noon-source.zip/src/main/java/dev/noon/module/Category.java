package dev.noon.module;

public enum Category {
    COMBAT("Combat"),
    PLAYER("Player"),
    RENDER("Render"),
    CLIENT("Client");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
