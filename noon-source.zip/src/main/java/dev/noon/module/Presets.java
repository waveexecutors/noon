package dev.noon.module;

/**
 * Conservative "legit" presets. NOTE: nothing is truly undetectable - anti-cheats and staff can still spot cheating -
 * these just keep values low / human-like and avoid obviously blatant modules.
 */
public final class Presets {
    private Presets() {}

    public static final String[] NAMES = {"Legit PvP", "Legit SMP", "Visuals Only", "Disable All"};

    private static Module find(String name) {
        for (Module m : ModuleManager.all()) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    private static void on(String mod, String... kv) {
        Module m = find(mod);
        if (m == null) return;
        for (String e : kv) {
            int i = e.indexOf('=');
            if (i < 0) continue;
            String key = e.substring(0, i), val = e.substring(i + 1);
            for (Setting s : m.settings) {
                if (!s.name.equalsIgnoreCase(key)) continue;
                if (s instanceof Setting.Mode md) {
                    for (int k = 0; k < md.modes.length; k++) if (md.modes[k].equalsIgnoreCase(val)) md.index = k;
                } else {
                    s.de(val);
                    if (s instanceof Setting.Num n) n.syncAnim();
                    if (s instanceof Setting.Bool b) b.anim.v = b.value ? 1f : 0f;
                }
            }
        }
        m.setEnabled(true);
    }

    public static void disableAll() {
        for (Module m : ModuleManager.all()) {
            if (m.category == Category.CLIENT || m.category == Category.CONFIG) continue;
            m.setEnabled(false);
        }
    }

    public static void apply(String name) {
        disableAll();
        switch (name) {
            case "Legit PvP" -> {
                on("AutoSprint");
                on("Criticals", "Mode=Legit");
                on("WTap", "Pause (ticks)=2");
                on("AimAssist", "Range=3.2", "FOV=45", "Speed=3.5", "Vertical=false", "Only While Clicking=true");
                on("AutoClicker", "Min CPS=7", "Max CPS=10", "Respect Cooldown=true");
                on("NoHurtCam");
            }
            case "Legit SMP" -> {
                on("AutoSprint");
                on("AutoEat", "Eat Below (hunger)=12");
                on("AutoTool");
                on("PlayerAlert");
                on("AutoRespawn");
                on("NoHurtCam");
            }
            case "Visuals Only" -> {
                on("Player ESP", "Style=CS2 Corners");
                on("Storage ESP");
                on("Fullbright");
                on("NoHurtCam");
            }
            default -> {
            }
        }
    }
}
