package dev.noon.module.smp;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.util.Gfx;
import dev.noon.util.Sounds;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

/**
 * Staff radar. Flags players near you that are hidden from the normal player list (vanished), in spectator mode, invisible,
 * wearing a staff rank prefix or listed in config/noon_staff.txt. Plays a loud siren and shows the name + head on screen.
 *
 * Vanish plugins remove the player from the tab list but some still leave the entity visible to the client for a moment
 * (or to you if you are close / have lag), which is what the "Unlisted" check catches.
 */
public class StaffRadar extends Module {
    public static final StaffRadar INSTANCE = new StaffRadar();

    public final Setting.Bool unlisted = add(new Setting.Bool("Detect Vanished (unlisted)", true));
    public final Setting.Bool spectators = add(new Setting.Bool("Detect Spectators", true));
    public final Setting.Bool invisible = add(new Setting.Bool("Detect Invisible", true));
    public final Setting.Bool rankTags = add(new Setting.Bool("Detect Rank Prefix", true));
    public final Setting.Bool fileList = add(new Setting.Bool("Use config/noon_staff.txt", true));
    public final Setting.Num range = add(new Setting.Num("Range", 8, 160, 96, 4));
    public final Setting.Bool alarm = add(new Setting.Bool("Alarm Sound", true));
    public final Setting.Num volume = add(new Setting.Num("Alarm Loudness", 1, 5, 3, 1));
    public final Setting.Num duration = add(new Setting.Num("Alarm Seconds", 1, 20, 5, 1));
    public final Setting.Bool banner = add(new Setting.Bool("Screen Banner", true));
    public final Setting.Bool flash = add(new Setting.Bool("Red Screen Flash", true));
    public final Setting.Bool chat = add(new Setting.Bool("Chat Message", true));

    private static final String[] RANKS = {"owner", "admin", "mod", "moderator", "helper", "staff", "dev", "developer", "manager", "support", "trial", "sr"};

    private static final class Hit {
        UUID id;
        String name;
        String reason;
        double dist;
        int lastSeen;
        PlayerListEntry head;
    }

    private final Map<UUID, Hit> hits = new LinkedHashMap<>();
    private final Set<UUID> alerted = new HashSet<>();
    private final Map<UUID, PlayerListEntry> heads = new HashMap<>();
    private final Map<UUID, Integer> firstSeen = new HashMap<>();
    private final Set<String> staffNames = new HashSet<>();
    private int tick, alarmTicks, alarmStep;
    private long flashStart;

    private StaffRadar() {
        super("StaffRadar", Category.SMP);
    }

    @Override
    public void onEnable() {
        staffNames.clear();
        Path f = FabricLoader.getInstance().getConfigDir().resolve("noon_staff.txt");
        try {
            if (!Files.exists(f)) Files.writeString(f, "# one staff username per line\n");
            for (String l : Files.readAllLines(f)) {
                l = l.trim().toLowerCase(Locale.ROOT);
                if (!l.isEmpty() && !l.startsWith("#")) staffNames.add(l);
            }
        } catch (IOException ignored) {
        }
    }

    @Override
    public void onDisable() {
        hits.clear();
        alerted.clear();
        firstSeen.clear();
        alarmTicks = 0;
    }

    @Override
    public String suffix() {
        return hits.isEmpty() ? "" : hits.size() + " near";
    }

    private static boolean hasRank(String display, String name) {
        int i = display.toLowerCase(Locale.ROOT).indexOf(name.toLowerCase(Locale.ROOT));
        String prefix = (i > 0 ? display.substring(0, i) : "").toLowerCase(Locale.ROOT);
        if (prefix.isBlank()) return false;
        for (String w : prefix.split("[^a-z]+")) {
            for (String r : RANKS) if (w.equals(r)) return true;
        }
        return false;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity me = mc.player;
        ClientPlayNetworkHandler nh = mc.getNetworkHandler();
        if (me == null || mc.world == null || nh == null) return;
        tick++;

        Set<UUID> present = new HashSet<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == me) continue;
            UUID id = p.getUuid();
            present.add(id);
            firstSeen.putIfAbsent(id, tick);
            PlayerListEntry entry = nh.getPlayerListEntry(id);
            if (entry != null) heads.put(id, entry); // keep the skin even if they vanish from the tab list later
            double dist = me.distanceTo(p);
            if (dist > range.get()) continue;

            String name = p.getName().getString();
            String reason = null;
            if (spectators.get() && (p.isSpectator() || (entry != null && entry.getGameMode() == net.minecraft.world.GameMode.SPECTATOR))) {
                reason = "SPECTATOR";
            } else if (unlisted.get() && entry == null && tick - firstSeen.get(id) > 15 && !nh.getPlayerList().isEmpty()) {
                reason = "VANISHED (not in tab list)";
            } else if (invisible.get() && p.isInvisible()) {
                reason = "INVISIBLE";
            } else if (fileList.get() && staffNames.contains(name.toLowerCase(Locale.ROOT))) {
                reason = "STAFF LIST";
            } else if (rankTags.get() && hasRank(p.getDisplayName().getString(), name)) {
                reason = "STAFF RANK";
            }
            if (reason == null) continue;

            Hit h = hits.computeIfAbsent(id, k -> new Hit());
            h.id = id;
            h.name = name;
            h.reason = reason;
            h.dist = dist;
            h.lastSeen = tick;
            h.head = heads.get(id);
            if (alerted.add(id)) trigger(me, h);
        }
        firstSeen.keySet().retainAll(present);

        // drop hits that are gone for >2s; they can alert again when they come back
        List<UUID> gone = new ArrayList<>();
        for (Hit h : hits.values()) if (tick - h.lastSeen > 40) gone.add(h.id);
        for (UUID id : gone) {
            hits.remove(id);
            alerted.remove(id);
        }

        if (alarmTicks > 0) {
            if (alarmTicks % 4 == 0) Sounds.alarmTone(alarmStep++, volume.i());
            alarmTicks--;
        }
    }

    private void trigger(ClientPlayerEntity me, Hit h) {
        if (alarm.get()) {
            alarmTicks = Math.max(alarmTicks, duration.i() * 20);
            alarmStep = 0;
        }
        flashStart = System.currentTimeMillis();
        if (chat.get()) {
            me.sendMessage(Text.literal("[Noon] STAFF NEAR: " + h.name + " - " + h.reason + " - " + Math.round(h.dist) + "m"), false);
        }
    }

    /** Called from the HUD callback every frame. */
    public void render(DrawContext ctx) {
        if (hits.isEmpty()) return;
        MinecraftClient mc = mc();
        int sw = ctx.getScaledWindowWidth();
        long t = System.currentTimeMillis();
        float pulse = 0.5f + 0.5f * (float) Math.sin(t / 130.0);

        if (flash.get()) {
            float age = (t - flashStart) / 1000f;
            float a = Math.max(0.18f, 1f - age / 2f) * (0.35f + 0.65f * pulse);
            int sh = ctx.getScaledWindowHeight(), e = 46;
            int c = Gfx.alpha(0xFFFF1E1E, a * 0.8f), z = 0x00FF1E1E;
            ctx.fillGradient(0, 0, sw, e, c, z);
            ctx.fillGradient(0, sh - e, sw, sh, z, c);
        }
        if (!banner.get()) return;

        int y = 14;
        for (Hit h : hits.values()) {
            String title = h.name;
            String sub = h.reason + "  -  " + Math.round(h.dist) + "m";
            int w = Math.max(Gfx.width(title) * 3 / 2, Gfx.width(sub)) + 62;
            int x = (sw - w) / 2;
            int bg = Gfx.lerp(0xE6140808, 0xE6300A0A, pulse);
            ctx.fill(x - 1, y - 1, x + w + 1, y + 37, Gfx.alpha(0xFFFF3B30, 0.55f + 0.45f * pulse));
            ctx.fill(x, y, x + w, y + 36, bg);
            if (h.head != null) PlayerSkinDrawer.draw(ctx, h.head.getSkinTextures(), x + 6, y + 6, 24);
            else PlayerSkinDrawer.draw(ctx, DefaultSkinHelper.getSkinTextures(h.id), x + 6, y + 6, 24);
            Gfx.textShadow(ctx, "STAFF NEAR", x + 38, y + 5, 0xFFFF6B60);
            Gfx.textShadow(ctx, title, x + 38, y + 15, 0xFFFFFFFF);
            Gfx.text(ctx, sub, x + 38, y + 26, 0xFFFFB4AE);
            y += 42;
            if (y > 150) break;
        }
    }
}
