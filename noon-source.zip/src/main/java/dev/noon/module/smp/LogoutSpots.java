package dev.noon.module.smp;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.render.Esp;
import dev.noon.util.Gfx;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

/** Remembers where players were standing when they logged out (left the server while in your render distance). */
public class LogoutSpots extends Module {
    public static final LogoutSpots INSTANCE = new LogoutSpots();

    public final Setting.Num minutes = add(new Setting.Num("Keep (minutes)", 1, 60, 10, 1));
    public final Setting.Bool chat = add(new Setting.Bool("Chat Message", true));
    public final Setting.Bool sound = add(new Setting.Bool("Sound", false));

    private static final class Spot {
        String name;
        Vec3d pos;
        long time;
    }

    private final Map<UUID, Object[]> seen = new HashMap<>();
    private final List<Spot> spots = new ArrayList<>();

    private LogoutSpots() {
        super("LogoutSpots", Category.SMP);
    }

    @Override
    public void onDisable() {
        seen.clear();
        spots.clear();
    }

    @Override
    public String suffix() {
        return spots.isEmpty() ? "" : Integer.toString(spots.size());
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity me = mc.player;
        ClientPlayNetworkHandler nh = mc.getNetworkHandler();
        if (me == null || mc.world == null || nh == null) return;
        Set<UUID> now = new HashSet<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == me) continue;
            now.add(p.getUuid());
            seen.put(p.getUuid(), new Object[]{p.getName().getString(), p.getPos()});
        }
        Iterator<Map.Entry<UUID, Object[]>> it = seen.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Object[]> e = it.next();
            if (now.contains(e.getKey())) continue;
            it.remove();
            if (nh.getPlayerListEntry(e.getKey()) != null) continue; // still online, only out of range
            Spot s = new Spot();
            s.name = (String) e.getValue()[0];
            s.pos = (Vec3d) e.getValue()[1];
            s.time = System.currentTimeMillis();
            spots.add(s);
            if (chat.get()) {
                me.sendMessage(Text.literal("[Noon] " + s.name + " logged out at " + Math.round(s.pos.x) + ", " + Math.round(s.pos.y) + ", " + Math.round(s.pos.z)), false);
            }
            if (sound.get()) dev.noon.util.Sounds.ping();
        }
        long maxAge = minutes.i() * 60_000L;
        spots.removeIf(s -> System.currentTimeMillis() - s.time > maxAge);
    }

    public void render(MinecraftClient mc, DrawContext ctx) {
        if (spots.isEmpty() || mc.player == null) return;
        float[] o = new float[2];
        for (Spot s : spots) {
            if (!Esp.project(s.pos.x, s.pos.y + 1.0, s.pos.z, o)) continue;
            int x = Math.round(o[0]), y = Math.round(o[1]);
            long ago = (System.currentTimeMillis() - s.time) / 1000;
            String label = s.name + "  " + Math.round(mc.player.getPos().distanceTo(s.pos)) + "m  " + (ago >= 60 ? ago / 60 + "m" : ago + "s") + " ago";
            int w = Gfx.width(label) + 8;
            ctx.fill(x - w / 2, y - 6, x + w / 2, y + 6, 0xB0101014);
            ctx.fill(x - w / 2, y + 5, x + w / 2, y + 6, 0xFFFFA030);
            Gfx.text(ctx, label, x - w / 2 + 4, y - 4, 0xFFFFFFFF);
        }
    }
}
