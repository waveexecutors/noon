package dev.noon.module.smp;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.util.Sounds;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

/** Warns once per item when armor or your held tool drops below a durability percentage. */
public class DurabilityAlert extends Module {
    public static final DurabilityAlert INSTANCE = new DurabilityAlert();

    public final Setting.Num percent = add(new Setting.Num("Warn Below %", 3, 50, 12, 1));
    public final Setting.Bool armor = add(new Setting.Bool("Armor", true));
    public final Setting.Bool held = add(new Setting.Bool("Held Items", true));

    private final Set<String> warned = new HashSet<>();

    private DurabilityAlert() {
        super("DurabilityAlert", Category.SMP);
    }

    @Override
    public void onDisable() {
        warned.clear();
    }

    private void check(ClientPlayerEntity p, ItemStack s, String slot) {
        if (s.isEmpty() || !s.isDamageable()) {
            warned.remove(slot);
            return;
        }
        float left = 100f * (s.getMaxDamage() - s.getDamage()) / s.getMaxDamage();
        String key = slot + s.getItem();
        if (left <= percent.get()) {
            if (warned.add(key)) {
                p.sendMessage(Text.literal("[Noon] " + s.getName().getString() + " is at " + Math.round(left) + "% durability"), false);
                Sounds.warn();
            }
        } else {
            warned.remove(key);
        }
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (armor.get()) {
            check(p, p.getEquippedStack(EquipmentSlot.HEAD), "head");
            check(p, p.getEquippedStack(EquipmentSlot.CHEST), "chest");
            check(p, p.getEquippedStack(EquipmentSlot.LEGS), "legs");
            check(p, p.getEquippedStack(EquipmentSlot.FEET), "feet");
        }
        if (held.get()) check(p, p.getMainHandStack(), "main");
    }
}
