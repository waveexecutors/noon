package dev.noon.module.smp;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;

/** Respawns instantly and prints where you died. */
public class AutoRespawn extends Module {
    public static final AutoRespawn INSTANCE = new AutoRespawn();

    public final Setting.Bool coords = add(new Setting.Bool("Log Death Coords", true));
    private boolean logged;

    private AutoRespawn() {
        super("AutoRespawn", Category.SMP);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (mc.currentScreen instanceof DeathScreen) {
            if (coords.get() && !logged) {
                logged = true;
                p.sendMessage(Text.literal("[Noon] You died at " + p.getBlockX() + ", " + p.getBlockY() + ", " + p.getBlockZ()), false);
            }
            p.requestRespawn();
        } else {
            logged = false;
        }
    }
}
