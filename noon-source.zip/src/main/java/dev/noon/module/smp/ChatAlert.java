package dev.noon.module.smp;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.util.Sounds;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/** Plays a sound when chat mentions your name, a keyword from config/noon_keywords.txt, or coordinates. */
public class ChatAlert extends Module {
    public static final ChatAlert INSTANCE = new ChatAlert();

    public final Setting.Bool ownName = add(new Setting.Bool("Own Name", true));
    public final Setting.Bool keywords = add(new Setting.Bool("Keywords File", true));
    public final Setting.Bool coords = add(new Setting.Bool("Coordinates", false));
    public final Setting.Bool ignoreOwn = add(new Setting.Bool("Ignore My Messages", true));

    private static final Pattern COORDS = Pattern.compile("-?\\d{2,6}[ ,]+-?\\d{1,3}[ ,]+-?\\d{2,6}");
    private final List<String> words = new ArrayList<>();
    private boolean registered;

    private ChatAlert() {
        super("ChatAlert", Category.SMP);
    }

    /** Hooks the message events once (called from ModuleManager.init). */
    public void register() {
        if (registered) return;
        registered = true;
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) handle(message);
        });
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, ts) -> handle(message));
    }

    @Override
    public void onEnable() {
        words.clear();
        Path f = FabricLoader.getInstance().getConfigDir().resolve("noon_keywords.txt");
        try {
            if (!Files.exists(f)) Files.writeString(f, "# one keyword per line\n");
            for (String l : Files.readAllLines(f)) {
                l = l.trim().toLowerCase(Locale.ROOT);
                if (!l.isEmpty() && !l.startsWith("#")) words.add(l);
            }
        } catch (IOException ignored) {
        }
    }

    private void handle(Text message) {
        if (!enabled) return;
        MinecraftClient mc = mc();
        if (mc.player == null) return;
        String txt = message.getString();
        if (txt.startsWith("[Noon]")) return;
        String low = txt.toLowerCase(Locale.ROOT);
        String me = mc.player.getName().getString().toLowerCase(Locale.ROOT);
        if (ignoreOwn.get() && (low.startsWith("<" + me + ">") || low.startsWith(me + ":"))) return;
        boolean hit = ownName.get() && low.contains(me);
        if (!hit && keywords.get()) for (String w : words) if (low.contains(w)) { hit = true; break; }
        if (!hit && coords.get() && COORDS.matcher(txt).find()) hit = true;
        if (hit) mc.execute(Sounds::ping);
    }
}
