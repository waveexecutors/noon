package dev.noon.module;

import dev.noon.util.Anim;

public abstract class Setting {
    public final String name;
    public final Anim anim = new Anim();

    protected Setting(String name) {
        this.name = name;
    }

    public abstract String ser();

    public abstract void de(String s);

    public static final class Bool extends Setting {
        public boolean value;

        public Bool(String name, boolean value) {
            super(name);
            this.value = value;
            this.anim.v = value ? 1f : 0f;
        }

        public boolean get() {
            return value;
        }

        @Override
        public String ser() {
            return Boolean.toString(value);
        }

        @Override
        public void de(String s) {
            value = Boolean.parseBoolean(s);
            anim.v = value ? 1f : 0f;
        }
    }

    public static final class Num extends Setting {
        public final double min, max, step;
        public double value;

        public Num(String name, double min, double max, double value, double step) {
            super(name);
            this.min = min;
            this.max = max;
            this.step = step;
            this.value = value;
        }

        public double get() {
            return value;
        }

        public float f() {
            return (float) value;
        }

        public int i() {
            return (int) Math.round(value);
        }

        public void set(double v) {
            v = Math.max(min, Math.min(max, v));
            if (step > 0) v = Math.round((v - min) / step) * step + min;
            value = Math.max(min, Math.min(max, v));
        }

        @Override
        public String ser() {
            return Double.toString(value);
        }

        @Override
        public void de(String s) {
            try {
                set(Double.parseDouble(s));
            } catch (NumberFormatException ignored) {
            }
        }
    }

    public static final class Mode extends Setting {
        public final String[] modes;
        public int index;

        public Mode(String name, int index, String... modes) {
            super(name);
            this.modes = (modes != null && modes.length > 0) ? modes : new String[]{"None"};
            this.index = Math.max(0, Math.min(index, this.modes.length - 1));
        }

        public String get() {
            int i = index;
            if (i < 0 || i >= modes.length) {
                i = 0;
            }
            return modes[i];
        }

        public boolean is(String m) {
            return get().equals(m);
        }

        public void next() {
            if (modes.length == 0) {
                return;
            }
            index = (index + 1) % modes.length;
        }

        public void prev() {
            if (modes.length == 0) {
                return;
            }
            index = (index + modes.length - 1) % modes.length;
        }

        @Override
        public String ser() {
            return Integer.toString(index);
        }

        @Override
        public void de(String s) {
            try {
                int i = Integer.parseInt(s);
                if (i >= 0 && i < modes.length) {
                    index = i;
                }
            } catch (NumberFormatException ignored) {
            }
        }
    }
}
