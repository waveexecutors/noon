package dev.noon.module.client;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.util.Anim;

/** Toggle this off to hide the whole Noon HUD. */
public class HudModule extends Module {
    public static final HudModule INSTANCE = new HudModule();

    public final Setting.Bool watermark = add(new Setting.Bool("Watermark", true));
    public final Setting.Bool list = add(new Setting.Bool("Module List", true));
    public final Anim master = new Anim();

    private HudModule() {
        super("HUD", Category.CLIENT);
        showInHud = false;
        enabled = true;
        toggle.v = 1f;
        master.v = 1f;
    }
}
