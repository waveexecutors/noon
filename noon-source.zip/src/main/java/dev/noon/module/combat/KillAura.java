package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class KillAura extends Module {
    public static final KillAura INSTANCE = new KillAura();

    public final Setting.Num range = add(new Setting.Num("Range", 2.0, 6.0, 3.8, 0.1));
    public final Setting.Num cooldown = add(new Setting.Num("Cooldown", 0.5, 1.0, 0.92, 0.01));
    public final Setting.Bool players = add(new Setting.Bool("Players", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Hostile Mobs", true));
    public final Setting.Bool rotate = add(new Setting.Bool("Rotate", true));

    private KillAura() {
        super("KillAura", Category.COMBAT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        if (p.getAttackCooldownProgress(0.5f) < cooldown.f()) return;

        LivingEntity best = null;
        double bestDist = range.get();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || le == p || !le.isAlive() || le.isSpectator()) continue;
            boolean ok = (players.get() && le instanceof PlayerEntity) || (mobs.get() && le instanceof HostileEntity);
            if (!ok) continue;
            double d = p.distanceTo(le);
            if (d <= bestDist) {
                bestDist = d;
                best = le;
            }
        }
        if (best == null) return;

        if (rotate.get()) {
            Vec3d from = p.getEyePos();
            Vec3d to = best.getEyePos();
            double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
            p.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
            p.setPitch((float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
        }
        Criticals.attack(best);
    }
}
