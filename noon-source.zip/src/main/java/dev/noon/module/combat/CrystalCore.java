package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Shared crystal PvP logic: finds the best obsidian/bedrock spot next to the target, places a crystal, breaks it.
 * Legit mode behaves like a human: smooth aim, crosshair must actually be on the thing, randomised delays, no switching.
 */
public abstract class CrystalCore extends Module {
    public final Setting.Num targetRange = add(new Setting.Num("Target Range", 3, 15, 10, 1));
    public final Setting.Num placeRange = add(new Setting.Num("Place Range", 2, 6, 4.5, 0.1));
    public final Setting.Num breakRange = add(new Setting.Num("Break Range", 2, 6, 4.5, 0.1));
    public final Setting.Num minDamage = add(new Setting.Num("Min Damage", 1, 20, 5, 0.5));
    public final Setting.Num maxSelf = add(new Setting.Num("Max Self Damage", 1, 20, 6, 0.5));
    public final Setting.Bool antiSuicide = add(new Setting.Bool("Anti Suicide", true));
    public final Setting.Num placeDelay = add(new Setting.Num("Place Delay (ticks)", 0, 10, 2, 1));
    public final Setting.Num breakDelay = add(new Setting.Num("Break Delay (ticks)", 0, 10, 2, 1));
    public final Setting.Bool place = add(new Setting.Bool("Place", true));
    public final Setting.Bool breakC = add(new Setting.Bool("Break", true));
    public final Setting.Bool rotate = add(new Setting.Bool("Rotate", true));
    public final Setting.Num rotSpeed = add(new Setting.Num("Rotation Speed (deg/tick)", 5, 180, 60, 5));
    public final Setting.Bool legit = add(new Setting.Bool("Legit Mode", false));
    public final Setting.Num jitter = add(new Setting.Num("Legit Delay Jitter %", 0, 200, 60, 5));
    public final Setting.Num missChance = add(new Setting.Num("Legit Miss Chance %", 0, 30, 6, 1));
    public final Setting.Bool onlyHolding = add(new Setting.Bool("Only When Holding Crystal", false));
    public final Setting.Bool swing = add(new Setting.Bool("Swing", true));

    protected final boolean silent;
    private int placeT, breakT;
    private float ry, rp;
    private boolean engaged;

    protected CrystalCore(String name, boolean silent) {
        super(name, Category.COMBAT);
        this.silent = silent;
        if (silent) {
            rotSpeed.set(90);
        }
    }

    @Override
    public void onDisable() {
        engaged = false;
    }

    // ---- helpers ------------------------------------------------------------------------------

    private static double est(Entity e, double cx, double cy, double cz) {
        double dx = e.getX() - cx, dy = e.getY() - cy, dz = e.getZ() - cz;
        double d = Math.sqrt(dx * dx + dy * dy + dz * dz) / 12.0;
        if (d > 1.0) return 0;
        double imp = 1.0 - d;
        return (imp * imp + imp) / 2.0 * 7.0 * 12.0 + 1.0;
    }

    private int delay(int base) {
        if (!legit.get()) return base;
        double j = ThreadLocalRandom.current().nextDouble() * jitter.get() / 100.0;
        return Math.max(1, (int) Math.round(base * (1.0 + j)));
    }

    private boolean aim(ClientPlayerEntity p, Vec3d to) {
        if (!rotate.get()) return true;
        Vec3d eye = p.getEyePos();
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        float ty = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float tp = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        boolean real = legit.get() && !silent; // legit + non-silent moves your real camera like a player would
        if (!engaged) {
            ry = p.getYaw();
            rp = p.getPitch();
            engaged = true;
        }
        float sp = legit.get() ? Math.min(rotSpeed.f(), 45f) : rotSpeed.f();
        float dyaw = MathHelper.wrapDegrees(ty - ry), dp = tp - rp;
        ry += MathHelper.clamp(dyaw, -sp, sp);
        rp = MathHelper.clamp(rp + MathHelper.clamp(dp, -sp, sp), -90f, 90f);
        if (real) {
            p.setYaw(ry);
            p.setPitch(rp);
        } else if (silent) {
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(ry, rp, p.isOnGround(), p.horizontalCollision));
        } else {
            p.setYaw(ry);
            p.setPitch(rp);
        }
        float tol = legit.get() ? 4f : 12f;
        return Math.abs(MathHelper.wrapDegrees(ty - ry)) <= tol && Math.abs(tp - rp) <= tol;
    }

    private int crystalSlot(ClientPlayerEntity p) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(Items.END_CRYSTAL)) return i;
        return -1;
    }

    // ---- main loop ----------------------------------------------------------------------------

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (placeT > 0) placeT--;
        if (breakT > 0) breakT--;

        PlayerEntity target = null;
        double best = targetRange.get();
        for (PlayerEntity t : mc.world.getPlayers()) {
            if (t == p || !t.isAlive() || t.isSpectator()) continue;
            double d = p.distanceTo(t);
            if (d <= best) {
                best = d;
                target = t;
            }
        }
        if (target == null) {
            engaged = false;
            return;
        }

        double selfHp = p.getHealth() + p.getAbsorptionAmount();
        boolean acted = false;

        // ---- break ----
        if (breakC.get() && breakT <= 0) {
            EndCrystalEntity bc = null;
            double bestScore = -1e9;
            Box area = p.getBoundingBox().expand(breakRange.get() + 1);
            for (EndCrystalEntity c : mc.world.getEntitiesByClass(EndCrystalEntity.class, area, e -> true)) {
                if (p.getEyePos().distanceTo(c.getBoundingBox().getCenter()) > breakRange.get()) continue;
                double t = est(target, c.getX(), c.getY(), c.getZ()), s = est(p, c.getX(), c.getY(), c.getZ());
                if (t < 1.5 || s > maxSelf.get() || (antiSuicide.get() && s >= selfHp - 1)) continue;
                if (t - s * 0.5 > bestScore) {
                    bestScore = t - s * 0.5;
                    bc = c;
                }
            }
            if (bc != null) {
                acted = true;
                boolean aligned = aim(p, bc.getBoundingBox().getCenter());
                boolean gate = !legit.get() || silent || (mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() == bc);
                if (aligned && gate) {
                    if (!(legit.get() && ThreadLocalRandom.current().nextInt(100) < missChance.i())) {
                        Criticals.rawAttack(bc);
                        if (!swing.get()) { /* rawAttack always swings; kept simple */ }
                    }
                    breakT = delay(breakDelay.i());
                }
            }
        }

        // ---- place ----
        if (place.get() && placeT <= 0 && !acted) {
            Hand hand = null;
            int slot = -1;
            if (p.getOffHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.OFF_HAND;
            else if (p.getMainHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.MAIN_HAND;
            else if (!legit.get() && !onlyHolding.get()) {
                slot = crystalSlot(p);
                if (slot >= 0) hand = Hand.MAIN_HAND;
            }
            if (hand == null) {
                if (!acted) engaged = false;
                return;
            }

            BlockPos bp = null;
            double bs = -1e9;
            BlockPos o = p.getBlockPos();
            int r = (int) Math.ceil(placeRange.get());
            for (int x = -r; x <= r; x++) {
                for (int y = -r; y <= r; y++) {
                    for (int z = -r; z <= r; z++) {
                        BlockPos b = o.add(x, y, z);
                        if (!(mc.world.getBlockState(b).isOf(Blocks.OBSIDIAN) || mc.world.getBlockState(b).isOf(Blocks.BEDROCK))) continue;
                        if (!mc.world.getBlockState(b.up()).isAir() || !mc.world.getBlockState(b.up(2)).isAir()) continue;
                        double cx = b.getX() + 0.5, cy = b.getY() + 1.0, cz = b.getZ() + 0.5;
                        if (p.getEyePos().distanceTo(new Vec3d(cx, cy, cz)) > placeRange.get()) continue;
                        double t = est(target, cx, cy, cz), s = est(p, cx, cy, cz);
                        if (t < minDamage.get() || s > maxSelf.get() || (antiSuicide.get() && s >= selfHp - 1)) continue;
                        if (!mc.world.getOtherEntities(null, new Box(b.getX(), b.getY() + 1, b.getZ(), b.getX() + 1, b.getY() + 3, b.getZ() + 1)).isEmpty()) continue;
                        if (t - s * 0.5 > bs) {
                            bs = t - s * 0.5;
                            bp = b;
                        }
                    }
                }
            }
            if (bp == null) {
                engaged = false;
                return;
            }
            Vec3d top = new Vec3d(bp.getX() + 0.5, bp.getY() + 1.0, bp.getZ() + 0.5);
            boolean aligned = aim(p, top);
            boolean gate = !legit.get() || silent
                    || (mc.crosshairTarget instanceof BlockHitResult bh && bh.getBlockPos().equals(bp));
            if (aligned && gate) {
                if (legit.get() && ThreadLocalRandom.current().nextInt(100) < missChance.i()) {
                    placeT = delay(placeDelay.i());
                    return;
                }
                int prev = p.getInventory().getSelectedSlot();
                if (slot >= 0) p.getInventory().setSelectedSlot(slot);
                mc.interactionManager.interactBlock(p, hand, new BlockHitResult(top, Direction.UP, bp, false));
                if (swing.get()) p.swingHand(hand);
                if (slot >= 0 && silent) p.getInventory().setSelectedSlot(prev); // silent switch: back the same tick
                placeT = delay(placeDelay.i());
            }
        }
    }
}
