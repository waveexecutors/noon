package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * Hops (mini / full) before the hit lands so it connects while falling.
 * The hit is delayed until the player is actually descending.
 */
public class Criticals extends Module {
    public static final Criticals INSTANCE = new Criticals();

    /** True while Noon itself is sending an attack, so the attack hook ignores it. */
    public static boolean internal;

    private static Entity pending;
    private static int pendingTicks;

    public final Setting.Mode mode = add(new Setting.Mode("Mode", 0, "Mini Jump", "Full Jump", "Legit"));

    private Criticals() {
        super("Criticals", Category.COMBAT);
    }

    @Override
    public String suffix() {
        if (mode.is("Legit")) {
            ClientPlayerEntity p = mc().player;
            return p != null && critReady(p) ? "Legit  CRIT" : "Legit";
        }
        return mode.get();
    }

    /** Vanilla critical conditions: falling, airborne, not sprinting/climbing/swimming/riding/blind. */
    public static boolean critReady(ClientPlayerEntity p) {
        return p.fallDistance > 0f && !p.isOnGround() && !p.isClimbing() && !p.isTouchingWater() && !p.hasVehicle()
                && !p.isSprinting() && !p.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.BLINDNESS);
    }

    @Override
    public void onDisable() {
        pending = null;
    }

    /** Raw attack, bypassing the criticals hook. */
    public static void rawAttack(Entity target) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null) return;
        internal = true;
        try {
            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
        } finally {
            internal = false;
        }
    }

    /** Attack that respects Criticals if it is enabled. */
    public static void attack(Entity target) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (INSTANCE.enabled && INSTANCE.mode.is("Legit") && p != null) {
            // Legit: Noon changes nothing - no delayed/held hits, no velocity or sprint edits, no timing gates.
            // It only shows "CRIT" in the HUD when vanilla would give a critical, so YOU time your own click.
            rawAttack(target);
            return;
        }
        if (!handle(target)) rawAttack(target);
    }

    /** Returns true when the attack was swallowed and queued for later. */
    public static boolean handle(Entity target) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (!INSTANCE.enabled || p == null) return false;
        if (pending != null) return true;
        if (!p.isOnGround() || p.isClimbing() || p.isTouchingWater() || p.hasVehicle()) return false;
        if (INSTANCE.mode.is("Legit")) return false; // legit mode never delays or alters your own clicks

        Vec3d v = p.getVelocity();
        if (INSTANCE.mode.is("Mini Jump")) p.setVelocity(v.x, 0.2, v.z);
        else p.setVelocity(v.x, 0.42, v.z);

        pending = target;
        pendingTicks = 0;
        return true;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (pending == null || p == null) return;
        pendingTicks++;
        if (!pending.isAlive() || pendingTicks > 14 || p.distanceTo(pending) > 6.5f) {
            pending = null;
            return;
        }
        if (!p.isOnGround() && p.getVelocity().y < 0 && p.fallDistance > 0) {
            Entity t = pending;
            pending = null;
            p.setSprinting(false); // sprinting blocks critical hits in vanilla
            rawAttack(t);
        }
    }
}
