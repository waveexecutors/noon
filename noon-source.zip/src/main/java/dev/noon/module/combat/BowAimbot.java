package dev.noon.module.combat;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** While drawing a bow: aims at the closest player in your view with movement lead and gravity drop compensation. */
public class BowAimbot extends Module {
    public static final BowAimbot INSTANCE = new BowAimbot();

    public final Setting.Num range = add(new Setting.Num("Range", 8, 80, 40, 1));
    public final Setting.Num fov = add(new Setting.Num("FOV", 10, 180, 90, 5));
    public final Setting.Num smooth = add(new Setting.Num("Smoothing", 1, 20, 6, 0.5));
    public final Setting.Bool predict = add(new Setting.Bool("Predict Movement", true));

    private final Map<Integer, Vec3d> last = new HashMap<>();

    private BowAimbot() {
        super("BowAimbot", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        last.clear();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        Map<Integer, Vec3d> now = new HashMap<>();
        PlayerEntity best = null;
        float bestDiff = fov.f() / 2f;
        boolean drawing = p.isUsingItem() && p.getActiveItem().isOf(Items.BOW);
        for (PlayerEntity t : mc.world.getPlayers()) {
            now.put(t.getId(), t.getPos());
            if (!drawing || t == p || !t.isAlive() || t.isSpectator() || p.distanceTo(t) > range.get()) continue;
            Vec3d c = t.getBoundingBox().getCenter();
            Vec3d eye = p.getEyePos();
            float yawTo = (float) (Math.toDegrees(Math.atan2(c.z - eye.z, c.x - eye.x)) - 90.0);
            float d = Math.abs(MathHelper.wrapDegrees(yawTo - p.getYaw()));
            if (d < bestDiff) {
                bestDiff = d;
                best = t;
            }
        }
        if (best != null) {
            Vec3d eye = p.getEyePos();
            Vec3d c = best.getBoundingBox().getCenter();
            float pull = Math.min(1f, (float) ((p.getItemUseTime() / 20.0 * p.getItemUseTime() / 20.0 + p.getItemUseTime() / 10.0) / 3.0));
            double speed = Math.max(0.5, pull * 3.0);
            double dist = eye.distanceTo(c);
            double ticks = dist / speed;
            if (predict.get()) {
                Vec3d prev = last.get(best.getId());
                if (prev != null) {
                    Vec3d v = best.getPos().subtract(prev);
                    c = c.add(v.x * ticks, 0, v.z * ticks);
                }
            }
            c = c.add(0, 0.5 * 0.05 * ticks * ticks, 0); // gravity drop
            double dx = c.x - eye.x, dy = c.y - eye.y, dz = c.z - eye.z;
            float yawTo = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            float pitchTo = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
            float k = 1f - (float) Math.exp(-smooth.f() * 0.25f);
            p.setYaw(p.getYaw() + MathHelper.wrapDegrees(yawTo - p.getYaw()) * k);
            p.setPitch(MathHelper.clamp(p.getPitch() + (pitchTo - p.getPitch()) * k, -90f, 90f));
        }
        last.clear();
        last.putAll(now);
    }
}
