package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.util.Gfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Soft glowing aura behind your hand / held item (RGB or custom colour). Drawn as a HUD overlay so it is cheap and
 * follows the swing animation. Position is tunable with Offset X / Y.
 */
public class HandGlow extends Module {
    public static final HandGlow INSTANCE = new HandGlow();

    public final Setting.Mode colorMode = add(new Setting.Mode("Color Mode", 0, "Rainbow", "Custom", "Fade", "Pulse"));
    public final Setting.Num r1 = add(new Setting.Num("Red", 0, 255, 80, 1));
    public final Setting.Num g1 = add(new Setting.Num("Green", 0, 255, 160, 1));
    public final Setting.Num b1 = add(new Setting.Num("Blue", 0, 255, 255, 1));
    public final Setting.Num r2 = add(new Setting.Num("Fade Red", 0, 255, 255, 1));
    public final Setting.Num g2 = add(new Setting.Num("Fade Green", 0, 255, 60, 1));
    public final Setting.Num b2 = add(new Setting.Num("Fade Blue", 0, 255, 180, 1));
    public final Setting.Num speed = add(new Setting.Num("Speed", 0.1, 5.0, 1.0, 0.1));
    public final Setting.Num size = add(new Setting.Num("Size", 20, 200, 90, 5));
    public final Setting.Num intensity = add(new Setting.Num("Intensity", 5, 100, 45, 1));
    public final Setting.Num layers = add(new Setting.Num("Layers", 3, 12, 6, 1));
    public final Setting.Bool mainHand = add(new Setting.Bool("Main Hand", true));
    public final Setting.Bool offHand = add(new Setting.Bool("Off Hand", false));
    public final Setting.Bool needItem = add(new Setting.Bool("Only With Item", false));
    public final Setting.Bool followSwing = add(new Setting.Bool("Follow Swing", true));
    public final Setting.Num offX = add(new Setting.Num("Offset X", -100, 100, 0, 1));
    public final Setting.Num offY = add(new Setting.Num("Offset Y", -100, 100, 0, 1));

    private HandGlow() {
        super("Hand Glow", Category.RENDER);
        showInHud = false;
    }

    private int color(float t) {
        double ph = System.currentTimeMillis() / 1000.0 * speed.get();
        int c1 = 0xFF000000 | (r1.i() << 16) | (g1.i() << 8) | b1.i();
        int c2 = 0xFF000000 | (r2.i() << 16) | (g2.i() << 8) | b2.i();
        switch (colorMode.index) {
            case 0:
                return 0xFF000000 | java.awt.Color.HSBtoRGB((float) ((ph * 0.25 + t * 0.15) % 1.0), 0.7f, 1f);
            case 1:
                return c1;
            case 2:
                return Gfx.lerp(c1, c2, (float) (0.5 + 0.5 * Math.sin(ph * 2.0 + t * 2.0)));
            default:
                return Gfx.lerp(0xFF000000 | ((r1.i() / 3) << 16) | ((g1.i() / 3) << 8) | (b1.i() / 3), c1,
                        (float) (0.5 + 0.5 * Math.sin(ph * 3.0)));
        }
    }

    public void render(MinecraftClient mc, DrawContext ctx, float td) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson()) return;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        float swing = followSwing.get() ? p.getHandSwingProgress(td) : 0f;
        float sv = (float) Math.sin(swing * Math.PI);
        boolean rightMain = p.getMainArm() == net.minecraft.util.Arm.RIGHT;

        if (mainHand.get() && (!needItem.get() || !p.getMainHandStack().isEmpty())) {
            float side = rightMain ? 1f : -1f;
            draw(ctx, sw / 2f + side * sw * 0.2f - side * sv * 26f + offX.f() * side, sh * 0.84f - sv * 22f + offY.f(), 0f);
        }
        if (offHand.get() && (!needItem.get() || !p.getOffHandStack().isEmpty())) {
            float side = rightMain ? -1f : 1f;
            draw(ctx, sw / 2f + side * sw * 0.2f + offX.f() * side, sh * 0.84f + offY.f(), 1f);
        }
    }

    private void draw(DrawContext ctx, float cx, float cy, float phase) {
        int n = layers.i();
        float base = intensity.f() / 100f;
        for (int i = 0; i < n; i++) {
            float t = i / (float) n;
            int w = Math.round(size.f() * (1f - t * 0.85f));
            int h = Math.round(w * 1.25f);
            int col = Gfx.alpha(color(phase + t), (base * 0.5f) / n * (1f + t) * 2.2f);
            Gfx.rrectFast(ctx, Math.round(cx - w / 2f), Math.round(cy - h / 2f), w, h, Math.min(w, h) / 2, col);
        }
    }
}
