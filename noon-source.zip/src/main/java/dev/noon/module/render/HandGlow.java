package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import dev.noon.util.Gfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Soft glowing aura behind your hand / held item (RGB or custom colour). Drawn as a HUD overlay so it is cheap and
 * follows the swing animation. Position is tunable with Offset X / Y.
 */
public class HandGlow extends Module {
    public static final HandGlow INSTANCE = new HandGlow();

    public final Setting.Mode colorMode = add(new Setting.Mode("Color Mode", 0, "Rainbow", "Custom", "Fade", "Pulse"));
    public final Setting.Num r1 = add(new Setting.Num("Red", 0, 255, 80, 1));
    public final Setting.Num g1 = add(new Setting.Num("Green", 0, 255, 160, 1));
    public final Setting.Num b1 = add(new Setting.Num("Blue", 0, 255, 255, 1));
    public final Setting.Num r2 = add(new Setting.Num("Fade Red", 0, 255, 255, 1));
    public final Setting.Num g2 = add(new Setting.Num("Fade Green", 0, 255, 60, 1));
    public final Setting.Num b2 = add(new Setting.Num("Fade Blue", 0, 255, 180, 1));
    public final Setting.Num speed = add(new Setting.Num("Speed", 0.1, 5.0, 1.0, 0.1));
    public final Setting.Num size = add(new Setting.Num("Size", 20, 200, 90, 5));
    public final Setting.Num intensity = add(new Setting.Num("Intensity", 5, 100, 45, 1));
    public final Setting.Num layers = add(new Setting.Num("Layers", 3, 12, 6, 1));
    public final Setting.Bool mainHand = add(new Setting.Bool("Main Hand", true));
    public final Setting.Bool offHand = add(new Setting.Bool("Off Hand", true));
    public final Setting.Bool needItem = add(new Setting.Bool("Only With Item", false));
    public final Setting.Bool followSwing = add(new Setting.Bool("Follow Swing", true));
    public final Setting.Num offX = add(new Setting.Num("Offset X", -100, 100, 0, 1));
    public final Setting.Num offY = add(new Setting.Num("Offset Y", -100, 100, 0, 1));

    private HandGlow() {
        super("Hand Glow", Category.RENDER);
        showInHud = false;
    }

    private int color(float t) {
        double ph = System.currentTimeMillis() / 1000.0 * speed.get();
        int c1 = 0xFF000000 | (r1.i() << 16) | (g1.i() << 8) | b1.i();
        int c2 = 0xFF000000 | (r2.i() << 16) | (g2.i() << 8) | b2.i();
        switch (colorMode.index) {
            case 0:
                return 0xFF000000 | java.awt.Color.HSBtoRGB((float) ((ph * 0.25 + t * 0.15) % 1.0), 0.7f, 1f);
            case 1:
                return c1;
            case 2:
                return Gfx.lerp(c1, c2, (float) (0.5 + 0.5 * Math.sin(ph * 2.0 + t * 2.0)));
            default:
                return Gfx.lerp(0xFF000000 | ((r1.i() / 3) << 16) | ((g1.i() / 3) << 8) | (b1.i() / 3), c1,
                        (float) (0.5 + 0.5 * Math.sin(ph * 3.0)));
        }
    }

    // view-space position of each hand's item pivot, captured by HeldItemRendererMixin every frame
    private static final float[][] CAP = new float[2][4];
    private static final long[] CAP_T = new long[2];

    public static void capture(boolean main, float x, float y, float z, boolean hasItem) {
        int i = main ? 0 : 1;
        CAP[i][0] = x;
        CAP[i][1] = y;
        CAP[i][2] = z;
        CAP[i][3] = hasItem ? 1f : 0f;
        CAP_T[i] = System.nanoTime();
    }

    public void render(MinecraftClient mc, DrawContext ctx, float td) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson()) return;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        double tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        double aspect = (double) sw / sh;
        long now = System.nanoTime();
        for (int i = 0; i < 2; i++) {
            if (i == 0 ? !mainHand.get() : !offHand.get()) continue;
            if (now - CAP_T[i] > 120_000_000L) continue; // hand not rendered this frame
            if (needItem.get() && CAP[i][3] == 0f) continue;
            double d = -CAP[i][2];
            if (d < 0.05) continue;
            float sx = (float) (sw / 2.0 + (CAP[i][0] / d) / (tanHalf * aspect) * (sw / 2.0));
            float sy = (float) (sh / 2.0 - (CAP[i][1] / d) / tanHalf * (sh / 2.0));
            float px = (float) ((0.55 / d) / tanHalf * (sh / 2.0)) * (size.f() / 90f);
            float side = (CAP[i][0] >= 0) ? 1f : -1f;
            draw(ctx, sx + offX.f() * side, sy + offY.f() - px * 0.35f, px, i);
        }
    }

    /** Glowing outline ring (stroke only, fading outward) around the hand / item. */
    private void draw(DrawContext ctx, float cx, float cy, float px, int hand) {
        int n = layers.i();
        float base = intensity.f() / 100f;
        int w0 = Math.max(16, Math.round(px)), h0 = Math.round(w0 * 1.3f);
        for (int i = 0; i < n; i++) {
            float t = i / (float) n;
            int e = i * 2;
            int w = w0 + e * 2, h = h0 + e * 2;
            float fall = (1f - t);
            int col = Gfx.alpha(color(hand * 0.5f + t), base * fall * fall);
            int x = Math.round(cx - w / 2f), y = Math.round(cy - h / 2f);
            Gfx.outline(ctx, x, y, w, h, Math.min(w, h) / 3, col, col);
        }
    }
}
