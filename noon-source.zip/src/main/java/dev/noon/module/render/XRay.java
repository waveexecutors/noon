package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;

/** Only ores, debris, lava, spawners and chests are rendered. See BlockMixin. */
public class XRay extends Module {
    public static final XRay INSTANCE = new XRay();

    private static final Map<Block, Boolean> CACHE = new ConcurrentHashMap<>();

    public final Setting.Bool light = add(new Setting.Bool("Fullbright", true));

    private XRay() {
        super("X-Ray", Category.RENDER);
    }

    public static boolean isVisible(Block block) {
        return CACHE.computeIfAbsent(block, b -> {
            String p = Registries.BLOCK.getId(b).getPath();
            return p.endsWith("_ore") || p.equals("ancient_debris") || p.equals("lava")
                    || p.equals("spawner") || p.equals("trial_spawner") || p.equals("chest")
                    || p.equals("trapped_chest") || p.equals("ender_chest") || p.equals("end_portal_frame")
                    || p.equals("gilded_blackstone") || p.equals("budding_amethyst") || p.equals("amethyst_cluster")
                    || p.equals("end_portal") || p.equals("nether_portal") || p.equals("reinforced_deepslate");
        });
    }

    private static void reload() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.worldRenderer != null && mc.world != null) mc.worldRenderer.reload();
    }

    @Override
    public void onEnable() {
        CACHE.clear();
        reload();
    }

    @Override
    public void onDisable() {
        reload();
    }
}
