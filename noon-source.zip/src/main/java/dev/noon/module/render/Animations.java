package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

/** 10 swing animations each for attacking and mining (first-person). See HeldItemRendererMixin. */
public class Animations extends Module {
    private static final String[] NAMES = {
            "Vanilla", "Slash", "Spin", "Punch", "Smash", "Swipe", "Flip", "Wobble", "Bounce", "Pull", "Corkscrew",
            "Whip", "Chop", "Jab", "Windmill", "Sway", "Drop", "Yoyo", "Twirl", "Stab", "Orbit", "Shake", "Slam", "Spiral"
    };

    // NAMES must be declared BEFORE INSTANCE: static init runs top-to-bottom, otherwise the Mode settings get no options ("None")
    public static final Animations INSTANCE = new Animations();


    public final Setting.Mode attack = add(new Setting.Mode("Attack Anim", 1, NAMES));
    public final Setting.Mode mining = add(new Setting.Mode("Mining Anim", 2, NAMES));
    public final Setting.Num speed = add(new Setting.Num("Speed", 0.5, 2.5, 1.0, 0.05));
    public final Setting.Num intensity = add(new Setting.Num("Intensity", 0.3, 2.0, 1.0, 0.05));
    public final Setting.Bool idleSway = add(new Setting.Bool("Idle Sway", false));
    public final Setting.Num swayAmount = add(new Setting.Num("Sway Amount", 0.2, 3.0, 1.0, 0.1));
    public final Setting.Bool walkBob = add(new Setting.Bool("Walk Bob", false));
    public final Setting.Bool swingBoth = add(new Setting.Bool("Animate Off Hand", false));

    private Animations() {
        super("Animations", Category.RENDER);
        showInHud = false;
    }

    /** True when a custom swing replaces vanilla's (so the mixin zeroes vanilla's swing progress). */
    public static boolean overridesSwing() {
        Animations a = INSTANCE;
        if (!a.enabled) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean isMining = mc.interactionManager != null && mc.interactionManager.isBreakingBlock();
        return (isMining ? a.mining : a.attack).index != 0;
    }

    /** Slow breathing sway while standing and a gentle bob while moving; independent of the swing animations. */
    private static void idle(Animations a, MinecraftClient mc, MatrixStack m, Hand hand, boolean mainArmIsRight) {
        if (mc.player == null) return;
        double t = (System.nanoTime() / 1.0e9) * 1.6;
        float side = (hand == Hand.MAIN_HAND) == mainArmIsRight ? 1f : -1f;
        float k = a.swayAmount.f();
        if (a.idleSway.get()) {
            m.translate(0.004f * k * side * (float) Math.sin(t * 0.7), 0.006f * k * (float) Math.sin(t), 0f);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 0.9f * k * (float) Math.sin(t * 0.8)));
        }
        if (a.walkBob.get()) {
            double spd = Math.min(0.3, mc.player.getVelocity().horizontalLength());
            if (spd > 0.02 && mc.player.isOnGround()) {
                float amp = (float) (spd / 0.2);
                m.translate(0.012f * amp * (float) Math.sin(t * 5.5) * side, 0.01f * amp * (float) Math.abs(Math.sin(t * 5.5)), 0f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(1.6f * amp * side * (float) Math.sin(t * 5.5)));
            }
        }
    }

    public static void apply(MatrixStack m, Hand hand, boolean mainArmIsRight, float swing) {
        Animations a = INSTANCE;
        if (!a.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        idle(a, mc, m, hand, mainArmIsRight);
        if ((hand != Hand.MAIN_HAND && !a.swingBoth.get()) || swing <= 0.001f) return;
        boolean isMining = mc.interactionManager != null && mc.interactionManager.isBreakingBlock();
        int idx = (isMining ? a.mining : a.attack).index;
        if (idx == 0) return;
        swing = Math.min(1f, swing * a.speed.f());

        float k = a.intensity.f();
        float side = mainArmIsRight ? 1f : -1f;
        float s = (float) Math.sin(swing * Math.PI);
        float px = 0.56f * side, py = -0.52f, pz = -0.72f;

        m.translate(px, py, pz);
        switch (idx) {
            case 1 -> { // Slash
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-side * 60f * s * k));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(20f * s * k));
            }
            case 2 -> m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(360f * swing * k)); // Spin
            case 3 -> m.translate(0f, 0f, -0.55f * s * k); // Punch
            case 4 -> m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-85f * s * k)); // Smash
            case 5 -> { // Swipe
                m.translate(-side * 0.5f * s * k, 0f, 0f);
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 45f * s * k));
            }
            case 6 -> m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(360f * swing * k)); // Flip
            case 7 -> m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees( // Wobble
                    (float) (28f * Math.sin(swing * Math.PI * 4.0) * (1f - swing) * k)));
            case 8 -> m.translate(0f, 0.3f * s * k, -0.1f * s * k); // Bounce
            case 9 -> { // Pull
                m.translate(0f, 0f, 0.45f * s * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(35f * s * k));
            }
            case 10 -> { // Corkscrew
                m.translate(0f, 0f, -0.3f * s * k);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(120f * s * k));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 40f * s * k));
            }
            case 11 -> { // Whip
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-side * 75f * (float) Math.sin(swing * Math.PI * 1.5) * k));
                m.translate(0f, 0f, -0.25f * s * k);
            }
            case 12 -> { // Chop
                m.translate(0f, 0.25f * (1f - swing) * s * k, -0.2f * s * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-70f * (float) Math.sin(Math.min(1f, swing * 1.4f) * Math.PI) * k));
            }
            case 13 -> m.translate(0f, 0f, -0.75f * (float) Math.pow(s, 3) * k); // Jab
            case 14 -> m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(360f * swing * k)); // Windmill
            case 15 -> { // Sway
                m.translate(side * 0.2f * (float) Math.sin(swing * Math.PI * 2) * k, 0f, 0f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 25f * (float) Math.sin(swing * Math.PI * 2) * k));
            }
            case 16 -> { // Drop
                m.translate(0f, -0.45f * s * k, 0.05f * s * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(25f * s * k));
            }
            case 17 -> { // Yoyo
                m.translate(0f, -0.3f * Math.abs((float) Math.sin(swing * Math.PI * 2)) * k, 0f);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-30f * s * k));
            }
            case 18 -> { // Twirl
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(720f * swing * k * (1f - 0.5f * swing)));
                m.translate(0f, 0.1f * s * k, 0f);
            }
            case 19 -> { // Stab
                m.translate(0f, 0.15f * s * k, -0.5f * s * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-25f * s * k));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 12f * s * k));
            }
            case 20 -> { // Orbit
                double ang = swing * Math.PI * 2;
                m.translate((float) Math.sin(ang) * 0.25f * k, (float) (1 - Math.cos(ang)) * 0.15f * k, 0f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * -40f * s * k));
            }
            case 21 -> { // Shake
                m.translate((float) Math.sin(swing * Math.PI * 10) * 0.04f * (1f - swing) * k, (float) Math.cos(swing * Math.PI * 12) * 0.03f * (1f - swing) * k, -0.1f * s * k);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) Math.sin(swing * Math.PI * 9) * 10f * (1f - swing) * k));
            }
            case 22 -> { // Slam
                float e = swing < 0.3f ? swing / 0.3f : 1f - (swing - 0.3f) / 0.7f;
                m.translate(0f, 0.2f * (swing < 0.3f ? e : 0f) * k - 0.3f * (swing >= 0.3f ? e : 0f) * k, -0.2f * s * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees((swing < 0.3f ? 30f * e : -95f * e) * k));
            }
            case 23 -> { // Spiral
                m.translate(0f, 0f, -0.35f * s * k);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 300f * swing * k));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-40f * s * k));
            }
            default -> {
            }
        }
        m.translate(-px, -py, -pz);
    }
}
