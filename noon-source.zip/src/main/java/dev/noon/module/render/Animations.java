package dev.noon.module.render;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

/** 10 swing animations each for attacking and mining (first-person). See HeldItemRendererMixin. */
public class Animations extends Module {
    public static final Animations INSTANCE = new Animations();

    private static final String[] NAMES = {
            "Vanilla", "Slash", "Spin", "Punch", "Smash", "Swipe", "Flip", "Wobble", "Bounce", "Pull", "Corkscrew"
    };

    public final Setting.Mode attack = add(new Setting.Mode("Attack Anim", 1, NAMES));
    public final Setting.Mode mining = add(new Setting.Mode("Mining Anim", 2, NAMES));
    public final Setting.Num speed = add(new Setting.Num("Speed", 0.5, 2.5, 1.0, 0.05));
    public final Setting.Num intensity = add(new Setting.Num("Intensity", 0.3, 2.0, 1.0, 0.05));

    private Animations() {
        super("Animations", Category.RENDER);
        showInHud = false;
    }

    /** True when a custom swing replaces vanilla's (so the mixin zeroes vanilla's swing progress). */
    public static boolean overridesSwing() {
        Animations a = INSTANCE;
        if (!a.enabled) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean isMining = mc.interactionManager != null && mc.interactionManager.isBreakingBlock();
        return (isMining ? a.mining : a.attack).index != 0;
    }

    public static void apply(MatrixStack m, Hand hand, boolean mainArmIsRight, float swing) {
        Animations a = INSTANCE;
        if (!a.enabled || hand != Hand.MAIN_HAND || swing <= 0.001f) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean isMining = mc.interactionManager != null && mc.interactionManager.isBreakingBlock();
        int idx = (isMining ? a.mining : a.attack).index;
        if (idx == 0) return;
        swing = Math.min(1f, swing * a.speed.f());

        float k = a.intensity.f();
        float side = mainArmIsRight ? 1f : -1f;
        float s = (float) Math.sin(swing * Math.PI);
        float px = 0.56f * side, py = -0.52f, pz = -0.72f;

        m.translate(px, py, pz);
        switch (idx) {
            case 1 -> { // Slash
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-side * 60f * s * k));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(20f * s * k));
            }
            case 2 -> m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(360f * swing * k)); // Spin
            case 3 -> m.translate(0f, 0f, -0.55f * s * k); // Punch
            case 4 -> m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-85f * s * k)); // Smash
            case 5 -> { // Swipe
                m.translate(-side * 0.5f * s * k, 0f, 0f);
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 45f * s * k));
            }
            case 6 -> m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(360f * swing * k)); // Flip
            case 7 -> m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees( // Wobble
                    (float) (28f * Math.sin(swing * Math.PI * 4.0) * (1f - swing) * k)));
            case 8 -> m.translate(0f, 0.3f * s * k, -0.1f * s * k); // Bounce
            case 9 -> { // Pull
                m.translate(0f, 0f, 0.45f * s * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(35f * s * k));
            }
            case 10 -> { // Corkscrew
                m.translate(0f, 0f, -0.3f * s * k);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(120f * s * k));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 40f * s * k));
            }
            default -> {
            }
        }
        m.translate(-px, -py, -pz);
    }
}
