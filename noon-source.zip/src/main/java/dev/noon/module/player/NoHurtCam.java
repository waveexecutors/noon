package dev.noon.module.player;

import dev.noon.module.Category;
import dev.noon.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;

/** Stops the screen tilt/shake when you take damage by keeping the client hurt timer at zero. */
public class NoHurtCam extends Module {
    public static final NoHurtCam INSTANCE = new NoHurtCam();

    private NoHurtCam() {
        super("NoHurtCam", Category.RENDER);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p != null) {
            p.hurtTime = 0;
        }
    }
}
