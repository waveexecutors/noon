package dev.noon.module;

import dev.noon.module.client.Configs;
import dev.noon.module.client.GlassMenu;
import dev.noon.module.render.HandGlow;
import dev.noon.module.client.HudModule;
import dev.noon.module.combat.AutoArmor;
import dev.noon.module.combat.AutoTotem;
import dev.noon.module.combat.Criticals;
import dev.noon.module.combat.KillAura;
import dev.noon.module.combat.Reach;
import dev.noon.module.combat.TriggerBot;
import dev.noon.module.combat.Velocity;
import dev.noon.module.combat.AimAssist;
import dev.noon.module.combat.AutoClicker;
import dev.noon.module.combat.HitBox;
import dev.noon.module.combat.JumpReset;
import dev.noon.module.combat.WTap;
import dev.noon.module.render.MobESP;
import dev.noon.module.render.PlayerESP;
import dev.noon.module.render.StorageESP;
import dev.noon.module.render.Tracers;
import dev.noon.module.smp.AutoEat;
import dev.noon.module.smp.AutoLog;
import dev.noon.module.smp.AutoRespawn;
import dev.noon.module.smp.BaseFinder;
import dev.noon.module.smp.ChestStealer;
import dev.noon.module.smp.FastPlace;
import dev.noon.module.smp.PlayerAlert;
import dev.noon.module.player.AutoSprint;
import dev.noon.module.player.AutoTool;
import dev.noon.module.player.FastBreak;
import dev.noon.module.player.NoFall;
import dev.noon.module.player.Step;
import dev.noon.module.player.NoHurtCam;
import dev.noon.module.render.Animations;
import dev.noon.module.render.Fullbright;
import dev.noon.module.render.HandCustomization;
import dev.noon.module.render.XRay;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import org.lwjgl.glfw.GLFW;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static boolean nightVisionApplied;

    private ModuleManager() {}

    public static void init() {
        MODULES.clear();
        BY_CAT.clear();
        Collections.addAll(MODULES,
                Criticals.INSTANCE, KillAura.INSTANCE, TriggerBot.INSTANCE, AutoTotem.INSTANCE,
                Velocity.INSTANCE, Reach.INSTANCE, AutoArmor.INSTANCE,
                AutoClicker.INSTANCE, AimAssist.INSTANCE, HitBox.INSTANCE, WTap.INSTANCE, JumpReset.INSTANCE,
                FastBreak.INSTANCE, AutoSprint.INSTANCE, NoFall.INSTANCE, Step.INSTANCE, AutoTool.INSTANCE,
                PlayerESP.INSTANCE, MobESP.INSTANCE, StorageESP.INSTANCE, Tracers.INSTANCE,
                BaseFinder.INSTANCE, AutoEat.INSTANCE, ChestStealer.INSTANCE, AutoRespawn.INSTANCE, AutoLog.INSTANCE,
                PlayerAlert.INSTANCE, FastPlace.INSTANCE,
                XRay.INSTANCE, Fullbright.INSTANCE, NoHurtCam.INSTANCE, HandCustomization.INSTANCE, Animations.INSTANCE,
                HandGlow.INSTANCE, HudModule.INSTANCE, GlassMenu.INSTANCE, Configs.INSTANCE);
    }

    public static List<Module> all() {
        return MODULES;
    }

    private static final java.util.Map<Category, List<Module>> BY_CAT = new java.util.EnumMap<>(Category.class);

    /** Cached per-category lists (no per-frame allocation in the ClickGUI). */
    public static List<Module> byCategory(Category c) {
        return BY_CAT.computeIfAbsent(c, k -> {
            List<Module> out = new ArrayList<>();
            for (Module m : MODULES) {
                if (m.category == k) out.add(m);
            }
            return out;
        });
    }

    public static void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getWindow() != null) {
            long handle = mc.getWindow().getHandle();
            for (Module m : MODULES) {
                if (m.key < 0) continue;
                boolean down = GLFW.glfwGetKey(handle, m.key) == GLFW.GLFW_PRESS;
                if (down && !m.keyDown && mc.currentScreen == null) m.toggle();
                m.keyDown = down;
            }
        }
        for (Module m : MODULES) {
            if (m.enabled) m.onTick();
        }
        Configs.INSTANCE.poll();
        updateNightVision();
    }

    private static void updateNightVision() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p == null) {
            nightVisionApplied = false;
            return;
        }
        boolean want = Fullbright.INSTANCE.enabled || (XRay.INSTANCE.enabled && XRay.INSTANCE.light.get());
        if (want) {
            if (!p.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1_000_000, 0, false, false, false));
                nightVisionApplied = true;
            }
        } else if (nightVisionApplied) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            nightVisionApplied = false;
        }
    }

    // ---- persistence -------------------------------------------------------

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("noon.properties");
    }

    public static Path slotFile(int n) {
        return FabricLoader.getInstance().getConfigDir().resolve("noon_slot" + n + ".properties");
    }

    public static void save() {
        saveTo(file());
    }

    public static void saveTo(Path f) {
        Properties p = new Properties();
        for (Module m : MODULES) {
            p.setProperty(m.name + ".enabled", Boolean.toString(m.enabled));
            p.setProperty(m.name + ".key", Integer.toString(m.key));
            for (Setting s : m.settings) {
                p.setProperty(m.name + "." + s.name, s.ser());
            }
        }
        try (Writer w = Files.newBufferedWriter(f)) {
            p.store(w, "Noon config");
        } catch (IOException ignored) {
        }
    }

    public static void load() {
        loadFrom(file());
    }

    public static boolean loadFrom(Path f) {
        if (!Files.exists(f)) return false;
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(f)) {
            p.load(r);
        } catch (IOException e) {
            return false;
        }
        for (Module m : MODULES) {
            String en = p.getProperty(m.name + ".enabled");
            if (en != null) {
                m.setEnabled(Boolean.parseBoolean(en));
                m.toggle.v = m.enabled ? 1f : 0f;
                m.hud.v = m.enabled ? 1f : 0f;
            }
            String kv = p.getProperty(m.name + ".key");
            if (kv != null) {
                try {
                    m.key = Integer.parseInt(kv);
                } catch (NumberFormatException ignored) {
                }
            }
            for (Setting s : m.settings) {
                String v = p.getProperty(m.name + "." + s.name);
                if (v != null) {
                    s.de(v);
                    if (s instanceof Setting.Bool b) b.anim.v = b.value ? 1f : 0f;
                }
            }
        }
        HudModule.INSTANCE.master.v = HudModule.INSTANCE.enabled ? 1f : 0f;
        return true;
    }
}
