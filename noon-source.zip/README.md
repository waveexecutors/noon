# Noon (Fabric 1.21.11)

iOS-style glass utility client. Right Shift opens the ClickGUI.

Build locally: `gradle build` (Gradle 9.2+, Java 21) -> `build/libs/noon-1.0.0.jar`.
Config is saved to `config/noon.properties`.

ClickGUI: left click = toggle, right click (or the arrow) = expand settings, mouse wheel / Up / Down = scroll.
Turn the "HUD" module off to hide the whole HUD.
