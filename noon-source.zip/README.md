# Noon (Fabric 1.21.11)

iOS-style glass utility client. Right Shift opens the ClickGUI.

Build locally: `gradle build` (Gradle 9.2+, Java 21) -> `build/libs/noon-1.0.0.jar`.
Config is saved to `config/noon.properties`.

ClickGUI: left click = toggle, right click (or the arrow) = expand settings, mouse wheel / Up / Down = scroll.
Turn the "HUD" module off to hide the whole HUD.

## New in this version
- **ClickGUI**: iOS-26 liquid-glass look, spring animations, staggered card entrance, culled off-screen cards, cached rounded-rect tables (no more lag).
- **Render**: Player ESP (CS2 corners / 2D / 3D box, health bar + HP number, name, held item, distance), Mob ESP (+items), Storage ESP, Tracers.
- **SMP**: BaseFinder (chunk scoring -> markers + list + chat ping), AutoEat, ChestStealer, AutoRespawn (+death coords), AutoLog, PlayerAlert, FastPlace.
- **Combat**: AutoClicker, AimAssist, HitBox, WTap, JumpReset.
- **Fix**: hand animations - vanilla swing is now zeroed while a custom swing is selected, and the mixin matches by argument type.
  Turn the "Animations" module ON, then pick Attack / Mining anim in its settings.
- **Alt Manager**: button top-left of the title screen. Offline/cracked accounts only (config/noon_alts.txt). Criticals 'Legit' mode no longer touches velocity or delays clicks.

## v6
- ClickGUI: flat modern style, no vanilla blur (lag fix), no nested scissor (right-click / expand crash fix).
- Hand Glow module (RGB / custom / fade / pulse), Configs tab (presets + 3 save slots), more settings on KillAura, TriggerBot, Velocity, Animations, NoFall, AutoSprint, FastBreak.
- Presets are conservative, NOT guaranteed undetectable.
