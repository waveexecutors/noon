package dev.noon.mixin;

import dev.noon.module.render.HandCustomization;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void noon$handBegin(AbstractClientPlayerEntity player, float tickProgress, float pitch, Hand hand,
                                float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                                @Coerce Object queue, int light, CallbackInfo ci) {
        matrices.push();
        HandCustomization.apply(matrices, hand, player.getMainArm() == Arm.RIGHT);
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
    private void noon$handEnd(AbstractClientPlayerEntity player, float tickProgress, float pitch, Hand hand,
                              float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                              @Coerce Object queue, int light, CallbackInfo ci) {
        matrices.pop();
    }
}
