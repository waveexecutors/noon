package dev.noon.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Small 2D drawing helpers: rounded rects, glass panels, text. */
public final class Gfx {
    public static final int ACCENT = 0xFF0A84FF;
    public static final int GREEN = 0xFF34C759;
    public static final int WHITE = 0xFFFFFFFF;
    public static final int GREY = 0xFFAEAEB2;

    private Gfx() {}

    public static int alpha(int c, float m) {
        m = Math.max(0f, Math.min(1f, m));
        int a = Math.round((c >>> 24) * m);
        return (a << 24) | (c & 0xFFFFFF);
    }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >>> 24) & 255, rr = (a >>> 16) & 255, gr = (a >>> 8) & 255, br = a & 255;
        int ab = (b >>> 24) & 255, rb = (b >>> 16) & 255, gb = (b >>> 8) & 255, bb = b & 255;
        int oa = Math.round(ar + (ab - ar) * t);
        int or = Math.round(rr + (rb - rr) * t);
        int og = Math.round(gr + (gb - gr) * t);
        int ob = Math.round(br + (bb - br) * t);
        return (oa << 24) | (or << 16) | (og << 8) | ob;
    }

    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0 || (color >>> 24) == 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * (double) r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    /** iOS-style frosted glass panel: rim, tinted body, top sheen. */
    public static void glass(DrawContext c, int x, int y, int w, int h, int r, float m) {
        if (m < 0.01f) return;
        rrect(c, x, y, w, h, r, alpha(0x3CFFFFFF, m));
        rrect(c, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), alpha(0x8C14141E, m));
        int top = y + 2;
        int bottom = y + Math.max(4, h / 3);
        if (w - 2 * r > 0) {
            c.fillGradient(x + r, top, x + w - r, bottom, alpha(0x2AFFFFFF, m), alpha(0x00FFFFFF, m));
        }
    }

    public static void text(DrawContext c, String s, int x, int y, int color) {
        if ((color >>> 24) < 5) return;
        c.drawText(MinecraftClient.getInstance().textRenderer, s, x, y, color, false);
    }

    public static int width(String s) {
        return MinecraftClient.getInstance().textRenderer.getWidth(s);
    }
}
