package dev.noon.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {
    @Accessor("itemUseCooldown")
    int noon$getUseCooldown();

    @Accessor("itemUseCooldown")
    void noon$setUseCooldown(int v);
}
