package dev.noon.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * 2D drawing helpers: anti-aliased rounded rects (cached corner tables, run-merged fills - cheap),
 * iOS-26 style "liquid glass" panels, text.
 */
public final class Gfx {
    public static final int ACCENT = 0xFF0A84FF;
    public static final int GREEN = 0xFF34C759;
    public static final int RED = 0xFFFF453A;
    public static final int ORANGE = 0xFFFF9F0A;
    public static final int WHITE = 0xFFFFFFFF;
    public static final int GREY = 0xFFAEAEB2;

    private Gfx() {}

    // ---- corner tables ------------------------------------------------------------------------

    private static final class Tab {
        final int[] full;     // first fully covered column in row i
        final float[][] aa;   // coverage of columns [0, full[i]) in row i
        final int[] start;    // first column with visible coverage

        Tab(int r) {
            full = new int[r];
            aa = new float[r][];
            start = new int[r];
            double rr = (double) r * r;
            for (int i = 0; i < r; i++) {
                float[] cov = new float[r];
                for (int c = 0; c < r; c++) {
                    int in = 0;
                    for (int sy = 0; sy < 4; sy++) {
                        for (int sx = 0; sx < 4; sx++) {
                            double px = c + (sx + 0.5) / 4.0, py = i + (sy + 0.5) / 4.0;
                            double dx = r - px, dy = r - py;
                            if (dx * dx + dy * dy <= rr) in++;
                        }
                    }
                    cov[c] = in / 16f;
                }
                int f = 0;
                while (f < r && cov[f] < 0.97f) f++;
                int s = 0;
                while (s < f && cov[s] < 0.03f) s++;
                full[i] = f;
                start[i] = s;
                aa[i] = cov;
            }
        }
    }

    private static final Tab[] TABS = new Tab[65];

    private static Tab tab(int r) {
        r = Math.min(r, 64);
        Tab t = TABS[r];
        if (t == null) TABS[r] = t = new Tab(r);
        return t;
    }

    // ---- colour helpers -----------------------------------------------------------------------

    public static int alpha(int c, float m) {
        m = Math.max(0f, Math.min(1f, m));
        int a = Math.round((c >>> 24) * m);
        return (a << 24) | (c & 0xFFFFFF);
    }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >>> 24) & 255, rr = (a >>> 16) & 255, gr = (a >>> 8) & 255, br = a & 255;
        int ab = (b >>> 24) & 255, rb = (b >>> 16) & 255, gb = (b >>> 8) & 255, bb = b & 255;
        int oa = Math.round(ar + (ab - ar) * t);
        int or = Math.round(rr + (rb - rr) * t);
        int og = Math.round(gr + (gb - gr) * t);
        int ob = Math.round(br + (bb - br) * t);
        return (oa << 24) | (or << 16) | (og << 8) | ob;
    }

    // ---- shapes -------------------------------------------------------------------------------

    /** Anti-aliased rounded rectangle. */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0 || (color >>> 24) == 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        Tab t = tab(r);
        r = Math.min(r, 64);
        c.fill(x, y + r, x + w, y + h - r, color);
        int i = 0;
        while (i < r) {
            int f = t.full[i];
            int j = i + 1;
            while (j < r && t.full[j] == f) j++;
            if (x + w - f > x + f) {
                c.fill(x + f, y + i, x + w - f, y + j, color);
                c.fill(x + f, y + h - j, x + w - f, y + h - i, color);
            }
            for (int k = i; k < j; k++) {
                float[] cov = t.aa[k];
                for (int col = t.start[k]; col < f; col++) {
                    int ec = alpha(color, cov[col]);
                    c.fill(x + col, y + k, x + col + 1, y + k + 1, ec);
                    c.fill(x + w - 1 - col, y + k, x + w - col, y + k + 1, ec);
                    c.fill(x + col, y + h - 1 - k, x + col + 1, y + h - k, ec);
                    c.fill(x + w - 1 - col, y + h - 1 - k, x + w - col, y + h - k, ec);
                }
            }
            i = j;
        }
    }

    /** 1px rounded outline with a vertical colour gradient (top -> bottom). */
    public static void outline(DrawContext c, int x, int y, int w, int h, int r, int top, int bottom) {
        if (w <= 2 || h <= 2) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 1) {
            c.fill(x, y, x + w, y + 1, top);
            c.fill(x, y + h - 1, x + w, y + h, bottom);
            c.fillGradient(x, y + 1, x + 1, y + h - 1, top, bottom);
            c.fillGradient(x + w - 1, y + 1, x + w, y + h - 1, top, bottom);
            return;
        }
        Tab o = tab(r);
        Tab in = tab(r - 1);
        r = Math.min(r, 64);
        float hf = Math.max(1, h - 1);
        c.fill(x + o.full[0], y, x + w - o.full[0], y + 1, top);
        c.fill(x + o.full[0], y + h - 1, x + w - o.full[0], y + h, bottom);
        for (int i = 1; i < r; i++) {
            int a = o.full[i];
            int b = Math.max(a + 1, 1 + (i - 1 < in.full.length ? in.full[i - 1] : 0));
            int ct = lerp(top, bottom, i / hf);
            int cb = lerp(top, bottom, (h - 1 - i) / hf);
            c.fill(x + a, y + i, x + b, y + i + 1, ct);
            c.fill(x + w - b, y + i, x + w - a, y + i + 1, ct);
            c.fill(x + a, y + h - 1 - i, x + b, y + h - i, cb);
            c.fill(x + w - b, y + h - 1 - i, x + w - a, y + h - i, cb);
        }
        int ct = lerp(top, bottom, r / hf), cb = lerp(top, bottom, (h - r) / hf);
        if (h - 2 * r > 0) {
            c.fillGradient(x, y + r, x + 1, y + h - r, ct, cb);
            c.fillGradient(x + w - 1, y + r, x + w, y + h - r, ct, cb);
        }
    }

    /** Soft drop shadow made of a few expanding translucent layers. */
    public static void shadow(DrawContext c, int x, int y, int w, int h, int r, float m) {
        if (m < 0.01f) return;
        for (int i = 1; i <= 3; i++) {
            int g = i * 3;
            rrect(c, x - g, y - g + 5, w + g * 2, h + g * 2, r + g, alpha(0x14000000, m * (4 - i) / 3f));
        }
    }

    /** iOS-26 style liquid glass: dark frosted body over the blurred backdrop, top sheen, bright specular rim. */
    public static void glass(DrawContext c, int x, int y, int w, int h, int r, float m) {
        if (m < 0.01f) return;
        rrect(c, x, y, w, h, r, alpha(0x7A101018, m));
        rrect(c, x, y, w, h, r, alpha(0x14FFFFFF, m));
        int sheenH = Math.max(4, Math.min(h / 2, 40));
        if (w - 2 * r > 0 && sheenH > 2) {
            c.fillGradient(x + r, y + 1, x + w - r, y + sheenH, alpha(0x30FFFFFF, m), alpha(0x00FFFFFF, m));
        }
        outline(c, x, y, w, h, r, alpha(0xA0FFFFFF, m), alpha(0x2CFFFFFF, m));
    }

    /** Lighter inner card (module rows, buttons). */
    public static void card(DrawContext c, int x, int y, int w, int h, int r, float m, float hover) {
        if (m < 0.01f) return;
        rrect(c, x, y, w, h, r, alpha(lerp(0x1CFFFFFF, 0x36FFFFFF, hover), m));
        outline(c, x, y, w, h, r, alpha(lerp(0x46FFFFFF, 0x78FFFFFF, hover), m), alpha(0x12FFFFFF, m));
    }

    public static void text(DrawContext c, String s, int x, int y, int color) {
        if ((color >>> 24) < 5) return;
        c.drawText(MinecraftClient.getInstance().textRenderer, s, x, y, color, false);
    }

    public static void textShadow(DrawContext c, String s, int x, int y, int color) {
        if ((color >>> 24) < 5) return;
        c.drawText(MinecraftClient.getInstance().textRenderer, s, x, y, color, true);
    }

    public static int width(String s) {
        return MinecraftClient.getInstance().textRenderer.getWidth(s);
    }
}
