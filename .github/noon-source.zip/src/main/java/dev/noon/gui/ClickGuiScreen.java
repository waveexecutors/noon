package dev.noon.gui;

import dev.noon.module.Category;
import dev.noon.module.Module;
import dev.noon.module.ModuleManager;
import dev.noon.module.Setting;
import dev.noon.util.Anim;
import dev.noon.util.Gfx;
import dev.noon.util.Keys;
import dev.noon.util.Sounds;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Noon ClickGUI - iOS 26 "liquid glass" window.
 * Springs everywhere, staggered card entrance, off-screen cards are culled, rounded rects use cached tables.
 * Input is polled straight from GLFW so it does not depend on Screen input signatures.
 * Left click: toggle / change. Right click (or the arrow): expand settings.
 */
public class ClickGuiScreen extends Screen {
    private static final int W = 540, H = 340;
    private static final int MOD_H = 32, SET_H = 24, SIDE_W = 108, ITEM_H = 24, ITEM_GAP = 3;

    private final Anim open = new Anim();
    private final Anim scrollAnim = new Anim();
    private final Anim pillY = new Anim();
    private final Anim[] catHover = new Anim[Category.values().length];

    private boolean closing;
    private Category selected = Category.COMBAT;
    private long switchTime = System.nanoTime();
    private float scrollTarget;
    private int maxScroll;
    private boolean prevL, prevR;
    private Setting.Num dragging;
    private int dragX, dragW;
    private Module binding;
    private final boolean[] prevKeys = new boolean[GLFW.GLFW_KEY_LAST + 1];

    public boolean isBinding() {
        return binding != null;
    }

    public ClickGuiScreen() {
        super(Text.literal("Noon"));
        for (int i = 0; i < catHover.length; i++) catHover[i] = new Anim();
        pillY.v = 0;
        Sounds.slide(true);
    }

    public void requestClose() {
        if (!closing) {
            closing = true;
            Sounds.slide(false);
        }
    }

    @Override
    public void close() {
        if (binding != null) {
            binding = null; // Esc cancels binding
            return;
        }
        requestClose();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // vanilla mouse wheel (no @Override on purpose: arrow keys also scroll if the signature ever changes)
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollTarget -= (float) verticalAmount * 34f;
        return true;
    }

    private static void drawSwitch(DrawContext ctx, int x, int y, int w, int h, float t, float o) {
        int track = Gfx.lerp(0x66787880, Gfx.GREEN, t);
        Gfx.rrect(ctx, x, y, w, h, h / 2, Gfx.alpha(track, o));
        int k = h - 4;
        int stretch = Math.round(4f * (float) Math.sin(Math.PI * Math.max(0f, Math.min(1f, t))));
        int kw = k + stretch;
        int kx = x + 2 + Math.round((w - k - 4) * t) - (t > 0.5f ? stretch : 0);
        Gfx.rrect(ctx, kx + 1, y + 3, kw, k, k / 2, Gfx.alpha(0x30000000, o));
        Gfx.rrect(ctx, kx, y + 2, kw, k, k / 2, Gfx.alpha(0xFFFFFFFF, o));
    }

    private static String fmt(Setting.Num n) {
        if (n.step >= 1) return Integer.toString(n.i());
        return String.format(Locale.ROOT, "%.2f", n.get());
    }

    private static int settingsHeight(Module m) {
        return (m.settings.size() + 1) * SET_H + 8;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta); // vanilla background blur (the glass backdrop)

        float openRaw = open.spring(closing ? 0f : 1f, 170f, closing ? 26f : 15f);
        float o = Math.max(0f, Math.min(1f, openRaw * (closing ? 1f : 1.15f)));
        if (closing && openRaw <= 0.03f) {
            ModuleManager.save();
            this.client.setScreen(null);
            return;
        }
        boolean ready = !closing && openRaw > 0.7f;

        // ---- input (polled) ----
        long handle = this.client.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean clickL = l && !prevL && ready, clickR = r && !prevR && ready;
        prevL = l;
        prevR = r;
        if (!l || !ready) dragging = null;
        if (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_DOWN) == GLFW.GLFW_PRESS) scrollTarget += 7f;
        if (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_UP) == GLFW.GLFW_PRESS) scrollTarget -= 7f;

        if (binding != null) {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                boolean d = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
                if (d && !prevKeys[k] && k != GLFW.GLFW_KEY_ESCAPE) {
                    binding.key = (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) ? -1 : k;
                    binding = null;
                    Sounds.click();
                }
                prevKeys[k] = d;
                if (binding == null) break;
            }
        }

        // ---- window ----
        int ww = Math.min(W, this.width - 16);
        int hh = Math.min(H, this.height - 16);
        int x = (this.width - ww) / 2;
        int y = (this.height - hh) / 2 + Math.round((1f - openRaw) * 70f);

        ctx.fill(0, 0, this.width, this.height, Gfx.alpha(0x40000000, o));
        Gfx.shadow(ctx, x, y, ww, hh, 22, o);
        Gfx.glass(ctx, x, y, ww, hh, 22, o);

        // ---- sidebar ----
        Gfx.textShadow(ctx, "Noon", x + 22, y + 18, Gfx.alpha(Gfx.WHITE, o));
        int on = 0;
        for (Module m : ModuleManager.all()) if (m.enabled && m.showInHud) on++;
        Gfx.text(ctx, on + " active", x + 22, y + 30, Gfx.alpha(Gfx.GREY, o));

        Category[] cats = Category.values();
        int sideTop = y + 52;
        int selIdx = selected.ordinal();
        float py = pillY.spring(selIdx * (ITEM_H + ITEM_GAP), 260f, 24f);
        int sx = x + 12, sw = SIDE_W - 12;
        Gfx.rrect(ctx, sx, sideTop + Math.round(py), sw, ITEM_H, 12, Gfx.alpha(0xB30A84FF, o));
        Gfx.outline(ctx, sx, sideTop + Math.round(py), sw, ITEM_H, 12, Gfx.alpha(0x90FFFFFF, o), Gfx.alpha(0x20FFFFFF, o));
        for (int i = 0; i < cats.length; i++) {
            Category c = cats[i];
            int ry = sideTop + i * (ITEM_H + ITEM_GAP);
            boolean hov = ready && mx >= sx && mx < sx + sw && my >= ry && my < ry + ITEM_H;
            float hv = catHover[i].to(hov && selected != c ? 1f : 0f, 16f);
            if (hv > 0.01f) Gfx.rrect(ctx, sx, ry, sw, ITEM_H, 12, Gfx.alpha(0x20FFFFFF, o * hv));
            int col = selected == c ? Gfx.WHITE : Gfx.lerp(0xFFB4B4BA, Gfx.WHITE, hv);
            Gfx.text(ctx, c.label, sx + 14, ry + (ITEM_H - 8) / 2, Gfx.alpha(col, o));
            if (clickL && hov && selected != c) {
                selected = c;
                scrollTarget = 0;
                scrollAnim.set(0);
                switchTime = System.nanoTime();
                Sounds.click();
            }
        }
        Gfx.text(ctx, "RShift to close", x + 22, y + hh - 20, Gfx.alpha(0xFF8E8E93, o));

        // ---- content ----
        int cx = x + SIDE_W + 18, cy = y + 14, cw = ww - SIDE_W - 18 - 18, ch = hh - 28;
        Gfx.textShadow(ctx, selected.label, cx + 4, cy + 4, Gfx.alpha(Gfx.WHITE, o));
        int viewTop = cy + 22, viewBottom = cy + ch, viewH = viewBottom - viewTop;

        scrollTarget = Math.max(0f, Math.min(scrollTarget, maxScroll));
        float scroll = scrollAnim.to(scrollTarget, 18f);
        boolean mouseInView = my >= viewTop && my < viewBottom && mx >= cx && mx < cx + cw;
        float sinceSwitch = (System.nanoTime() - switchTime) / 1_000_000_000f;

        ctx.enableScissor(cx - 3, viewTop, cx + cw + 3, viewBottom);
        int yy = viewTop - Math.round(scroll);
        int startY = yy;
        List<Module> mods = ModuleManager.byCategory(selected);

        for (int mi = 0; mi < mods.size(); mi++) {
            Module m = mods.get(mi);
            float ex = m.expand.spring(m.expanded ? 1f : 0f, 210f, 22f);
            ex = Math.max(0f, ex);
            int setH = settingsHeight(m);
            int cardH = MOD_H + Math.round(setH * ex);

            float ap = Anim.easeOutCubic(sinceSwitch * 3.2f - mi * 0.12f);
            int drawY = yy + Math.round((1f - ap) * 14f);
            float co = o * ap;

            // cull cards outside of the viewport (they still advance the layout)
            if (drawY > viewBottom || drawY + cardH < viewTop) {
                yy += cardH + 6;
                continue;
            }

            boolean hov = mouseInView && mx >= cx && mx < cx + cw && my >= drawY && my < drawY + MOD_H;
            float hv = m.hover.to(hov ? 1f : 0f, 16f);
            float tg = m.toggle.to(m.enabled ? 1f : 0f, 16f);

            Gfx.card(ctx, cx, drawY, cw, cardH, 12, co, hv);
            if (tg > 0.01f) Gfx.rrect(ctx, cx, drawY, cw, cardH, 12, Gfx.alpha(0x2C0A84FF, co * tg));

            int ty = drawY + (MOD_H - 8) / 2;
            Gfx.text(ctx, m.name, cx + 14, ty, Gfx.alpha(Gfx.WHITE, co));
            if (m.key >= 0) {
                Gfx.text(ctx, "[" + Keys.name(m.key) + "]", cx + 14 + Gfx.width(m.name) + 6, ty, Gfx.alpha(Gfx.GREY, co));
            }
            int swW = 38, swH = 20, swX = cx + cw - swW - 12, swY = drawY + (MOD_H - swH) / 2;
            drawSwitch(ctx, swX, swY, swW, swH, tg, co);
            Gfx.text(ctx, m.expanded ? "v" : ">", swX - 16, ty, Gfx.alpha(Gfx.lerp(Gfx.GREY, Gfx.WHITE, hv), co));

            if (hov && clickL) {
                if (mx >= swX - 28 && mx < swX - 6) m.expanded = !m.expanded;
                else m.toggle();
                Sounds.click();
            } else if (hov && clickR) {
                m.expanded = !m.expanded;
                Sounds.click();
            }

            if (ex > 0.02f) {
                ctx.enableScissor(cx, drawY + MOD_H, cx + cw, drawY + cardH);
                int sy = drawY + MOD_H + 2;
                boolean interactive = ex > 0.9f && mouseInView;
                float sa = co * Math.min(1f, ex * 1.4f);

                // keybind row
                {
                    boolean kHov = interactive && my >= sy && my < sy + SET_H;
                    Gfx.text(ctx, "Keybind", cx + 14, sy + (SET_H - 8) / 2, Gfx.alpha(0xFFD1D1D6, sa));
                    String kn = binding == m ? "press a key..." : Keys.name(m.key);
                    int kw = Gfx.width(kn) + 18;
                    int kx = cx + cw - 12 - kw;
                    Gfx.rrect(ctx, kx, sy + 3, kw, SET_H - 6, (SET_H - 6) / 2, Gfx.alpha(binding == m ? 0xB3FF9F0A : 0x66787880, sa));
                    Gfx.text(ctx, kn, kx + 9, sy + (SET_H - 8) / 2, Gfx.alpha(Gfx.WHITE, sa));
                    if (kHov && clickL && mx >= kx - 4) {
                        binding = binding == m ? null : m;
                        if (binding != null) {
                            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                                prevKeys[k] = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
                            }
                        }
                        Sounds.click();
                    }
                    sy += SET_H;
                }

                for (Setting s : m.settings) {
                    boolean rowHov = interactive && my >= sy && my < sy + SET_H;
                    Gfx.text(ctx, s.name, cx + 14, sy + (SET_H - 8) / 2, Gfx.alpha(0xFFD1D1D6, sa));

                    if (s instanceof Setting.Bool b) {
                        int bw = 30, bh = 18, bx = cx + cw - bw - 12, by = sy + (SET_H - bh) / 2;
                        drawSwitch(ctx, bx, by, bw, bh, b.anim.to(b.value ? 1f : 0f, 16f), sa);
                        if (rowHov && clickL) {
                            b.value = !b.value;
                            Sounds.click();
                        }
                    } else if (s instanceof Setting.Num n) {
                        String val = fmt(n);
                        int vw = Gfx.width(val);
                        int tw = Math.min(120, cw / 3);
                        int tx = cx + cw - 12 - vw - 10 - tw;
                        int ty2 = sy + SET_H / 2 - 2;
                        double range = n.max - n.min;
                        double frac = range > 0 ? (n.get() - n.min) / range : 0.0;
                        float fa = n.anim.to((float) frac, 22f);
                        int fillW = Math.round(tw * fa);
                        boolean active = dragging == n;
                        Gfx.rrect(ctx, tx, ty2, tw, 4, 2, Gfx.alpha(0x66787880, sa));
                        Gfx.rrect(ctx, tx, ty2, Math.max(4, fillW), 4, 2, Gfx.alpha(Gfx.ACCENT, sa));
                        int kr = active ? 6 : 5;
                        Gfx.rrect(ctx, tx + fillW - kr, ty2 + 2 - kr, kr * 2, kr * 2, kr, Gfx.alpha(0xFFFFFFFF, sa));
                        Gfx.text(ctx, val, cx + cw - 12 - vw, sy + (SET_H - 8) / 2, Gfx.alpha(Gfx.WHITE, sa));
                        if (interactive && clickL && mx >= tx - 6 && mx < tx + tw + 6 && my >= sy && my < sy + SET_H) {
                            dragging = n;
                            dragX = tx;
                            dragW = tw;
                        }
                    } else if (s instanceof Setting.Mode md) {
                        String val = md.get();
                        int pw = Gfx.width(val) + 18;
                        int px = cx + cw - 12 - pw, py2 = sy + 3;
                        Gfx.rrect(ctx, px, py2, pw, SET_H - 6, (SET_H - 6) / 2, Gfx.alpha(0x8C0A84FF, sa));
                        Gfx.text(ctx, val, px + 9, sy + (SET_H - 8) / 2, Gfx.alpha(Gfx.WHITE, sa));
                        if (rowHov && clickL && mx >= px - 4) {
                            md.next();
                            Sounds.click();
                        } else if (rowHov && clickR && mx >= px - 4) {
                            md.prev();
                            Sounds.click();
                        }
                    }
                    sy += SET_H;
                }
                ctx.disableScissor();
            }
            yy += cardH + 6;
        }
        ctx.disableScissor();

        maxScroll = Math.max(0, (yy - startY) - viewH);

        // thin scrollbar
        if (maxScroll > 0) {
            int trackH = viewH - 8;
            int thumbH = Math.max(18, Math.round(trackH * (viewH / (float) (viewH + maxScroll))));
            int thumbY = viewTop + 4 + Math.round((trackH - thumbH) * (scroll / maxScroll));
            Gfx.rrect(ctx, cx + cw + 6, thumbY, 3, thumbH, 1, Gfx.alpha(0x66FFFFFF, o));
        }

        if (dragging != null && l) {
            double f = (mx - dragX) / (double) dragW;
            f = Math.max(0.0, Math.min(1.0, f));
            dragging.set(dragging.min + f * (dragging.max - dragging.min));
        }
    }
}
